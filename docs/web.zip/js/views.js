/* Screen rendering */
(function (global) {
  'use strict';

  var esc = UI.esc, md = UI.md, icon = UI.icon;
  var openRouterQuotaClock = null, openRouterQuotaPoll = null;

  function $(sel, root) { return (root || document).querySelector(sel); }
  function on(root, sel, ev, fn) {
    (root.querySelectorAll ? root.querySelectorAll(sel) : []).forEach(function (el) {
      if (el) el.addEventListener(ev, fn);   /* test stubs may lack the element */
    });
  }
  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase();
  }
  function avatarHtml(src, name, cls) {
    if (src) return '<img src="' + esc(src) + '" alt="" class="' + (cls || '') + '">';
    return '<div class="ph" style="width:100%;height:100%;display:grid;place-items:center;font-size:12px;color:var(--dim)">' +
      esc(initials(name)) + '</div>';
  }
  /* v1.31.0: the active persona's photo, if it has one. Personas carry
     their avatar on the persona record; the default identity (no persona
     selected) and a persona without a photo keep initials. */
  function activePersonaAvatar(s) {
    var id = (s && s.activePersona) || '';
    if (!id) return '';
    var p = (Store.personas || []).find(function (x) { return x.id === id; });
    return (p && p.avatar) || '';
  }
  function pickFile(accept) {
    return new Promise(function (resolve) {
      var inp = document.createElement('input');
      inp.type = 'file'; inp.accept = accept;
      inp.onchange = function () { resolve(inp.files && inp.files[0]); };
      inp.click();
    });
  }
  function fileToDataUrl(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
  }

  /* 18.2.0: newly imported images arrive normalized — downscaled to at most
     maxDim px and re-encoded (PNG only when the picture actually has
     transparency, JPEG 0.85 otherwise). A 12 MP phone photo must not become
     several MB of base64 sitting in IndexedDB. The math helpers are pure
     and unit-tested; the canvas glue falls back to the raw data URL if any
     step throws. */
  function imageTargetSize(w, h, maxDim) {
    maxDim = maxDim || 512;
    var scale = Math.min(1, maxDim / Math.max(w || 1, h || 1));
    return {
      w: Math.max(1, Math.round((w || 1) * scale)),
      h: Math.max(1, Math.round((h || 1) * scale))
    };
  }
  function imageMime(hasAlpha) { return hasAlpha ? 'image/png' : 'image/jpeg'; }

  function normalizeImage(file, maxDim) {
    return new Promise(function (resolve) {
      function fallback() { fileToDataUrl(file).then(resolve, resolve); }
      try {
        if (!file || !file.size || file.size < 40 * 1024) return fallback(); /* already tiny */
        var url = null;
        try { if (typeof URL !== 'undefined' && URL.createObjectURL) url = URL.createObjectURL(file); } catch (e) { /* ignore */ }
        if (!url) return fallback();
        var img = new Image();
        img.onerror = function () { try { URL.revokeObjectURL(url); } catch (e) {} fallback(); };
        img.onload = function () {
          try {
            var t = imageTargetSize(img.naturalWidth || img.width, img.naturalHeight || img.height, maxDim);
            var canvas = document.createElement('canvas');
            canvas.width = t.w; canvas.height = t.h;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, t.w, t.h);
            var hasAlpha = false;
            try {
              var data = ctx.getImageData(0, 0, t.w, t.h).data;
              for (var i = 3; i < data.length; i += 64) if (data[i] < 255) { hasAlpha = true; break; }
            } catch (e) { hasAlpha = true; } /* unknown → keep it lossless */
            resolve(canvas.toDataURL(imageMime(hasAlpha), 0.85));
          } catch (e2) { fallback(); }
          try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ }
        };
        img.src = url;
      } catch (e) { fallback(); }
    });
  }

  /* Card import runs the same normalization on the avatar the card carries
     (a data: URI, not a File). Anything that is not an image data URI —
     web URLs, unknown types — passes through unchanged, and so does a
     decode failure: the <img> shows those as well as the re-encoded
     result, and the card's original bytes are never lost. */
  function normalizeDataUrl(dataUrl, maxDim) {
    return new Promise(function (resolve) {
      function fallback() { resolve(dataUrl || ''); }
      try {
        if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image') !== 0) return fallback();
        var img = new Image();
        img.onerror = function () { fallback(); };
        img.onload = function () {
          try {
            var w = img.naturalWidth || img.width || 0, h = img.naturalHeight || img.height || 0;
            if (!w || !h) return fallback();
            var t = imageTargetSize(w, h, maxDim);
            if (t.w === w && t.h === h) return fallback(); /* already at or under the cap */
            var canvas = document.createElement('canvas');
            canvas.width = t.w; canvas.height = t.h;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, t.w, t.h);
            var hasAlpha = false;
            try {
              var data = ctx.getImageData(0, 0, t.w, t.h).data;
              for (var i = 3; i < data.length; i += 64) if (data[i] < 255) { hasAlpha = true; break; }
            } catch (e) { hasAlpha = true; } /* unknown → keep it lossless */
            resolve(canvas.toDataURL(imageMime(hasAlpha), 0.85));
          } catch (e2) { fallback(); }
        };
        img.src = dataUrl;
      } catch (e) { fallback(); }
    });
  }

  /* v1.29.0: the card's pictures besides the avatar get the same storage
     diet as the avatar — data-URLs down to a 512px long edge, web URLs
     (and anything undecodable) pass through untouched. Resolves with the
     (mutated) list, so the caller keeps one reference. */
  function normalizeCardImages(images) {
    var list = images || [];
    return Promise.all(list.map(function (im) {
      if (typeof im.src === 'string' && im.src.indexOf('data:image') === 0) {
        return normalizeDataUrl(im.src, 512).then(function (s) {
          if (s) im.src = s;
          return im;
        });
      }
      return Promise.resolve(im);
    }));
  }

  var Views = {};

  /* ================= PERSONA SWITCHER ================= */
  /* One-tap identity switching, shown on the Cast and Chats screens.
     Editing lives in Settings — the bar answers only "who am I right now?".
     Hidden entirely until you have created at least one persona, so nothing
     changes for anyone who never touches it. Every .persona-bar element in
     the document is filled from one place, so both screens stay in step. */
  function renderPersonaBar() {
    var bars = document.querySelectorAll('.persona-bar');
    if (!bars.length) return;
    var list = Store.personas || [];
    var active = (Store.settings && Store.settings.activePersona) || '';

    var defName = (Store.settings && Store.settings.defaultName) || 'You';
    var html =
      '<span class="persona-lbl">You are</span>' +
      '<button class="pchip' + (active ? '' : ' on') + '" data-persona="">' +
        icon('user') + esc(defName) + '</button>' +
      list.map(function (p) {
        /* v1.31.0: a persona with a photo shows its face in the chip. */
        var face = p.avatar
          ? '<img class="pchip-av" src="' + esc(p.avatar) + '" alt="">'
          : icon('user');
        return '<button class="pchip' + (active === p.id ? ' on' : '') + '" data-persona="' +
          esc(p.id) + '">' + face + esc(p.name || 'Unnamed') + '</button>';
      }).join('') +
      '<button class="pchip add" data-persona-new="1">' + icon('plus') + 'New</button>';

    bars.forEach(function (bar) {
      bar.hidden = list.length === 0;
      if (bar.hidden) { bar.innerHTML = ''; return; }
      bar.innerHTML = html;
      on(bar, '.pchip', 'click', function (e) {
        var el = e.currentTarget;
        if (el.getAttribute('data-persona-new')) return App.newPersona();
        App.switchTo(el.getAttribute('data-persona') || '');
      });
    });
  }
  Views.renderPersonaBar = function () { renderPersonaBar(); };

  /* ================= CAST ================= */
  Views.characters = function (root) {
    var q = (App.state.query || '').toLowerCase();
    var tag = App.state.tag || '';
    var list = Store.characters.filter(function (c) {
      var okQ = !q || (c.name || '').toLowerCase().indexOf(q) !== -1 ||
        (c.tagline || '').toLowerCase().indexOf(q) !== -1 ||
        (c.tags || []).join(' ').toLowerCase().indexOf(q) !== -1;
      var okT = !tag || (c.tags || []).indexOf(tag) !== -1;
      return okQ && okT;
    });

    var tags = {};
    Store.characters.forEach(function (c) { (c.tags || []).forEach(function (t) { tags[t] = (tags[t] || 0) + 1; }); });
    var tagNames = Object.keys(tags).sort(function (a, b) { return tags[b] - tags[a]; }).slice(0, 14);

    $('#tag-bar').innerHTML = tagNames.length
      ? '<button class="tag' + (tag ? '' : ' on') + '" data-tag="">All</button>' +
        tagNames.map(function (t) {
          return '<button class="tag' + (tag === t ? ' on' : '') + '" data-tag="' + esc(t) + '">' + esc(t) + '</button>';
        }).join('')
      : '';
    $('#tag-bar').hidden = !tagNames.length;
    on($('#tag-bar'), '.tag', 'click', function (e) {
      App.state.tag = e.currentTarget.getAttribute('data-tag');
      Views.characters(root);
    });

    renderPersonaBar();

    var grid = $('#char-grid');
    var empty = $('#char-empty');
    empty.hidden = Store.characters.length > 0;
    grid.hidden = list.length === 0;

    grid.innerHTML = list.map(function (c) {
      return '<div class="card" data-id="' + c.id + '">' +
        '<div class="card-art">' +
          (c.avatar ? '<img src="' + esc(c.avatar) + '" alt="">' :
            '<div class="ph">' + icon('user') + '</div>') +
          ((c.vh && c.vh.enabled)
            ? '<span class="badge-vh"><svg viewBox="0 0 24 24" style="width:10px;height:10px;stroke:currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg> living</span>'
            : '') +
          '<button class="card-menu" data-menu="' + c.id + '" aria-label="Options">' +
            '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>' +
          '</button>' +
        '</div>' +
        '<div class="card-body">' +
          '<div class="card-name">' + esc(c.name || 'Unnamed') + '</div>' +
          '<div class="card-sub">' + esc(c.tagline || (c.persona || '').slice(0, 90)) + '</div>' +
          ((c.tags && c.tags.length) ? '<div class="card-tags">' +
            c.tags.slice(0, 3).map(function (t) { return '<span class="mini-tag">' + esc(t) + '</span>'; }).join('') +
            '</div>' : '') +
        '</div>' +
      '</div>';
    }).join('');

    on(grid, '.card', 'click', function (e) {
      if (e.target.closest('[data-menu]')) return;
      App.openCharacter(e.currentTarget.getAttribute('data-id'));
    });
    on(grid, '[data-menu]', 'click', function (e) {
      e.stopPropagation();
      App.characterMenu(e.currentTarget.getAttribute('data-menu'));
    });
    on(empty, '[data-act=new-char]', 'click', function () { App.editCharacter(null); });
    on(empty, '[data-act=import-card]', 'click', App.importCard);
  };

  /* ================= LIFE (virtual humans) ================= */
  function needBar(label, text, value) {
    var pct = Math.round(Math.max(0, Math.min(1, value || 0)) * 100);
    return '<div class="meter"><span>' + esc(label) + '</span><b>' + esc(text) + '</b>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div></div>';
  }
  function signedBar(label, text, value) {
    var pct = Math.round((Math.max(-1, Math.min(1, value || 0)) + 1) / 2 * 100);
    return '<div class="meter"><span>' + esc(label) + '</span><b>' + esc(text) + '</b>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div></div>';
  }

  Views.life = function (root) {
    var body = $('#now-body');
    var all = Store.characters;
    if (!all.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>No one lives here yet</h3><p>Virtual humans are built on top of characters — create one first.</p>' +
        '<button class="btn primary" data-act="new">Create character</button>' +
        '<button class="btn ghost" data-act="import">Import a portable human</button></div>';
      on(body, '[data-act=new]', 'click', function () { App.editCharacter(null); });
      on(body, '[data-act=import]', 'click', App.importHuman);
      return;
    }
    var vhs = all.filter(function (c) { return c.vh && c.vh.enabled; });
    if (!vhs.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>No virtual humans yet</h3>' +
        '<p>Turn a character into a virtual human and they get a life of their own: places they go, ' +
        'needs that build up, other people, a diary, hours where they sleep instead of answering, ' +
        'and the habit of messaging you first.</p>' +
        '<button class="btn primary" data-act="pick">Choose a character</button>' +
        '<button class="btn ghost" data-act="import">Import a portable human</button></div>';
      on(body, '[data-act=pick]', 'click', App.pickVirtualHuman);
      on(body, '[data-act=import]', 'click', App.importHuman);
      return;
    }

    body.innerHTML = '<div class="hint" style="margin:0 2px 10px">Their day advances on real time — ' +
      'open the app after a few hours away and you may find messages waiting.</div>' +
      vhs.map(function (c) { return lifeCard(c); }).join('') +
      '<button class="btn ghost block sm" data-act="pick" style="margin-top:4px">' + icon('plus') + ' Make another character a virtual human</button>' +
      '<button class="btn ghost block sm" data-act="import" style="margin-top:6px">Import a portable human</button>';

    on(body, '[data-act=pick]', 'click', App.pickVirtualHuman);
    on(body, '[data-act=import]', 'click', App.importHuman);
    on(body, '[data-a]', 'click', function (e) {
      var id = e.currentTarget.closest('[data-vh]').getAttribute('data-vh');
      var a = e.currentTarget.getAttribute('data-a');
      Promise.resolve(Store.getCharacter(id)).then(function (c) {
        if (a === 'chat') App.openLatestOrNew(c.id);
        else if (a === 'nudge') App.nudge(c);
        else if (a === 'life') App.openLife(c);
        else if (a === 'feed') { App.state.feedFor = c.id; App.go('feed'); }
      });
    });
  };
  Views.now = Views.life;

  function lifeCard(c) {
    var L = VH.life(c);
    var st = L.summary, vh = c.vh, where = L.where;
    var last = L.bond.lastContact ? UI.fmtTime(L.bond.lastContact) : 'never';
    var ev = L.calendar.now || L.calendar.next;
    return '<div class="vh-card" data-vh="' + c.id + '">' +
      '<div class="vh-top">' +
        '<div class="vh-av">' + (c.avatar
          ? '<img src="' + esc(c.avatar) + '" alt="">'
          : '<div class="ph">' + esc(initials(c.name)) + '</div>') + '</div>' +
        '<div style="flex:1;min-width:0">' +
          '<div class="vh-name">' + esc(c.name) + '</div>' +
          '<div class="vh-status">' + esc(st.asleep ? 'Asleep' : (st.activity || 'Awake')) +
            (st.asleep ? ' · back around ' + esc(vh.sleep.end) : '') + '</div>' +
          '<div class="vh-when">' + esc(where.name) +
            (where.travelling ? ' · ' + where.minutesLeft + ' min away' : '') +
            ' · you last spoke ' + esc(last) + '</div>' +
        '</div>' +
      '</div>' +
      (ev ? '<div class="vh-note">' + icon('time') + ' <b>' + esc(ev.t) + '</b> ' + esc(ev.label) +
        (ev.placeId ? ' · ' + esc(VH.placeName(vh, ev.placeId)) : '') + '</div>' : '') +
      '<div class="meters">' +
        signedBar('Mood', st.moodLabel, st.mood) +
        signedBar('You two', L.bond.label + ' · ' + L.bond.persona, L.bond.affinity) +
        needBar('Energy', L.needs[0].label, L.needs[0].value) +
        needBar('Company', L.needs[2].label, L.needs[2].value) +
      '</div>' +
      '<div class="vh-note">Autonomous today: <b>' + L.spend.used + ' / ' + L.spend.cap + '</b>' +
        (L.spend.left ? '' : ' · budget spent, they will not message on their own until tomorrow') + '</div>' +
      (st.chronicle.length
        ? '<div class="chron">' + st.chronicle.slice(0, 3).map(function (b) {
            return '<div><b>' + esc(UI.fmtTime(b.ts)) + '</b> — ' + esc(b.text) + '</div>';
          }).join('') + '</div>'
        : '') +
      '<div class="vh-acts">' +
        '<button class="btn sm" data-a="chat">Open chat</button>' +
        '<button class="btn sm ghost" data-a="life">Their life</button>' +
        '<button class="btn sm ghost" data-a="feed">Feed</button>' +
        '<button class="btn sm ghost" data-a="nudge">Nudge</button>' +
      '</div>' +
    '</div>';
  }

  /* ---------------- the full life, in a sheet ---------------- */
  Views.lifeSheet = function (c) {
    var vh = VH.ensure(c), L = VH.life(c);
    var where = L.where;

    var people = L.people.length
      ? L.people.map(function (p) {
          return '<div class="person"><div class="person-av">' + esc((p.name || '?').slice(0, 1).toUpperCase()) + '</div>' +
            '<div style="flex:1;min-width:0"><div>' + esc(p.name) + '</div>' +
            '<div class="hint">' + esc(p.relation || 'person') + (p.note ? ' · ' + esc(p.note) : '') + '</div></div>' +
            '<span class="pill">' + esc(VH.relLabel((p.closeness || 0) * 2 - 1)) + '</span></div>';
        }).join('')
      : '<div class="hint">Nobody yet — add the people in their life from the character editor.</div>';

    var today = L.calendar.today.length
      ? L.calendar.today.map(function (e) {
          return '<div class="ev"><b>' + esc(e.t) + '</b> ' + esc(e.label) +
            (e.placeId ? ' · ' + esc(VH.placeName(vh, e.placeId)) : '') + '</div>';
        }).join('')
      : '<div class="hint">Nothing in the diary today.</div>';

    var perms = [
      ['message', 'Messages on their own'],
      ['photo', 'Photos on their own'],
      ['post', 'Posts to their feed'],
      ['travel', 'Going out and about']
    ].map(function (p) {
      return '<div class="field compact"><label>' + p[1] + '</label>' +
        '<div class="toggle' + (L.perms[p[0]] ? ' on' : '') + '" data-perm="' + p[0] + '"></div></div>';
    }).join('');

    return '' +
      '<div class="life-head">' +
        '<div class="life-where">' + esc(where.name) + '</div>' +
        '<div class="hint">' + esc(L.summary.activity || '') +
          (where.travelling ? ' · arriving in ' + where.minutesLeft + ' min' : '') + '</div>' +
      '</div>' +
      '<div class="group-title">Needs</div>' +
      '<div class="meters">' + L.needs.map(function (n) {
        return needBar(n.key[0].toUpperCase() + n.key.slice(1), n.label, n.value);
      }).join('') + '</div>' +
      '<div class="group-title">You two</div>' +
      '<div class="meters">' +
        signedBar('Relationship', L.bond.label, L.bond.affinity) +
        signedBar('Trust', L.bond.trust.toFixed(2), L.bond.trust) +
        signedBar('Tension', L.bond.tension.toFixed(2), L.bond.tension) +
      '</div>' +
      '<div class="hint">' + L.bond.exchanges + ' exchanges with ' + esc(L.bond.persona) + '.' +
        (L.personas.length > 1 ? ' They know ' + (L.personas.length - 1) + ' other persona(s) separately.' : '') + '</div>' +
      '<div class="group-title">People</div>' + people +
      '<div class="group-title">Today</div>' + today +
      '<div class="group-title">Autonomy</div>' + perms +
      '<div class="field"><div class="field-head"><label>Daily budget for autonomous messages</label>' +
        '<span class="spacer"></span><span class="val" id="cap-v">' + L.spend.cap + '</span></div>' +
        '<div class="range-row"><input type="range" id="vh-cap" min="0" max="40" step="1" value="' + L.spend.cap + '">' +
        '<span class="hint">' + L.spend.used + ' used today</span></div>' +
        '<div class="hint">Counts messages, photos and posts they send on their own. Your own replies and nudges are free.</div></div>' +
      '<div class="vh-acts">' +
        '<button class="btn sm ghost" data-l="export">Export life</button>' +
        '<button class="btn sm ghost" data-l="feed">Open feed</button>' +
      '</div>';
  };

  /* ================= FEED ================= */
  Views.feed = function (root) {
    var body = $('#feed-body');
    var vhs = Store.characters.filter(function (c) { return c.vh && c.vh.enabled; });
    var only = App.state.feedFor;
    if (only) vhs = vhs.filter(function (c) { return c.id === only; });

    var posts = [];
    vhs.forEach(function (c) {
      (c.vh.feed || []).forEach(function (p) { posts.push({ post: p, char: c }); });
    });
    posts.sort(function (a, b) { return (b.post.ts || 0) - (a.post.ts || 0); });

    if (!posts.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>Nothing posted yet</h3><p>When a virtual human sends you a photo or says something on ' +
        'their own, it shows up here — a record of the life outside your chat.</p>' +
        '<button class="btn ghost" data-act="life">Back to Life</button></div>';
      on(body, '[data-act=life]', 'click', function () { App.state.feedFor = null; App.go('life'); });
      return;
    }

    body.innerHTML = (only
        ? '<button class="btn ghost block sm" data-act="all" style="margin:0 2px 10px">Everyone’s feed</button>'
        : '') +
      posts.map(function (e) {
        var p = e.post, c = e.char;
        return '<div class="post" data-c="' + c.id + '">' +
          '<div class="post-head">' +
            '<div class="post-av">' + (c.avatar ? '<img src="' + esc(c.avatar) + '" alt="">' : esc(initials(c.name))) + '</div>' +
            '<div style="flex:1;min-width:0"><b>' + esc(c.name) + '</b>' +
            '<div class="hint">' + esc(UI.fmtTime(p.ts)) +
              (p.placeId ? ' · ' + esc(VH.placeName(c.vh, p.placeId)) : '') +
              (p.autonomous ? ' · sent on their own' : '') + '</div></div>' +
          '</div>' +
          (p.image ? '<img class="post-img" src="' + esc(p.image) + '" alt="">' : '') +
          (p.text ? '<div class="post-text">' + esc(p.text) + '</div>' : '') +
        '</div>';
      }).join('');

    on(body, '[data-act=all]', 'click', function () { App.state.feedFor = null; Views.feed($('.screen')); });
  };

  /* ================= CHATS ================= */
  Views.chats = function (root) {
    renderPersonaBar();
    var list = $('#chat-list'), empty = $('#chats-empty');
    Store.allSessions().then(function (all) {
      var chars = {};
      Store.characters.forEach(function (c) { chars[c.id] = c; });
      /* v1.39.0 chatwork: find-pin-archive. Hidden counts (search rows,
         archived piles) stay readable; nothing is ever deleted here. */
      var q = (App.state.chatSearch || '').trim().toLowerCase();
      var words = q ? q.split(/\s+/).filter(Boolean) : [];
      function matches(s) {
        if (!words.length) return true;
        var c = chars[s.charId] || { name: '' };
        var groupNames = (s.groupCharIds || []).map(function (id) { return chars[id] && chars[id].name; }).filter(Boolean);
        var hay = ((c.name || '') + ' ' + groupNames.join(' ') + ' ' + (s.title || '') + ' ' + (s.summary || '')).toLowerCase();
        if (words.every(function (w) { return hay.indexOf(w) !== -1; })) return true;
        return !!bodyHit(s);
      }
      /* v1.45.0: the titles-only filter could not find the chat where the boat got
         named, because the boat is 140 messages deep and the title is "New chat".
         The scan runs in the background (App.searchBodies) and paints itself in
         when it finishes, so typing stays instant and a chat with 600 messages
         never blocks the list. */
      var hits = null, scanning = false;
      if (q.length >= 3 && App.state.search && App.state.search.q === q) {
        hits = App.state.search.hits || {};
        scanning = !App.state.search.done;
      }
      function bodyHit(s) { return hits && hits[s.id] && hits[s.id].count ? hits[s.id] : null; }
      var archived = all.filter(function (s) { return s.archived; }).length;
      var sessions = all.filter(function (s) {
        return (App.state.showArchived || !s.archived) && matches(s);
      });
      /* pins ride first, newest first inside each pile (allSessions already
         sorts by updatedAt; Array.sort is stable in modern engines) */
      sessions = sessions.slice().sort(function (a, b) {
        return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0);
      });
      var searchEl = $('#chat-search');
      /* v1.45.0: the input shipped `hidden` in the markup in 1.39.0 and no code
         ever un hid it, so nobody has been able to reach the search at all.
         Below three chats it is still noise, so it stays out of the way. */
      if (searchEl) searchEl.hidden = all.length < 3;
      if (searchEl && searchEl.value !== (App.state.chatSearch || '')) {
        searchEl.value = App.state.chatSearch || '';
      }
      list.innerHTML = sessions.map(function (s) {
        var c = chars[s.charId] || { name: 'Deleted character' };
        var groupChars = (s.groupCharIds || []).map(function (id) { return chars[id]; }).filter(Boolean);
        var label = groupChars.length > 1 ? groupChars.map(function (x) { return x.name || 'Unnamed'; }).join(' + ') : c.name;
        return '<div class="item" data-open="' + s.id + '">' +
          '<div class="item-av">' + avatarHtml(c.avatar, c.name) + '</div>' +
          '<div class="item-main">' +
            '<div class="item-title">' + esc(label) + (groupChars.length > 1 ? ' <span class="item-badge">group</span>' : '') + ' <span style="color:var(--dim);font-weight:400">· ' + esc(s.title || 'New chat') + '</span>' +
              (s.pinned ? '<span class="item-badge">pinned</span>' : '') +
              (s.archived ? '<span class="item-badge">archived</span>' : '') +
            '</div>' +
            (bodyHit(s)
              ? '<div class="item-sub hitline"><span class="hit-where">' +
                  App.searchSnippet(bodyHit(s), words) +
                  '<span style="color:var(--dim)"> · ' + (bodyHit(s).count > 24 ? '24+' : bodyHit(s).count) +
                  ' matching message' + (bodyHit(s).count === 1 ? '' : 's') + '</span></span>' +
                  '<button class="chip" data-jump="' + esc(s.id) + ':' + esc(bodyHit(s).first) + '">Jump</button></div>'
              : '<div class="item-sub">' + esc(s.summary ? s.summary.slice(0, 90) : (s.messageCount || 0) + ' messages') + '</div>') +
          '</div>' +
          '<div class="item-side">' + esc(UI.fmtTime(s.updatedAt)) +
            '<button class="chip" style="margin-left:6px" data-menu="' + s.id + '">' +
              '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>' +
            '</button>' +
          '</div>' +
        '</div>';
      }).join('') +
      (archived && !App.state.showArchived
        ? '<div class="field"><button class="btn ghost block sm" data-act="show-archived">Show archived (' + archived + ')</button></div>'
        : (App.state.showArchived && archived ? '<div class="field"><button class="btn ghost block sm" data-act="hide-archived">Hide archived</button></div>' : '')) +
      (!sessions.length && archived && !App.state.showArchived ? '' :
        (!sessions.length && (q || all.length)
          ? '<div class="field"><span class="hint">' + (q ? 'No chats match \"' + esc(q) + '\" as ' + esc(Store.personaLabel()) + '.' : '') + '</span></div>'
          : ''));
      /* The box now reads the messages themselves, which is the slower half, so
         the empty result has to say whether it looked and found nothing, or gave
         up before it got there. */
      if (!sessions.length && q.length >= 3 && App.state.search && App.state.search.done) {
        var hintRow = list.querySelector('.field .hint');
        if (hintRow) {
          hintRow.insertAdjacentHTML('beforeend',
            ' Nothing in the messages either' +
            (App.state.search.capped ? ' — the read stopped early, so try a longer phrase' : '') + '.');
        }
      }
      empty.hidden = sessions.length > 0;
      if (!empty.hidden) {
        /* An empty list is usually not data loss: every persona keeps its
           own chats. If another identity has conversations, say so. */
        Store.sessionTotal().then(function (total) {
          if (total > 0 && !empty.hidden) {
            var h3 = empty.querySelector('h3'), p = empty.querySelector('p');
            if (h3) h3.textContent = 'No conversations as ' + Store.personaLabel();
            if (p) p.textContent = 'Nothing was lost — your other conversations live under a different identity. Switch to it with the bar above.';
          }
        });
      }
      if (scanning) {
        list.insertAdjacentHTML('beforeend', '<div class="field"><span class="hint" style="display:block">' +
          App.searchProgress() + '</span></div>');
      }
      on(list, '[data-jump]', 'click', function (e) {
        e.preventDefault(); e.stopPropagation();
        var bits = String(e.currentTarget.getAttribute('data-jump') || '').split(':');
        if (bits.length === 2) App.openSession(bits[0], { focusMid: bits[1] });
      });
      on(list, '[data-act=show-archived]', 'click', function () {
        App.state.showArchived = true; Views.chats(root);
      });
      on(list, '[data-act=hide-archived]', 'click', function () {
        App.state.showArchived = false; Views.chats(root);
      });
      on(list, '[data-open]', 'click', function (e) {
        if (e.target.closest('[data-menu]') || e.target.closest('[data-jump]')) return;
        App.openSession(e.currentTarget.getAttribute('data-open'));
      });
      on(list, '[data-menu]', 'click', function (e) {
        e.stopPropagation();
        App.sessionMenu(e.currentTarget.getAttribute('data-menu'));
      });
    });
  };

  /* ================= WORLD ================= */
  Views.world = function (root) {
    var body = $('#world-body');
    var chars = Store.characters;
    if (!chars.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('brain') + '</div>' +
        '<h3>No world yet</h3><p>Create a character first — worlds and memories hang off them.</p></div>';
      return;
    }
    var id = App.state.worldChar || chars[0].id;
    var c = chars.find(function (x) { return x.id === id; }) || chars[0];
    App.state.worldChar = c.id;

    /* D3: what the sheet costs on every single turn. */
    var sheetTokens = API.estTokens([c.persona, c.scenario, c.greeting, c.examples, c.postHistory]
      .filter(Boolean).join('\n\n'));

    body.innerHTML =
      '<div class="tag-bar">' + chars.map(function (x) {
        return '<button class="tag' + (x.id === c.id ? ' on' : '') + '" data-wc="' + x.id + '">' + esc(x.name || 'Unnamed') + '</button>';
      }).join('') + '</div>' +

      /* C2/D3 (v1.39.71): the sheet size and, per entry, whether it is in the
         prompt this turn and why not. "Why is my card ignored" becomes a
         readout instead of guesswork. The sample is the last few messages of
         the newest conversation with this character — the same text loreHits
         scans — and it is loaded below, so nothing here guesses at it. */
      '<div class="group"><div class="group-title">Character sheet · ' + esc(c.name || 'Unnamed') + '</div>' +
        '<div class="hint" style="margin:0 0 6px">About <b>' + sheetTokens + ' tokens</b> of character text ' +
        'is sent on every turn (persona, scenario, greeting, examples, post-history note). ' +
        'It is never trimmed, so a very large sheet costs context on every reply.</div></div>' +

      '<div class="group"><div class="group-title">Lorebook · ' + esc(c.name || 'Unnamed') + '</div>' +
        '<div class="hint" style="margin:0 0 6px" id="lore-summary">' +
          ((c.lorebook && c.lorebook.length) ? 'Checking the newest conversation…' : 'No lore entries yet.') +
        '</div>' +
        '<div id="lore-list">' + ((c.lorebook && c.lorebook.length)
          ? '<div class="field"><span class="hint">Loading…</span></div>' : '') + '</div>' +
        '<div class="field"><button class="btn ghost block sm" data-act="lore-add">' +
          icon('plus') + ' Add lore entry</button></div>' +
      '</div>' +

      '<div class="group"><div class="group-title">Story memory</div>' +
        '<div class="field"><div class="hint" style="margin:0">Memory is stored per conversation. It gets injected into ' +
        'the prompt so long chats stay coherent without sending the whole transcript.</div></div>' +
        '<div id="mem-list"><div class="field"><span class="hint">Loading…</span></div></div>' +
      '</div>';

    on(body, '[data-wc]', 'click', function (e) {
      App.state.worldChar = e.currentTarget.getAttribute('data-wc');
      Views.world(root);
    });
    on(body, '[data-act=lore-add]', 'click', function () { App.editLore(c, null); });

    /* C2: fill the lorebook readout from the newest conversation's messages. */
    Store.getSessions(c.id).then(function (sessions) {
      var list = $('#lore-list'), summary = $('#lore-summary');
      if (!list || !summary) return;
      var newest = (sessions || [])[0];
      if (!newest) {
        summary.innerHTML = 'Open a conversation with ' + esc(c.name || 'this character') +
          ' and this list will show which entries are in the prompt.';
        list.innerHTML = '';
        return;
      }
      return Store.getMessages(newest.id).then(function (msgs) {
        /* v1.39.74: the same window the request uses — loreSample over the
           stored history — so the readout and the prompt cannot disagree. */
        /* v1.40.0: the readout uses the character's own window and the
           character's own matching options, so what this screen reports is the
           request - not a recomputation with app defaults that a card-with-
           settings character never uses. */
        var sample = API.loreSample(msgs || [], API.loreScanTurns(c));
        var stage = newest.continuity && newest.continuity.enabled ? newest.continuity.stage : '';
        /* v1.39.110: read the ceilings from the engine. These were literals
           here, so when the prompt moved to 10 entries / 5000 bytes this
           screen kept reporting 6 / 1536 - it told the author that entries
           were "over the byte budget" which the request was happily sending. */
        var diag = API.loreDiagnostics(c.lorebook || [], sample, API.LORE_LIMIT, API.LORE_BUDGET,
          stage, API.loreOpts(c));
        var stageNote = '';
        if (diag.stageSkipped) {
          /* A staged book with no stage set is dark in every chat. Without
             this line the author sees "3 of 28 in the prompt", every row
             disagreeing with them, and concludes the lorebook is broken. */
          stageNote = '<div style="margin-top:6px;color:var(--warn,#fbbf24)">' +
            (diag.stageBlank
              ? '<b>' + diag.stageSkipped + '</b> ' + (diag.stageSkipped === 1 ? 'entry is' : 'entries are') +
                ' hidden because this chat has <b>no stage set</b>. Staged entries only appear when the ' +
                'chat’s stage matches theirs exactly — open Chat continuity on this conversation and ' +
                'set one, or clear the stage on those entries to make them available everywhere.'
              : '<b>' + diag.stageSkipped + '</b> ' + (diag.stageSkipped === 1 ? 'entry belongs' : 'entries belong') +
                ' to another stage and ' + (diag.stageSkipped === 1 ? 'is' : 'are') + ' hidden here ' +
                '(this chat is in <b>' + esc(diag.stage || '') + '</b>).') +
            '</div>';
        }
        /* the window and the mode are part of the answer. Without them a reader
           comparing two characters sees the same ceiling and concludes the
           matcher is inconsistent. */
        var modeNote = ' Scanning the last <b>' + diag.turns + '</b> ' +
          (diag.turns === 1 ? 'turn' : 'turns') + (diag.compat
            ? ', in the card’s own lore order' : '') + '.';
        var cutNote = '';
        var budgetCut = '<b>' + diag.droppedByBudget + '</b> ' +
          (diag.droppedByBudget === 1 ? 'entry matched but did' : 'entries matched but did') +
          ' not fit the byte budget' +
          (diag.droppedEssential
            ? ' — including <b>' + diag.droppedEssential + '</b> marked essential, which the budget ' +
              'cannot exempt: an entry that must be present belongs in the character sheet, not the lorebook'
            : '');
        var limitCut = '<b>' + diag.droppedByLimit + '</b> ' +
          (diag.droppedByLimit === 1 ? 'entry matched but' : 'entries matched but') +
          ' passed the ' + diag.limit + '-entry limit';
        /* v1.42.2: lead with whichever ceiling actually cost more, and name both
           when both bit. This was a plain if/else on the budget counter, so a book
           trimmed mainly by the 10-entry limit was told to shrink entries or raise
           the budget — a dial that cannot help while the limit is what is full. */
        var cuts = [];
        if (diag.droppedByLimit) cuts.push({ n: diag.droppedByLimit, text: limitCut });
        if (diag.droppedByBudget) cuts.push({ n: diag.droppedByBudget, text: budgetCut });
        cuts.sort(function (a, b) { return b.n - a.n; });
        if (cuts.length) cutNote = ' ' + cuts.map(function (c) { return c.text; }).join('; ') + '.';
        summary.innerHTML = 'Checking the conversation “' + esc(newest.title || 'New chat') +
          '”. <b>' + diag.admitted + ' of ' + diag.rows.length + '</b> ' +
          (diag.rows.length === 1 ? 'entry is' : 'entries are') + ' in the prompt now · ' +
          diag.used + ' of ' + diag.cap + ' bytes used.' + modeNote + cutNote + stageNote;
        list.innerHTML = diag.rows.length ? diag.rows.map(function (r, i) {
          return '<div class="kv" data-lore="' + i + '" style="cursor:pointer;align-items:flex-start">' +
            '<span style="flex:1">' +
              '<b style="display:block;color:' + (r.matched ? 'var(--text)' : 'var(--dim)') + '">' +
                esc((r.keys || []).join(', ') || '(no keys)') + '</b>' +
              '<span style="font-size:12px">' + esc((r.content || '').slice(0, 70)) + '</span>' +
              /* v1.40.0: the flags the matcher now reads, on the row that made
                 the entry behave that way, plus the one field it cannot read. */
              (r.essential || r.caseSensitive || r.selective || r.ignored || r.insertionOrder !== null
                ? '<span style="display:block;font-size:11px;margin-top:2px;color:var(--dim)">' +
                  [r.essential ? 'essential' : '', r.caseSensitive ? 'case-sensitive' : '',
                   r.selective ? 'needs a second key' : '',
                   r.insertionOrder !== null ? 'order ' + esc(String(r.insertionOrder)) : '',
                   r.position ? esc(r.position) : '',
                   r.ignored ? '<span style="color:var(--warn,#fbbf24)">' + esc(r.ignored) + ' not applied</span>' : ''
                  ].filter(Boolean).join(' · ') + '</span>'
                : '') +
              '<span style="display:block;font-size:11.5px;margin-top:2px;color:' +
                (r.matched ? 'var(--ok,#4ade80)' : 'var(--dim)') + '">' +
                (r.matched ? '✓ ' : '✕ ') + esc(r.reason || '') + '</span>' +
            '</span></div>';
        }).join('') : '<div class="field"><span class="hint">No lore entries yet.</span></div>';
      });
    });

    on(body, '[data-lore]', 'click', function (e) {
      App.editLore(c, parseInt(e.currentTarget.getAttribute('data-lore'), 10));
    });

    Store.getSessions(c.id).then(function (sessions) {
      var el = $('#mem-list');
      if (!sessions.length) {
        el.innerHTML = '<div class="field"><span class="hint">No conversations with this character yet.</span></div>';
        return;
      }
      el.innerHTML = sessions.map(function (s) {
        return '<div class="kv" data-mem="' + s.id + '" style="cursor:pointer">' +
          '<span style="flex:1"><b style="display:block">' + esc(s.title || 'New chat') + '</b>' +
          '<span style="font-size:12px">' + esc(s.summary ? s.summary.slice(0, 80) : 'No summary yet') + '</span></span>' +
          '<span style="color:var(--dim);font-size:11px">' + (s.facts ? s.facts.length : 0) + ' facts</span>' +
        '</div>';
      }).join('');
      on(el, '[data-mem]', 'click', function (e) {
        App.memorySheet(e.currentTarget.getAttribute('data-mem'));
      });
    });
  };

  /* ================= PERSONAS (dedicated management screen, v1.15.0) ===== */
  /* The persona list used to live inline in Settings, where every identity
     made the screen longer. It now has its own screen; Settings keeps a
     fixed-length "Manage personas" button. Rows are shared (personaRowsHtml)
     so the screen and the bar/Settings stay consistent. */
  function personaRowsHtml(personas, activeId) {
    return personas.length
      ? personas.map(function (p) {
          var on = activeId === p.id;
          return '<div class="field" data-prow="' + esc(p.id) + '">' +
            '<div class="field-head">' +
              /* v1.31.0: the persona's own photo - tap to import a picture,
                 the small dot removes it. Initials until one is set. */
              '<span class="pavat-wrap">' +
                '<button class="pavat" data-persona-av="' + esc(p.id) + '" title="Set or change the photo" aria-label="' + esc('Set photo for ' + (p.name || 'persona')) + '">' + avatarHtml(p.avatar || '', p.name) + '</button>' +
                (p.avatar ? '<button class="pavat-x" data-persona-avdel="' + esc(p.id) + '" aria-label="Remove photo">\u00d7</button>' : '') +
              '</span>' +
            '<label>' + esc(p.name || 'Unnamed persona') + '</label>' +
              '<span class="spacer"></span>' +
              (on ? '<span class="pill ok">active</span>'
                  : '<button class="chip" data-persona-use="' + esc(p.id) + '">Switch to</button>') +
              '<button class="chip" data-persona-del="' + esc(p.id) + '" aria-label="Delete persona">' + icon('trash') + '</button>' +
            '</div>' +
            '<input type="text" data-persona-name="' + esc(p.id) + '" value="' + esc(p.name || '') + '" placeholder="Persona name">' +
            '<textarea data-persona-text="' + esc(p.id) + '" style="margin-top:6px" placeholder="Who this persona is — appearance, background, goals.">' + esc(p.text || '') + '</textarea>' +
          '</div>';
        }).join('')
      : '<div class="field"><span class="hint">No personas yet. Add one to switch between identities — each keeps its own chats with every character and its own relationship with each virtual human.</span></div>';
  }

  Views.personas = function (root) {
    var personas = Store.personas || [];
    var activeId = (Store.settings && Store.settings.activePersona) || '';
    var body = $('#personas-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Identities</div>' +
        '<div class="field"><div class="hint" style="margin:0">Each persona keeps its own chats with every character, and its own relationship with each virtual human. Names and descriptions save when you leave the field. The identity bar at the top of Cast and Chats switches personas too.</div></div>' +
        personaRowsHtml(personas, activeId) +
        '<button class="btn ghost sm" id="btn-persona-add" style="margin-top:8px">' + icon('plus') + ' Add persona</button>' +
      '</div>';
    function bind(sel, ev, fn) { var el = $(sel, body); if (el) el.addEventListener(ev, fn); }
    on(body, '[data-persona-use]', 'click', function (e) {
      App.switchTo(e.currentTarget.getAttribute('data-persona-use'));
    });
    on(body, '[data-persona-del]', 'click', function (e) {
      App.deletePersona(e.currentTarget.getAttribute('data-persona-del'));
    });
    on(body, '[data-persona-name]', 'change', function (e) {
      App.editPersona(e.currentTarget.getAttribute('data-persona-name'), { name: e.target.value.trim() });
    });
    on(body, '[data-persona-text]', 'change', function (e) {
      App.editPersona(e.currentTarget.getAttribute('data-persona-text'), { text: e.target.value });
    });
    /* v1.31.0: import a photo for the persona. The picture goes through the
       image normalizer like every imported image, and the row's thumb and
       remove dot update in place instead of re-rendering the screen. */
    function personaById(id) {
      return (Store.personas || []).find(function (x) { return x.id === id; });
    }
    function detachPhoto(xbtn) {
      var id = xbtn.getAttribute('data-persona-avdel');
      App.editPersona(id, { avatar: '' });
      var btn = body.querySelector('[data-persona-av="' + id + '"]');
      var p = personaById(id);
      if (btn) btn.innerHTML = avatarHtml('', p && p.name, '');
      if (xbtn.remove) xbtn.remove();
    }
    on(body, '[data-persona-av]', 'click', function (e) {
      var id = e.currentTarget.getAttribute('data-persona-av');
      pickFile('image/*').then(function (f) {
        if (!f) return;
        normalizeImage(f).then(function (d) {
          if (!d) { UI.toast('Could not read that image'); return; }
          App.editPersona(id, { avatar: d });
          var btn = body.querySelector('[data-persona-av="' + id + '"]');
          if (!btn) return;
          btn.innerHTML = avatarHtml(d, '', '');
          var wrap = btn.parentNode;
          if (wrap && !wrap.querySelector('.pavat-x')) {
            var x = document.createElement('button');
            x.className = 'pavat-x';
            x.setAttribute('data-persona-avdel', id);
            x.setAttribute('aria-label', 'Remove photo');
            x.textContent = '\u00d7';
            x.addEventListener('click', function () { detachPhoto(x); });
            wrap.appendChild(x);
          }
        });
      });
    });
    on(body, '[data-persona-avdel]', 'click', function (e) { detachPhoto(e.currentTarget); });
    bind('#btn-persona-add', 'click', function () { App.newPersona(); });
  };

  /* ================= SETTINGS ================= */
  /* v1.16.0: Settings is a hub. Every group lives on its own sub-screen —
     one shared settings-x section rendered per section — so the hub stays
     the same length no matter what is inside. "About" stays in the hub as
     a footer: it is status, not a setting. The per-persona rows live on
     Views.personas (v1.15.0), reached from the hub too. */
  Views.SETTINGS_SECTIONS = {
    appearance: { title: 'Appearance', hint: 'Theme colors', icon: 'palette', view: 'settingsAppearance' },
    connection: { title: 'Connection', hint: 'Provider, API key, model', icon: 'key', view: 'settingsConnection' },
    generation: { title: 'Generation', hint: 'Temperature, reply length, context', icon: 'sparkle', view: 'settingsGeneration' },
    you:        { title: 'You', hint: 'Your name and identity', icon: 'user', view: 'settingsYou' },
    system:     { title: 'System prompt', hint: 'Rules sent with every message', icon: 'chat', view: 'settingsSystem' },
    horde:      { title: 'Image generation & AI Horde', hint: 'Choose an image provider and configure Horde', icon: 'image', view: 'settingsHorde' },
    memory:     { title: 'Memory', hint: 'Auto-summarise long chats', icon: 'brain', view: 'settingsMemory' },
    data:       { title: 'Data', hint: 'Backup, restore, erase', icon: 'download', view: 'settingsData' },
    storage:    { title: 'Storage', hint: 'What the app is holding', icon: 'copy', view: 'settingsStorage' },
    update:     { title: 'App updates', hint: 'Version, update address', icon: 'refresh', view: 'settingsUpdate' }
  };

  /* Control wiring shared by the settings sub-screens. Everything is scoped
     to the sub-screen's body, so control ids can never collide. */
  function settingsScope(body) {
    function bind(sel, ev, fn) { var el = $(sel, body); if (el) el.addEventListener(ev, fn); }
    function set(patch) { Store.saveSettings(patch); }
    function range(sel, valSel, key, fmt) {
      var el = $(sel, body);
      if (!el) return;
      el.addEventListener('input', function () {
        var v = parseFloat(el.value);
        if (valSel) $(valSel, body).textContent = fmt ? fmt(v) : v;
        var patch = {}; patch[key] = v; set(patch);
      });
    }
    function toggle(sel, key, after) {
      var el = $(sel, body);
      if (!el) return;
      el.addEventListener('click', function () {
        var patch = {}; patch[key] = !Store.settings[key]; set(patch);
        el.classList.toggle('on', Store.settings[key]);
        if (after) after();
      });
    }
    return { bind: bind, set: set, range: range, toggle: toggle };
  }

  /* Version / update-channel facts shared by the hub (About) and the
     App-updates screen. */
  /* v1.39.82: the history budget, and what the model's own window does to it. */
  function historyTokens(s) {
    var n = parseInt(s && s.historyTokens, 10);
    return n > 0 ? n : (API.DEFAULT_HISTORY_TOKENS || 6000);
  }
  function historyWindowNote(s) {
    var win = API.modelContextTokens ? API.modelContextTokens(s && s.model) : 0;
    if (win) {
      return 'Your model (' + esc(s.model) + ') takes <b>' + win.toLocaleString() + ' tokens</b> in total. ' +
        'If the sheet and the reply leave less room than the budget above, the app shrinks the budget to fit — ' +
        'a prompt bigger than the window gets truncated by the provider, and then the character answers the ' +
        'start of the conversation forever.';
    }
    return 'The app does not know this model\'s window yet. Open Choose model once while online and it will ' +
      'learn it, then fit this budget inside it automatically.';
  }
  Views.historyWindowNote = historyWindowNote;

  function settingsUpdateInfo() {
    var U = global.Updates;
    var upInfo = (U && U.supported()) ? U.info() : { apk: '?', apkCode: 0, overlay: false, rev: '' };
    var upUrl = U ? (U.baseUrl() || U.DEFAULT_URL || '') : '';
    var verLabel = (upInfo.apk && upInfo.apk !== '?') ? upInfo.apk : (Store.VERSION || 'unknown');
    if (upInfo.overlay && upInfo.rev) verLabel += ' · files ' + upInfo.rev;
    var upNote = '';
    try {
      var blocked = localStorage.getItem('hs.blockedRev');
      if (blocked) upNote += 'The last update was rolled back automatically because the app never started on it. ';
    } catch (e) { }
    if (!U || !U.supported()) {
      upNote += 'Self-updating needs the newest APK installed once — after that this screen does the rest.';
    } else {
      upNote += 'Nothing is downloaded unless you press Check for update.';
    }
    return { U: U, upInfo: upInfo, upUrl: upUrl, verLabel: verLabel, upNote: upNote };
  }

  /* The hub: one row per section, plus About. Fixed length (v1.16.0). */
  Views.settings = function (root) {
    var s = Store.settings;
    var info = settingsUpdateInfo();
    var personas = Store.personas || [];
    /* v1.26.1: 'appearance' was registered in SETTINGS_SECTIONS but missed
       from this ORDER list, so the hub never drew its row. */
    var ORDER = ['appearance', 'connection', 'generation', 'you', 'personas', 'system', 'horde', 'memory', 'data', 'storage', 'update'];
    var rows = ORDER.map(function (k) {
      var label, hint, ic;
      if (k === 'personas') {
        label = 'Manage personas' + (personas.length ? ' · ' + personas.length : '');
        hint = 'Switchable identities — each keeps its own chats';
        ic = 'user';
      } else {
        var m = Views.SETTINGS_SECTIONS[k];
        label = m.title; hint = m.hint; ic = m.icon;
      }
      return '<div class="field">' +
        '<button class="btn ghost sm block" data-gosec="' + k + '" style="display:flex;align-items:center;gap:10px">' +
          icon(ic) +
          '<span style="flex:1;text-align:left"><b>' + label + '</b>' +
          '<span class="hint" style="display:block">' + hint + '</span></span>' +
          '<span style="color:var(--dim);font-size:18px;line-height:1">›</span>' +
        '</button></div>';
    }).join('');
    $('#settings-body').innerHTML =
      '<div class="group">' +
        '<div class="group-title">Settings</div>' +
        rows +
      '</div>' +
      /* --- about (status, not a setting — stays in the hub) --- */
      '<div class="group">' +
        '<div class="group-title">About</div>' +
        '<div class="field"><div class="kv"><span>Version</span><b>' + esc(info.verLabel) + ' · mobile</b></div>' +
        '<div class="kv"><span>Text</span><b>' + esc(s.provider === 'horde' ? 'AI Horde (free)' : (Store.PRESETS[s.provider] || {}).label || 'Custom') + '</b></div>' +
        '<div class="kv"><span>Images</span><b>' + esc(s.imageProvider === 'cloudflare' ? 'Cloudflare Workers AI' : s.imageProvider === 'pollinations' ? 'Pollinations Classic' : 'AI Horde') + '</b></div>' +
        '<div class="hint">Horde Studio Mobile is an unofficial, mobile-first client. It talks to whatever backend you configure — ' +
        'nothing is sent anywhere except your chosen provider.</div></div>' +
      '</div>';
    var body = $('#settings-body');
    on(body, '[data-gosec]', 'click', function (e) {
      var k = e.currentTarget.getAttribute('data-gosec');
      if (k === 'personas') return App.go('personas');
      App.openSettings(k);
    });
  };

  /* ---- Connection ---- */
  Views.settingsConnection = function (root) {
    var s = Store.settings;
    var preset = Store.PRESETS[s.provider] || Store.PRESETS.custom;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Connection</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Provider</label></div>' +
          '<select id="set-provider">' +
            Object.keys(Store.PRESETS).map(function (k) {
              return '<option value="' + k + '"' + (k === s.provider ? ' selected' : '') + '>' +
                esc(Store.PRESETS[k].label) + '</option>';
            }).join('') +
          '</select>' +
          '<div class="hint" id="preset-note">' + esc(preset.note) + '</div>' +
        '</div>' +
        '<div class="field" id="url-field"' + (s.provider === 'horde' ? ' hidden' : '') + '>' +
          '<div class="field-head"><label>API base URL</label></div>' +
          '<input type="url" id="set-url" value="' + esc(s.baseUrl) + '" placeholder="https://…/v1" autocapitalize="off" autocorrect="off" spellcheck="false">' +
        '</div>' +
        '<div class="field"' + (s.provider === 'horde' ? ' hidden' : '') + '>' +
          '<div class="field-head"><label>API key</label></div>' +
          '<input type="password" id="set-key" value="' + esc(s.apiKey) + '" placeholder="' +
            (preset.keyRequired ? 'sk-…' : 'leave blank if not needed') + '" autocapitalize="off" autocorrect="off" spellcheck="false">' +
          '<div class="hint">Stored only in this app’s private storage on your phone. Never included in exports.</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Model</label></div>' +
          '<div class="row">' +
            '<button class="btn ghost sm" id="btn-model" style="flex:1;text-align:left">' + esc(s.model || 'Tap to choose a model') + '</button>' +
            '<button class="btn ghost sm" id="btn-refresh-models" title="Refresh list">' + icon('refresh') + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="row">' +
            '<button class="btn ghost sm" style="flex:1" id="btn-test">' + icon('key') + ' Test connection</button>' +
          '</div>' +
          '<div class="hint" id="test-out"></div>' +
        '</div>' +
      '</div>' +
      (s.provider === 'openrouter' && /^https:\/\/openrouter\.ai(?:\/|$)/i.test(String(s.baseUrl || ''))
        ? '<div class="group"><div class="group-title">OpenRouter quota &amp; route health</div>' +
          '<div class="field"><div class="row">' +
            '<button class="btn ghost sm" id="btn-or-refresh" style="flex:1"' + (!s.apiKey ? ' disabled' : '') + '>Refresh account quota</button>' +
            '<button class="btn ghost sm" id="btn-or-probe" style="flex:1"' + (!s.apiKey || !s.model ? ' disabled' : '') + '>Test selected model</button>' +
          '</div><div class="hint">Selected model: <b>' + esc(s.model || 'none selected') + '</b>. The model test sends one short request and may use one free-model request. It tests the selected route now; it does not guarantee future availability.</div></div>' +
          '<div class="field"><div id="or-quota-status" class="hint">Checking OpenRouter…</div>' +
            '<div id="or-quota-countdown" class="kv" hidden><span>Daily reset</span><b></b></div>' +
            '<div id="or-quota-credits" class="kv" hidden><span>API-key credit cap remaining</span><b></b></div>' +
            '<div class="hint" id="or-quota-checked"></div>' +
            '<div id="or-local-usage"></div>' +
            '<div id="or-probe-result" class="hint" aria-live="polite"></div>' +
            '<div id="or-recent-activity"></div>' +
          '</div></div>'
        : '');
    var sc = settingsScope(body);
    sc.bind('#set-provider', 'change', function (e) {
      var p = e.target.value;
      sc.set({ provider: p, baseUrl: Store.PRESETS[p].url });
      Views.settingsConnection(root);
    });
    sc.bind('#set-url', 'change', function (e) { sc.set({ baseUrl: e.target.value.trim() }); });
    sc.bind('#set-key', 'change', function (e) {
      sc.set({ apiKey: e.target.value.trim() });
      if (Store.settings.provider === 'openrouter') Views.settingsConnection(root);
    });
    sc.bind('#btn-test', 'click', function () {
      var out = $('#test-out', body);
      out.innerHTML = '<span class="pill">Testing…</span>';
      API.testConnection(Store.settings).then(function (r) {
        out.innerHTML = '<span class="pill ' + (r.ok ? 'ok' : 'err') + '">' + esc(r.message) + '</span>';
      });
    });
    sc.bind('#btn-refresh-models', 'click', function () { App.chooseModel(true); });
    sc.bind('#btn-model', 'click', function () { App.chooseModel(false); });

    if (s.provider === 'openrouter' && /^https:\/\/openrouter\.ai(?:\/|$)/i.test(String(s.baseUrl || ''))) {
      if (openRouterQuotaClock) clearInterval(openRouterQuotaClock);
      if (openRouterQuotaPoll) clearInterval(openRouterQuotaPoll);
      var quotaInfo = null;
      function isVisible() {
        var screen = $('[data-screen="settings-x"]');
        return !!(screen && !screen.hidden && Store.settings.provider === 'openrouter');
      }
      function renderCountdown() {
        var row = $('#or-quota-countdown', body);
        if (!row || !quotaInfo || !quotaInfo.resetsAt) return;
        row.hidden = false;
        var ms = Math.max(0, quotaInfo.resetsAt - Date.now()), sec = Math.floor(ms / 1000);
        var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), r = sec % 60;
        var text = (h ? h + 'h ' : '') + (m ? m + 'm ' : '') + r + 's';
        var reset = new Date(quotaInfo.resetsAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        row.querySelector('b').textContent = text + ' · ' + reset + ' local';
      }
      function renderLocalActivity() {
        var usageBox = $('#or-local-usage', body), recentBox = $('#or-recent-activity', body);
        if (!usageBox || !recentBox) return;
        var totals = API.openRouterActivityToday(Store.settings);
        usageBox.innerHTML = '<div class="kv"><span>Generation calls logged on this phone today</span><b>' + totals.requests + ' · ' + totals.successes + ' succeeded · ' + totals.failures + ' failed</b></div>' +
          '<div class="kv"><span>Reported tokens today (this app)</span><b>' + (totals.tokenReports
            ? totals.promptTokens.toLocaleString() + ' in · ' + totals.completionTokens.toLocaleString() + ' out'
            : 'No token-usage data reported yet') + '</b></div>' +
          '<div class="hint">These are logical calls and token totals observed on this phone, not an OpenRouter token allowance. The account-wide counter above is authoritative; failed or interrupted calls may not return token counts.</div>';
        var events = API.openRouterActivity(Store.settings).slice(0, 5);
        recentBox.innerHTML = '<div class="field-head" style="margin-top:10px"><label>Recent route results</label></div>' +
          (events.length ? events.map(function (x) {
            var time = new Date(x.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            var label = x.diagnosis || (x.kind === 'success' ? 'Completed' : x.kind);
            var pill = x.kind === 'success' ? 'ok' : (x.kind === 'timeout' || x.kind === 'provider_limit' || x.kind === 'account_limit' || x.kind === 'ambiguous_limit' ? 'warn' : 'err');
            return '<div class="kv"><span>' + esc(time + ' · ' + (x.model || 'model')) + '</span><b><span class="pill ' + pill + '">' + esc(label) + '</span></b></div>' +
              (x.message ? '<div class="hint">' + esc(x.message) + (x.provider ? ' · route: ' + esc(x.provider) : '') + '</div>' : '');
          }).join('') : '<div class="hint">No generation calls logged by this app today.</div>');
      }
      function refreshQuota() {
        var status = $('#or-quota-status', body), button = $('#btn-or-refresh', body);
        if (!status) return Promise.resolve();
        if (button) button.disabled = true;
        if (!Store.settings.apiKey) { status.innerHTML = '<span class="pill warn">Add your OpenRouter API key to view quota.</span>'; return Promise.resolve(); }
        status.innerHTML = '<span class="pill">Checking account quota…</span>';
        return API.openRouterKeyStatus(Store.settings).then(function (info) {
          quotaInfo = info;
          var d = info.data, free = d.free_model_daily_requests;
          if (free && typeof free.remaining === 'number') {
            status.innerHTML = '<span class="pill ' + (free.remaining > 0 ? 'ok' : 'warn') + '">Free-model requests: ' +
              esc(String(free.used)) + ' used / ' + esc(String(free.limit)) + ' today · ' + esc(String(free.remaining)) + ' remaining</span>' +
              '<div class="hint">Account-wide counter from OpenRouter. Model-provider throttling is separate and can happen even while requests remain.</div>';
          } else {
            status.innerHTML = '<span class="pill warn">OpenRouter did not report a free-model daily counter for this key.</span>';
          }
          var creditRow = $('#or-quota-credits', body);
          if (creditRow && typeof d.limit_remaining === 'number') {
            creditRow.hidden = false;
            creditRow.querySelector('b').textContent = '$' + Number(d.limit_remaining).toFixed(4);
          } else if (creditRow) creditRow.hidden = true;
          var checked = $('#or-quota-checked', body);
          if (checked) checked.textContent = 'Updated ' + new Date(info.checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          renderCountdown();
          renderLocalActivity();
        }).catch(function (e) {
          status.innerHTML = '<span class="pill err">Quota check failed</span> ' + esc(e && e.message || 'Unknown error') +
            '<div class="hint">This check uses the saved OpenRouter key and does not use a model reply request.</div>';
        }).then(function () { if (button) button.disabled = false; });
      }
      sc.bind('#btn-or-refresh', 'click', refreshQuota);
      sc.bind('#btn-or-probe', 'click', function () {
        var button = $('#btn-or-probe', body), out = $('#or-probe-result', body);
        if (button) button.disabled = true;
        if (out) out.innerHTML = '<span class="pill">Testing selected model… up to 30 seconds</span>';
        API.probeOpenRouterModel(Store.settings).then(function (r) {
          if (out) out.innerHTML = '<span class="pill ok">Model answered in ' + (r.elapsedMs / 1000).toFixed(1) + 's</span>' +
            (r.provider ? '<div class="hint">Provider route: ' + esc(r.provider) + '</div>' : '');
        }).catch(function (e) {
          var cls = e && e.name === 'TimeoutError' ? 'warn' : 'err';
          if (out) out.innerHTML = '<span class="pill ' + cls + '">Model test failed</span> ' + esc(e && e.message || 'Unknown error');
        }).then(function () {
          if (button) button.disabled = false;
          renderLocalActivity();
          refreshQuota();
        });
      });
      renderLocalActivity();
      if (s.apiKey) refreshQuota();
      else { var emptyKeyStatus = $('#or-quota-status', body); if (emptyKeyStatus) emptyKeyStatus.innerHTML = '<span class="pill warn">Add your OpenRouter API key to view quota.</span>'; }
      openRouterQuotaClock = setInterval(function () { if (!isVisible()) { clearInterval(openRouterQuotaClock); openRouterQuotaClock = null; return; } renderCountdown(); }, 1000);
      if (s.apiKey) openRouterQuotaPoll = setInterval(function () { if (!isVisible()) { clearInterval(openRouterQuotaPoll); openRouterQuotaPoll = null; return; } refreshQuota(); }, 120000);
    } else {
      if (openRouterQuotaClock) { clearInterval(openRouterQuotaClock); openRouterQuotaClock = null; }
      if (openRouterQuotaPoll) { clearInterval(openRouterQuotaPoll); openRouterQuotaPoll = null; }
    }
  };

  /* ---- Generation ---- */
  Views.settingsGeneration = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Generation</div>' +
        '<div class="field"><div class="field-head"><label>Temperature</label><span class="spacer"></span><span class="val" id="v-temp">' + s.temperature + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-temp" min="0" max="2" step="0.05" value="' + s.temperature + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Max reply length</label><span class="spacer"></span><button type="button" class="val val-edit" id="v-max" title="Tap to type an exact token limit" aria-label="Max reply length: ' + s.maxTokens + ' tokens. Tap to enter a number">' + s.maxTokens + '</button></div>' +
          '<div class="range-row"><input type="range" id="set-max" min="64" max="2048" step="32" value="' + s.maxTokens + '"><span class="hint">tokens \u00b7 about ' + Math.round((s.maxTokens || API.DEFAULT_MAX_TOKENS) * 0.65) + ' words of dialogue</span></div>' +
          '<div class="hint">Tap the number to type an exact value (64–2048 tokens).</div></div>' +
        '<div class="field"><div class="field-head"><label>Top P</label><span class="spacer"></span><span class="val" id="v-topp">' + s.topP + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-topp" min="0.1" max="1" step="0.05" value="' + s.topP + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Messages in context</label><span class="spacer"></span><span class="val" id="v-ctx">' + s.contextMessages + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-ctx" min="6" max="120" step="2" value="' + s.contextMessages + '"></div>' +
          /* v1.44.0: this used to promise the lorebook read the same window, and to
             hedge about "may change nothing" for a number that could not be raised past
             twelve messages at all. Both claims were wrong; the settings now do what the
             wording says, and the two windows are named apart because they are apart. */
          '<div class="hint">How many of the newest messages are offered to the model. A message is not a ' +
          'unit of story, so the cut is pulled back to the start of a turn rather than landing mid-sentence. ' +
          'The <b>history budget</b> below still decides the size, so a long chat or a small model window can ' +
          'send fewer messages than this number.</div>' +
          '<div class="hint">The lorebook\'s keyword scan is a separate, shorter window: it is set per character ' +
          'under <b>Lore</b>, not here.</div></div>' +
        /* v1.39.82: the real limit, finally visible. It was a 26 000-character
           literal inside the prompt builder. */
        '<div class="field"><div class="field-head"><label>History budget</label><span class="spacer"></span>' +
          '<button type="button" class="val val-edit" id="v-hist" title="Tap to type an exact token budget" aria-label="History budget: ' + historyTokens(s) + ' tokens. Tap to enter a number">' +
          historyTokens(s) + '</button></div>' +
          '<div class="range-row"><input type="range" id="set-hist" min="1000" max="32000" step="500" value="' + historyTokens(s) + '">' +
          '<span class="hint">tokens of transcript</span></div>' +
          '<div class="hint">How much of the conversation is sent on each reply — the transcript only. The character ' +
          'sheet, the examples and the reply itself sit on top of it. Text is measured in characters and converted ' +
          'at four to a token; that is right for English, but emoji, Chinese, Japanese, Korean and Cyrillic cost ' +
          'more per character, so the same budget holds noticeably less of them.</div>' +
          '<div class="hint">' + historyWindowNote(s) + '</div></div>' +
        '<div class="field"><div class="field-head"><label>Repetition guard</label><span class="spacer"></span><span class="val" id="v-freqp">' + ((s.frequencyPenalty || 0).toFixed(2)) + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-freqp" min="0" max="1" step="0.05" value="' + (s.frequencyPenalty || 0) + '"></div>' +
          '<div class="hint">Makes the model shy away from words it already used — the fix for signature phrases repeating ' +
          'in every reply. 0 = model default (off); 0.3–0.5 cures most habits; high values thin the prose.</div></div>' +
        '<div class="field compact"><label>Stream replies</label><div class="toggle' + (s.streaming ? ' on' : '') + '" id="t-stream"></div></div>' +
        '<div class="field compact"><label>Finish cut-off replies</label><div class="toggle' + (s.autoFinish ? ' on' : '') + '" id="t-finish"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">If a reply stops mid-sentence (common on the Horde, which ' +
          'cuts at its token limit), the app asks for the rest and stitches it together — up to 3 passes.</div></div>' +
        '<div class="field compact"><label>Strip the model\'s thinking</label><div class="toggle' + (s.stripThinking !== false ? ' on' : '') + '" id="t-think"></div></div>' +
        '<div class="field compact"><label>Ask for no thinking at all</label><div class="toggle' + (s.reasoningOff ? ' on' : '') + '" id="t-nothink"></div></div>' +
        '<div class="hint">Sends <code>reasoning:{enabled:false}</code>. A model that spends the whole reply budget on invisible thinking returns nothing you can read, and the app cannot tell that from a refusal. Off keeps each model on its own default; Nemotron free routes are already handled either way.</div>' +
        '<div class="field"><label>If a route is saturated, try next</label><input id="or-fallback" maxlength="240" value="' + esc(s.replyFallback || '') + '" placeholder="google/gemma-4-26b-a4b-it:free, nvidia/nemotron-3.5-lightning:free"><div class="hint">Up to three models, comma separated, OpenRouter only. A refused route answers from the next one instead of showing a red pill and waiting for you to do the failover yourself.</div></div>' +
        '<div class="field"><div class="hint" style="margin:0">Some models plan out loud before they answer. ' +
          'When that planning is recognisable it is removed, so you only see what the character says.</div></div>' +
        /* v1.39.24 */
        '<div class="field compact"><label>Plain-prose rendering</label><div class="toggle' + (s.plainEmphasis ? ' on' : '') + '" id="t-plain"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">Some models wrap narration in *asterisks* no matter how often ' +
          'they are told not to. This shows such text as ordinary prose — markers and stray asterisks hidden, ' +
          'speech still gold, and the stored story text is never rewritten.</div></div>' +
        /* v1.45.0: the neighbour is the app's own display-only transform, and the
           promise is the same one: what you see changes, the story does not. */
        '<div class="field compact"><label>Text scripts (display only)</label>' +
          '<div class="toggle' + (s.regexOn ? ' on' : '') + '" id="t-scripts"></div></div>' +
        '<div class="field"><button class="btn ghost sm block" id="btn-scripts">' + icon('edit') +
          ' Manage scripts' + ((s.regexScripts && s.regexScripts.length) ? ' · ' + s.regexScripts.length : '') +
          '</button><div class="hint" style="margin-top:6px">Find-and-replace rules applied to each reply as it is ' +
          'drawn — for a habit the model has that you cannot train out, a name you want shortened, a marker you want ' +
          'gone. Nothing is rewritten: the stored message, the prompt, a transcript export and the read-aloud text all ' +
          'keep the model\u2019s own words, so turning this off gives you exactly what you had. Rules run top to bottom, ' +
          'each seeing what the one before it left; JavaScript syntax, <code>$1</code> back-references included. ' +
          'Resetting the generation defaults switches this off but leaves your rules alone.</div></div>' +
        '<div class="field compact"><label>Split replies into separate texts</label><div class="toggle' + (s.bursts !== false ? ' on' : '') + '" id="t-bursts"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">For virtual humans: when a reply reads like several short ' +
          'messages rather than one paragraph, it arrives as separate bubbles a few seconds apart.</div></div>' +
        '<div class="field compact"><label>Enter sends message</label><div class="toggle' + (s.sendOnEnter ? ' on' : '') + '" id="t-enter"></div></div>' +
        '<div class="field"><button class="btn danger" id="gen-reset" style="width:100%">Reset to defaults</button>' +
          '<div class="hint" style="margin:6px 0 0">Puts every slider and toggle above back to its factory value. ' +
          'Provider, API key, model and personas are NOT touched.</div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.range('#set-temp', '#v-temp', 'temperature', function (v) { return v.toFixed(2); });
    sc.range('#set-max', '#v-max', 'maxTokens');
    /* v1.39.82: the history budget gets the same slider + exact-entry pair as
       the reply length, because a slider that stops at 32 000 with a 500 step
       cannot express "give me everything this model holds". */
    sc.range('#set-hist', '#v-hist', 'historyTokens');
    /* v1.39.82: same slider + exact-entry pair as the reply length. A slider
       that stops at 32 000 cannot express "everything this model holds". */
    (function () {
      var value = $('#v-hist', body), slider = $('#set-hist', body);
      if (!value || !slider) return;
      function openEditor() {
        var input = document.createElement('input');
        input.type = 'number'; input.min = '500'; input.max = '200000'; input.step = '100';
        input.inputMode = 'numeric'; input.className = 'max-token-entry';
        input.setAttribute('aria-label', 'History budget in tokens');
        input.value = String(historyTokens(Store.settings));
        value.replaceWith(input);
        input.focus(); input.select();
        var done = false;
        function finish(save) {
          if (done) return; done = true;
          var n = Math.round(Number(input.value));
          if (save && input.value.trim() !== '' && isFinite(n)) {
            n = Math.max(500, Math.min(200000, n));
            var patch = { historyTokens: n }; sc.set(patch);
            slider.value = String(Math.min(32000, n));
          }
          var current = historyTokens(Store.settings);
          var display = document.createElement('button');
          display.type = 'button'; display.className = 'val val-edit'; display.id = 'v-hist';
          display.title = 'Tap to type an exact token budget';
          display.setAttribute('aria-label', 'History budget: ' + current + ' tokens. Tap to enter a number');
          display.textContent = String(current);
          input.replaceWith(display);
          display.addEventListener('click', openEditor);
        }
        input.addEventListener('change', function () { finish(true); });
        input.addEventListener('blur', function () { finish(true); });
        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); finish(true); }
          if (e.key === 'Escape') { e.preventDefault(); finish(false); }
        });
      }
      value.addEventListener('click', openEditor);
    })();
    /* The slider is fiddly for an exact token count on a phone. Tap the
       displayed value to edit it directly; commit on Enter/change/blur,
       Escape cancels. Keep the slider and saved setting in sync. */
    var maxValue = $('#v-max', body), maxSlider = $('#set-max', body);
    if (maxValue && maxSlider) {
      function openMaxEditor() {
        var input = document.createElement('input');
        input.type = 'number'; input.min = '64'; input.max = '2048'; input.step = '1';
        input.inputMode = 'numeric'; input.className = 'max-token-entry';
        input.setAttribute('aria-label', 'Max reply length in tokens');
        input.value = String(Store.settings.maxTokens || API.DEFAULT_MAX_TOKENS);
        maxValue.replaceWith(input);
        input.focus(); input.select();
        var done = false;
        function finish(save) {
          if (done) return; done = true;
          var n = Math.round(Number(input.value));
          if (save && input.value.trim() !== '' && isFinite(n)) {
            n = Math.max(64, Math.min(2048, n));
            var patch = { maxTokens: n }; sc.set(patch); maxSlider.value = String(n);
          }
          var current = Store.settings.maxTokens || API.DEFAULT_MAX_TOKENS;
          var display = document.createElement('button');
          display.type = 'button'; display.className = 'val val-edit'; display.id = 'v-max';
          display.title = 'Tap to type an exact token limit';
          display.setAttribute('aria-label', 'Max reply length: ' + current + ' tokens. Tap to enter a number');
          display.textContent = String(current);
          input.replaceWith(display);
          display.addEventListener('click', openMaxEditor);
        }
        input.addEventListener('change', function () { finish(true); });
        input.addEventListener('blur', function () { finish(true); });
        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); finish(true); }
          else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
        });
      }
      maxValue.addEventListener('click', openMaxEditor);
    }
    sc.range('#set-topp', '#v-topp', 'topP', function (v) { return v.toFixed(2); });
        sc.range('#set-ctx', '#v-ctx', 'contextMessages');
        sc.range('#set-freqp', '#v-freqp', 'frequencyPenalty', function (v) { return v.toFixed(2); });
    sc.toggle('#t-stream', 'streaming');
    sc.toggle('#t-finish', 'autoFinish');
    sc.toggle('#t-bursts', 'bursts');
    sc.toggle('#t-think', 'stripThinking');
    sc.toggle('#t-nothink', 'reasoningOff');
    sc.bind('#or-fallback', 'input', function () {
      var el = $('#or-fallback', body);
      sc.set({ replyFallback: el ? el.value.trim() : '' });
    });
    sc.toggle('#t-plain', 'plainEmphasis');
    /* the list length is printed on the button, so coming back from the editor
       has to redraw it — but toggling the switch off must not, because a
       re-render from inside its own click handler is how controls get lost */
    sc.toggle('#t-scripts', 'regexOn');
    sc.bind('#btn-scripts', 'click', function () {
      Promise.resolve(App.regexScriptsSheet()).then(function () {
        if ($('#settings-x-body')) Views.settingsGeneration(root);
      });
    });
    sc.toggle('#t-enter', 'sendOnEnter');
    var gr = $('#gen-reset');
    if (gr) gr.onclick = function () { App.resetGenerationSettings(); };
  };

  /* ---- You ---- */
  Views.settingsYou = function (root) {
    var s = Store.settings;
    var activeId = s.activePersona || '';
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">You</div>' +
        '<div class="field"><div class="hint" style="margin:0 0 6px">' +
          (activeId
            ? 'Editing the <b>' + esc(Store.personaLabel()) + '</b> persona. These two fields always follow whichever identity is active.'
            : 'Your default identity — used whenever no persona is selected.') +
        '</div></div>' +
        '<div class="field"><div class="field-head"><label>Your name</label></div>' +
          '<input type="text" id="set-uname" value="' + esc(s.userName) + '"></div>' +
        '<div class="field"><div class="field-head"><label>Your persona</label></div>' +
          '<textarea id="set-upersona" placeholder="Who you are in the story — appearance, background, goals.">' + esc(s.userPersona) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Your pronouns</label></div>' +
          '<div class="hint" style="margin:0 0 6px">Cards that use {{sub}}, {{obj}}, {{poss}}, {{poss_p}} or {{ref}} fill them in from here. Without a set, they print as literal braces.</div>' +
          '<div class="chips" id="set-pronoun-presets">' +
            [['they', 'they / them'], ['she', 'she / her'], ['he', 'he / him'], ['it', 'it / its']].map(function (opt) {
              var on = (s.pronounPreset || 'they') === opt[0];
              return '<button type="button" class="chip' + (on ? ' on' : '') + '" data-pronoun="' + opt[0] + '">' + opt[1] + '</button>';
            }).join('') +
          '</div></div>' +
        pronounCustomHtml(s) +
      '</div>';
    var sc = settingsScope(body);
    /* Identity edits land on the persona when one is active, else on the default. */
    sc.bind('#set-uname', 'change', function (e) {
      Store.setIdentity({ name: e.target.value.trim() || 'You' }).then(function () { Views.settingsYou(root); });
    });
    sc.bind('#set-upersona', 'change', function (e) { Store.setIdentity({ text: e.target.value }); });
    body.querySelectorAll('[data-pronoun]').forEach(function (b) {
      b.onclick = function () {
        var preset = b.getAttribute('data-pronoun');
        /* a preset replaces any custom words the player typed */
        Store.setIdentity({ pronounPreset: preset, pronouns: { sub: '', obj: '', poss: '', possP: '', ref: '' } })
          .then(function () { Views.settingsYou(root); });
      };
    });
    body.querySelectorAll('[data-pron]').forEach(function (inp) {
      inp.onchange = function () {
        var patch = {}; patch[inp.getAttribute('data-pron')] = inp.value.trim();
        Store.setIdentity({ pronouns: patch });
      };
    });
  };

  /* Five override boxes, prefilled with the active preset so the player can
     change one word without retyping the set. */
  function pronounCustomHtml(s) {
    var preset = (API.pronounPresets && API.pronounPresets[(s.pronounPreset || 'they')]) || {};
    var custom = s.pronouns || {};
    var rows = [['sub', 'he / she / they'], ['obj', 'him / her / them'],
      ['poss', 'his / her / their'], ['possP', 'his / hers / theirs'], ['ref', 'himself / herself / themselves']];
    return '<div class="field"><div class="field-head"><label>Fine-tune words</label></div>' +
      '<div class="hint" style="margin:0 0 6px">Leave a box empty to use the preset above.</div>' +
      rows.map(function (r) {
        return '<div class="row" style="gap:8px;align-items:center;margin-bottom:6px">' +
          '<span class="hint" style="min-width:96px">' + r[0] + '</span>' +
          '<input type="text" data-pron="' + r[0] + '" placeholder="' + esc(preset[r[0]] || '') + '" value="' +
          esc(custom[r[0]] || '') + '" style="flex:1">' +
          '</div>';
      }).join('') + '</div>';
  }

  /* ---- System prompt ---- */
  Views.settingsSystem = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">System prompt</div>' +
        '<div class="field"><textarea class="tall" id="set-system">' + esc(s.systemPrompt) + '</textarea>' +
          '<div class="hint">Sent before the character sheet. Macros: {{char}}, {{user}}, {{persona}}.</div>' +
          '<button class="btn ghost sm" id="btn-reset-sys">Reset to default</button></div>' +
        /* v1.41.0 (review issue 1): the preference that lets a card's own prompt
           through exists in the prompt builder, so it is a switch here — off, and
           worded so nobody mistakes it for a compatibility default. It applies to
           cards imported from now on that asked for it, and to any character that
           has not been given its own answer. */
        '<div class="field compact"><label>Cards may choose their prompt</label>' +
          '<div class="toggle' + (s.honorCardSystemPrompt === true ? ' on' : '') + '" id="set-card-prompt"></div></div>' +
        '<div class="hint">Off — the default — a card that brings its own system prompt only has it ' +
          'shown on the character, and you can switch it on there. On, a card that <i>asks</i> for it in ' +
          'its Horde fields gets it without being asked again — for those cards and any you import later. ' +
          'It never overrides a choice you made on a character, and it does nothing at all to a card ' +
          'that never asked. Switch it back off and those cards go quiet again.</div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#set-system', 'change', function (e) { sc.set({ systemPrompt: e.target.value }); });
    var cardPromptEl = $('#set-card-prompt', body);
    if (cardPromptEl) cardPromptEl.onclick = function () {
      this.classList.toggle('on');
      sc.set({ honorCardSystemPrompt: this.classList.contains('on') });
    };
    sc.bind('#btn-reset-sys', 'click', function () {
      /* Reset to the real default (store.js) — this handler used to carry a
         stale copy that predated the formatting line and the closing
         "write only what the character does and says" sentence. */
      sc.set({ systemPrompt: Store.defaultSystem });
      Views.settingsSystem(root);
      UI.toast('System prompt reset');
    });
  };

  /* ---- AI Horde · images & free text ---- */
  Views.settingsHorde = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Image generation</div>' +
        '<div class="field"><div class="field-head"><label>Default image provider</label></div>' +
          '<select id="set-image-provider"><option value="horde"' + (s.imageProvider === 'horde' ? ' selected' : '') + '>AI Horde</option>' +
          '<option value="pollinations"' + (s.imageProvider === 'pollinations' ? ' selected' : '') + '>Pollinations Classic</option>' +
          '<option value="cloudflare"' + (s.imageProvider === 'cloudflare' ? ' selected' : '') + '>Cloudflare Workers AI</option></select>' +
          '<div class="hint">AI Horde is queued and supports model/size controls. Pollinations is free, anonymous and rate-limited. Cloudflare uses your own Worker proxy.</div></div>' +
        '<div class="field"><div class="field-head"><label>Cloudflare Worker URL</label></div>' +
          '<input type="url" id="set-cf-worker-url" value="' + esc(s.cloudflareWorkerUrl || '') + '" placeholder="https://your-worker.your-subdomain.workers.dev">' +
          '<div class="hint">Deploy the user-owned proxy template from tools/cloudflare-image-worker. Paste its HTTPS URL; do not enter a Cloudflare API token.</div></div>' +
        '<div class="field"><div class="field-head"><label>Worker access token</label></div>' +
          '<input type="password" id="set-cf-worker-token" value="' + esc(s.cloudflareWorkerToken || '') + '" autocomplete="new-password" placeholder="APP_TOKEN secret from your Worker">' +
          '<div class="hint">This is the separate APP_TOKEN secret configured on your Worker. It stays on this device and is excluded from backups.</div></div>' +
        '<div class="field"><div class="field-head"><label>Horde API key (optional)</label></div>' +
          '<input type="password" id="set-hkey" value="' + esc(s.hordeKey) + '" placeholder="0000000000 = anonymous">' +
          '<div class="hint">Free account at aihorde.net — a key jumps the queue. Anonymous works too.</div></div>' +
        '<div class="field"><div class="field-head"><label>Image model</label></div>' +
          '<div class="row"><button class="btn ghost sm" id="btn-hmodel" style="flex:1;text-align:left">' + esc(Horde.imageModelLabel(s.hordeModel) || 'Tap to choose') + '</button>' +
          '<button class="btn ghost sm" id="btn-refresh-hmodels">' + icon('refresh') + '</button></div></div>' +
        '<div class="field"><div class="field-head"><label>Image size</label><span class="spacer"></span><span class="val" id="v-size">' + s.hordeSize + 'px</span></div>' +
          '<div class="hint">Smaller = cheaper in kudos and much shorter queue time.</div>' +
          '<div class="seg" id="seg-size">' + [512, 640, 768, 1024].map(function (n) {
            return '<button data-size="' + n + '"' + (n === s.hordeSize ? ' class="on"' : '') + '>' + n + '</button>';
          }).join('') + '</div></div>' +
        '<div class="field"><div class="field-head"><label>Diffusion steps</label><span class="spacer"></span><span class="val" id="v-steps">' + s.hordeSteps + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-steps" min="10" max="50" step="1" value="' + s.hordeSteps + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Give up after</label><span class="spacer"></span><span class="val" id="v-maxwait">' + Math.round(s.hordeMaxWait / 60) + ' min</span></div>' +
          '<div class="range-row"><input type="range" id="set-maxwait" min="2" max="20" step="1" value="' + Math.round(s.hordeMaxWait / 60) + '"><span class="hint">queue wait</span></div>' +
          '<div class="hint">The Horde is a queue, not an API — busy models can hold a job for minutes. ' +
          'Jobs show queue position and ETA live, and you can cancel at any time.</div></div>' +
        '<div class="field"><div class="field-head"><label>Horde text model</label></div>' +
          '<div class="row"><button class="btn ghost sm" id="btn-htext" style="flex:1;text-align:left">' + esc(Horde.modelLabel(s.hordeTextModel) || 'Any available (recommended)') + '</button>' +
          '<button class="btn ghost sm" id="btn-refresh-tmodels">' + icon('refresh') + '</button></div>' +
          '<div class="hint">Only used when the provider above is set to AI Horde.</div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#set-image-provider', 'change', function (e) { sc.set({ imageProvider: e.target.value }); });
    sc.bind('#set-cf-worker-url', 'change', function (e) { sc.set({ cloudflareWorkerUrl: e.target.value.trim() }); });
    sc.bind('#set-cf-worker-token', 'change', function (e) { sc.set({ cloudflareWorkerToken: e.target.value.trim() }); });
    sc.bind('#set-hkey', 'change', function (e) { sc.set({ hordeKey: e.target.value.trim() }); });
    sc.range('#set-steps', '#v-steps', 'hordeSteps');
    var mw = $('#set-maxwait', body);
    if (mw) mw.addEventListener('input', function () {
      var mins = parseInt(mw.value, 10);
      $('#v-maxwait', body).textContent = mins + ' min';
      sc.set({ hordeMaxWait: mins * 60 });
    });
    sc.bind('#seg-size', 'click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      sc.set({ hordeSize: parseInt(b.getAttribute('data-size'), 10) });
      body.querySelectorAll('#seg-size button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      $('#v-size', body).textContent = Store.settings.hordeSize + 'px';
    });
    sc.bind('#btn-refresh-hmodels', 'click', function () { App.chooseHordeModel('image', true); });
    sc.bind('#btn-hmodel', 'click', function () { App.chooseHordeModel('image', false); });
    sc.bind('#btn-refresh-tmodels', 'click', function () { App.chooseHordeModel('text', true); });
    sc.bind('#btn-htext', 'click', function () { App.chooseHordeModel('text', false); });
  };

  /* ---- Memory ---- */
  Views.settingsMemory = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Memory</div>' +
        '<div class="field compact"><label>Auto-summarise long chats</label><div class="toggle' + (s.autoMemory ? ' on' : '') + '" id="t-mem"></div></div>' +
        '<div class="field"><div class="field-head"><label>Summarise every</label><span class="spacer"></span><span class="val" id="v-memevery">' + s.memoryEvery + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-memevery" min="6" max="60" step="2" value="' + s.memoryEvery + '"><span class="hint">msgs</span></div></div>' +
      '</div>' +
      '<div class="group">' +
        '<div class="group-title">Recall</div>' +
        '<div class="field compact"><label>Fetch older messages that fit this turn</label>' +
          '<div class="toggle' + (s.recallOn ? ' on' : '') + '" id="t-recall"></div></div>' +
        '<div class="field"><div class="field-head"><label>Passages per reply</label><span class="spacer"></span>' +
          '<span class="val" id="v-recallcount">' + API.recallCount(s) + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-recallcount" min="1" max="12" step="1" value="' +
            API.recallCount(s) + '"></div>' +
          '<div class="hint">When the history budget pushes a turn out of the request, the model does not ' +
          'remember it — it was never sent. This scores the messages the window left out (BM25, on the ' +
          'phone, nothing uploaded) and appends the few that match your last line, after the transcript, ' +
          'under a heading that says they are background rather than the present moment. Nothing is moved ' +
          'or rewritten, so the prompt cache keeps its discount. The block is capped at ~700 tokens, and ' +
          'a passage that shares only one common word with your line is not fetched at all.</div>' +
          '<div class="hint">' + recallStatusNote() + '</div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.toggle('#t-mem', 'autoMemory');
    sc.range('#set-memevery', '#v-memevery', 'memoryEvery');
    sc.toggle('#t-recall', 'recallOn');
    sc.range('#set-recallcount', '#v-recallcount', 'recallCount');
  };

  /* What the last request actually did, said in the place where you would decide
     to change it. Read, never derived: if nothing has been generated since the app
     opened there is no number to quote, and the honest line is longer than a zero. */
  function recallStatusNote() {
    var a = null;
    try { a = API.lastAssembly && API.lastAssembly(); } catch (e) { a = null; }
    if (!a || !a.recall) {
      return 'Nothing has been recalled yet since the app opened. Send a reply with this on and the count appears here.';
    }
    if (!a.recall.on) return 'Switched off, so the last request carried no recall block.';
    /* A chat longer than the search cap has lines that were never looked at. Saying
       "nothing matched" about those would be a lie, so the note names the bound. */
    var looked = 'looked through ' + a.recall.corpus + ' older messages';
    if (a.recall.scanned > a.recall.corpus) {
      looked += ' (' + (a.recall.scanned - a.recall.corpus) + ' before those are past the search cap and were not read)';
    }
    if (!a.recall.passages) return 'Last request: ' + looked + ' and nothing in them matched that turn.';
    return 'Last request: ' + looked + ' and kept ' + a.recall.passages +
      ' passage' + (a.recall.passages === 1 ? '' : 's') + ', ~' + a.recall.tokens + ' tokens' +
      (a.recall.dropped ? ', ' + a.recall.dropped + ' more dropped for size' : '') + '.';
  }


  /* ---- Data ---- */
  Views.settingsData = function (root) {
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Data</div>' +
        '<div class="field"><div class="row">' +
          '<button class="btn ghost sm" style="flex:1" id="btn-export">' + icon('download') + ' Backup</button>' +
          '<button class="btn ghost sm" style="flex:1" id="btn-import">' + icon('upload') + ' Restore</button>' +
        '</div><div class="hint">Backup exports everything except your API keys.</div></div>' +
        '<div class="field"><button class="btn danger block sm" id="btn-wipe">' + icon('trash') + ' Erase all characters and chats</button></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#btn-export', 'click', function () {
      Store.exportAll().then(function (json) {
        UI.download('horde-studio-backup-' + new Date().toISOString().slice(0, 10) + '.json', json);
        UI.toast('Backup downloaded');
      });
    });
    sc.bind('#btn-import', 'click', function () {
      pickFile('.json,application/json').then(function (f) {
        if (!f) return;
        var fr = new FileReader();
        fr.onload = function () {
          Promise.resolve()
            .then(function () { return Store.importAll(fr.result); })
            .then(function (r) {
              return Store.refreshCharacters().then(function () {
                UI.toast('Restored ' + r.characters + ' characters, ' + r.sessions + ' chats');
                Views.settingsData(root);
              });
            })
            .catch(function (e) { UI.toast('Restore failed: ' + e.message, 4000); });
        };
        fr.readAsText(f);
      });
    });
    sc.bind('#btn-wipe', 'click', function () {
      UI.confirm('Erase everything?', 'All characters, chats and memories on this device will be deleted. This cannot be undone.',
        { danger: true, okLabel: 'Erase' }).then(function (ok) {
        if (!ok) return;
        Store.wipe().then(function () { return Store.refreshCharacters(); }).then(function () {
          UI.toast('Everything erased');
          App.go('characters');
        });
      });
    });
  };

  /* ---- Storage ---- */
  Views.settingsStorage = function (root) {
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Storage</div>' +
        '<div class="field">' +
          '<button class="btn ghost sm block" id="btn-storage">' + icon('copy') + ' Show storage use</button>' +
          '<div class="hint">A read-only look at what the app is holding on this phone. The app never deletes anything on its own.</div>' +
          '<div id="storage-lines" style="margin-top:8px"></div>' +
        '</div>' +
      '</div>';
    var sc = settingsScope(body);
    /* 18.2.0 (mobile subset): read-only storage inspection — count what the
       app holds on this phone and show the biggest holders. */
    sc.bind('#btn-storage', 'click', function () {
      var box = $('#storage-lines', body);
      box.innerHTML = '<div class="hint">Measuring…</div>';
      var chars = Store.characters || [];
      Promise.all(chars.map(function (c) {
        return Store.getSessions(c.id).then(function (ss) { return ss || []; });
      })).then(function (perChar) {
        var sessions = [];
        perChar.forEach(function (ss) { sessions = sessions.concat(ss); });
        return Promise.all(sessions.map(function (s) {
          return Store.getMessages(s.id).then(function (mm) { return mm || []; });
        })).then(function (perSession) {
          var messages = [];
          perSession.forEach(function (mm) { messages = messages.concat(mm); });
          return HW.all().then(function (worlds) {
            var rep = App.storageReport({
              characters: chars, sessions: sessions, messages: messages, worlds: worlds || []
            });
            box.innerHTML = '<div class="kv"><span>Everything above</span><b>~' + (rep.bytes >= 1048576 ? (rep.bytes / 1048576).toFixed(1) + ' MB' : Math.ceil(rep.bytes / 1024) + ' KB') + '</b></div>' +
              rep.lines.map(function (l) {
                return '<div class="kv"><span>' + esc(l[0]) + '</span><b style="text-align:right">' + esc(l[1]) + '</b></div>';
              }).join('');
          });
        });
      }).catch(function (e) {
        box.innerHTML = '<div class="hint">Could not measure: ' + esc(e.message || e) + '</div>';
      });
    });
  };

  /* ---- App updates ---- */
  Views.settingsUpdate = function (root) {
    var info = settingsUpdateInfo();
    var U = info.U, upInfo = info.upInfo, upUrl = info.upUrl, upNote = info.upNote;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">App updates</div>' +
        '<div class="field"><div class="kv"><span>App</span><b>' + esc(upInfo.apk || '?') + '</b></div>' +
        '<div class="kv"><span>Files in use</span><b>' + (upInfo.overlay
            ? 'update ' + esc(upInfo.rev)
            : 'as shipped in the app') + '</b></div></div>' +
        '<div class="field"><div class="field-head"><label>Update address</label></div>' +
          '<input type="text" id="set-updurl" spellcheck="false" value="' + esc(upUrl) + '" placeholder="https://...">' +
          '<div class="hint">Where the app looks for new files. It only ever looks when you press the button below.</div></div>' +
        '<div class="field">' +
          '<button class="btn ghost sm" id="btn-upd-check">Check for update</button> ' +
          '<button class="btn ghost sm" id="btn-upd-file">Apply from a file</button> ' +
          '<button class="btn ghost sm" id="btn-upd-reset">Reset to shipped files</button>' +
          '<div class="hint" id="upd-status" style="margin-top:8px">' + upNote + '</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Error log</label>' +
            '<button class="btn ghost sm" id="btn-log-clear" style="margin-left:auto">Clear</button></div>' +
          '<div class="errlog" id="errlog-box"></div>' +
          '<div class="hint">The last things that went wrong — installs, downloads, crashes, and failed chat responses. ' +
            'Chat errors include provider/model details and up to 1,200 characters of the error; prompts, replies, and credentials are not logged. ' +
            'The log keeps its newest 200 entries and drops the rest on its own; Clear starts it fresh.</div>' +
        '</div>' +
      '</div>';
    var sc = settingsScope(body);
    var upStatus = $('#upd-status', body);

    /* the error log: toasts fade, this stays. Newest first, the box scrolls;
       the wrapper caps the stored log itself (200 entries, oldest dropped). */
    var logBox = $('#errlog-box', body);
    function renderLog() {
      if (!logBox) return;
      var entries;
      try { entries = (global.Logs && Logs.list()) || []; } catch (e) { entries = []; }
      if (!entries.length) {
        logBox.innerHTML = '<p class="hint" style="margin:0">Nothing has gone wrong here yet.</p>';
        return;
      }
      logBox.innerHTML = entries.map(function (e) {
        var when = '';
        try { when = new Date(e.t).toLocaleString(); } catch (err) { when = String(e.t || ''); }
        return '<div class="errlog-line"><span class="errlog-when">' + esc(when) + '</span>' +
          '<span class="errlog-msg">' + esc(e && e.m) + '</span></div>';
      }).join('');
    }
    renderLog();
    sc.bind('#btn-log-clear', 'click', function () {
      UI.confirm('Clear the error log?', 'The log starts fresh. This does not touch chats, characters or settings.',
        { okLabel: 'Clear' }).then(function (yes) {
          if (!yes) return;
          try { global.Logs && Logs.clear(); } catch (e) { }
          renderLog();
          UI.toast('Error log cleared');
        });
    });
    function upSay(html) { if (upStatus) upStatus.innerHTML = html; }
    function upBar(pct, label) {
      upSay('<div class="upd-bar"><span style="width:' + Math.max(2, Math.min(100, pct || 0)) + '%"></span></div>' +
        '<div style="margin-top:4px">' + esc(label || 'Downloading') + ' ' + (pct || 0) + '%</div>');
    }
    /* The install is the one update path that replaces the app itself, so it
       is the one that states its data promise out loud before it starts: an
       in-place install keeps everything; only uninstalling the app first
       would lose chats. (Files-only updates never touch chat storage at all.) */
    function beginInstall(apkLabel, followUp) {
      UI.confirm('Install app ' + apkLabel + ' over the current app?',
        'It downloads the APK and opens Android’s install screen. Installing over the current app keeps all your chats and characters — data is only lost if you uninstall the app first.',
        { okLabel: 'Install' }).then(function (yes) {
          if (!yes) return;
          try { U.installApk(); upSay(followUp); }
          catch (e) { upSay('Could not start the install: ' + esc(e.message || String(e))); }
        });
    }
    sc.bind('#set-updurl', 'change', function (e) {
      if (!U) return;
      U.saveUrl(e.target.value).then(function () { UI.toast('Update address saved'); });
    });
    sc.bind('#btn-upd-check', 'click', function () {
      if (!U || !U.supported()) { upSay('Self-updating needs the newest APK installed once.'); return; }
      var btn = this;
      btn.disabled = true;
      upSay('Checking…');
      U.check().then(function (r) {
        btn.disabled = false;
        if (r.upToDate) {
          upSay('Up to date — app ' + esc(r.local.apk) + ', files ' +
            (r.local.overlay ? 'update ' + esc(r.local.rev) : 'as shipped') + '.');
          return;
        }
        /* One guided path, not a list of options to reason about:
           - files only → Apply now
           - app only → Install app update
           - both → "Update everything" (the install), and the files apply
             themselves on the next boot. No second Check for it. */
        var html = '';
        if (r.newApk && r.newWeb) {
          html += '<p><b>App ' + esc(r.remote.apk || '') + '</b> and new files are ready.</p>' +
            '<p>Install the app, then reopen it — the new files apply themselves. ' +
            'Installing over the current app keeps your chats and characters.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-all">Update everything</button> ' +
            '<button class="btn ghost sm" id="btn-upd-apply">Files only — keep this app</button></div>';
        } else if (r.newApk) {
          html += '<p>App <b>' + esc(r.remote.apk || '') + '</b> is ready. ' +
            'It downloads the APK and opens the Android install screen — ' +
            'installing over the current app keeps your chats and characters.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-install">Install app update</button> ' +
            '<button class="btn ghost sm" id="btn-upd-browser">Or in browser</button></div>';
        } else {
          html += '<p>Fixes are ready to apply <b>without reinstalling anything</b>.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-apply">Apply now</button></div>';
        }
        if (r.remote.note) html += '<p>' + esc(r.remote.note) + '</p>';
        upSay(html);

        var allBtn = $('#btn-upd-all', body);
        if (allBtn) allBtn.addEventListener('click', function () {
          beginInstall(esc(r.remote.apk || 'the update'),
            'Downloading — Android will ask you to confirm the install. ' +
            'After it finishes, reopen the app: the new files apply themselves.');
        });

        var applyBtn = $('#btn-upd-apply', body);
        if (applyBtn) applyBtn.addEventListener('click', function () {
          applyBtn.disabled = true;
          upSay('Downloading the new files…');
          U.applyWeb(r.remote.webRev, function (p) { upBar(p, 'Downloading'); }).then(function () {
            upSay('Applied — reloading…');
            setTimeout(function () { U.reloadFresh(); }, 500);
          }).catch(function (e2) {
            applyBtn.disabled = false;
            upSay('Could not apply the update: ' + esc(e2.message || String(e2)));
          });
        });

        var instBtn = $('#btn-upd-install', body);
        if (instBtn) instBtn.addEventListener('click', function () {
          beginInstall(esc(r.remote.apk || 'the update'),
            'Downloading — Android will ask you to confirm the install.');
        });
        var browBtn = $('#btn-upd-browser', body);
        if (browBtn) browBtn.addEventListener('click', function () {
          try { U.openDownload(); upSay('Opened in your browser — download and install there.'); }
          catch (e4) { upSay('Could not open the browser: ' + esc(e4.message || String(e4))); }
        });
      }).catch(function (e) {
        btn.disabled = false;
        var msg = e.message || String(e);
        if (/answered (502|503|504)/.test(msg)) {
          msg += ' That address belongs to a workspace that is no longer running. Either ' +
            'paste the current address into Update address above, or use ' +
            'Apply from a file — download the bundle in your browser and pick it here.';
        } else if (/answered (401|403)|refused the request/.test(msg)) {
          msg += ' Apply from a file works without the network: download the bundle in ' +
            'your browser, then pick it here.';
        }
        upSay('Could not check: ' + esc(msg));
      });
    });
    sc.bind('#btn-upd-file', 'click', function () {
      if (!U || !U.supported()) { upSay('Self-updating needs the newest APK installed once.'); return; }
      upSay('Choose the update file you downloaded…');
      U.applyFile(function (p) { upBar(p, 'Applying'); }).then(function (rev) {
        upSay('Applied revision ' + esc(String(rev)) + ' — reloading…');
        setTimeout(function () { U.reloadFresh(); }, 600);
      }).catch(function (e2) {
        var m = (e2 && e2.message) || String(e2);
        upSay(/No file chosen/i.test(m) ? 'No file chosen — nothing changed.'
          : 'Could not apply that file: ' + esc(m));
      });
    });
    sc.bind('#btn-upd-reset', 'click', function () {
      if (!U || !U.supported()) return;
      UI.confirm('Go back to the shipped files?', 'The update is removed and the app restarts on the copy that came with the APK. Your chats and characters are untouched.',
        { okLabel: 'Reset' }).then(function (ok) {
          if (!ok) return;
          U.reset();
          U.reloadFresh();
        });
    });
  };
  
  /* ================= EDITOR ================= */
  Views.editor = function (root, char) {
    var isNew = !char.id || !Store.characters.some(function (c) { return c.id === char.id; });
    VH.ensure(char);
    var vh = char.vh;
    var vh_enabled = !!vh.enabled;
    /* the Create-with-AI card shows on an empty sheet only: once the model
     * (or the user) has written persona/scenario/greeting it goes away */
    var emptySheet = !char.persona && !char.scenario && !char.greeting;
    function slider(id, label, val) {
      var pct = Math.round((Math.max(-1, Math.min(1, val || 0)) + 1) / 2 * 100);
      return '<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted)">' +
        '<span>' + esc(label) + '</span><span id="' + id + '-v">' + (val || 0).toFixed(2) + '</span></div>' +
        '<input type="range" id="' + id + '" min="-100" max="100" step="5" value="' + Math.round((val || 0) * 100) + '" style="width:100%"></div>';
    }
    /* v1.40.0: the three card-prompt/placement choices, each read with the app's
       own default so a character from before this version needs no migration. */
    var SYS_SRC_LABEL = { app: 'Your prompt', card: "The card's", combine: 'Both' };
    var POST_PLACE_LABEL = { sheet: 'End of the sheet', tail: 'After the history', off: 'Not sent' };
    var cardPrompt = String(char.cardSystemPrompt || '');
    var sysSrc = ['app', 'card', 'combine'];
    /* The segment shows the mode the app will ACTUALLY use, which is not simply
       the stored field: `''` means "nobody has decided", and a player who has
       switched the global preference on has decided for every card they import.
       Showing "Your prompt" while the card's text went out would be a lie in the
       one screen whose job is to say what is being sent. */
    var sysSrcEff = API.cardPromptMode(char, Store.settings);
    var sysSrcAsked = String(char.systemPromptAsked || '');
    var sysSrcOn = sysSrc.indexOf(sysSrcEff) >= 0 ? sysSrcEff : 'app';
    /* v1.41.0 (review request 4): the persona as one string, or as the two fields
       a V2/V3 card actually carries. `descText`/`persText` come from the card at
       import, so opening a card and switching here cannot invent text; a
       hand-made character has none, and the first split puts the whole persona in
       the description where the card would keep it. */
    var personaSplitOn = char.personaSplit === true;
    var hasParts = typeof char.descText === 'string' && !!(char.descText || char.persText);
    var descSeed = hasParts ? String(char.descText) : String(char.persona || '');
    var persSeed = hasParts ? String(char.persText || '') : '';
    var postPlace = ['sheet', 'tail', 'off'];
    var postPlaceOn = postPlace.indexOf(char.postHistoryPlacement) >= 0 ? char.postHistoryPlacement : 'sheet';
    var LORE_SCAN_MIN = API.LORE_SCAN_MIN, LORE_SCAN_MAX = API.LORE_SCAN_MAX,
        LORE_SCAN_DEFAULT = API.LORE_SCAN_DEFAULT;
    /* The slider carries the number the PLAYER chose, not the effective window:
       with the card's lore order on, the book's own scan_depth may narrow it, and
       writing that narrowed figure back would keep the window small even after the
       mode is switched off again. */
    var loreScan = parseInt(char.loreScanTurns, 10) > 0 ? parseInt(char.loreScanTurns, 10) : LORE_SCAN_DEFAULT;
    var loreScanEff = API.loreScanTurns(char);
    var unreadLore = (char.lorebook || []).filter(function (e) {
      return e && (e.selectiveLogic !== undefined ||
        (e.selective !== undefined && e.selective !== true && e.selective !== false) ||
        (e.caseSensitive !== undefined && e.caseSensitive !== true && e.caseSensitive !== false));
    }).length;
    /* the six Horde-only fields, generated from the same list the prompt uses so
       the editor can never offer a field the sheet ignores, or omit one it reads */
    var DIR_CAP = (typeof Store.CARRY_CAP === 'number') ? Store.CARRY_CAP : 4000;
    var DIR_PROMPT = 600;
    var dirFields = (API.CARD_DIRECTIVES || []).map(function (pair) {
      var d = (char.directives || {})[pair[0]] || '';
      return '<div class="field"><div class="field-head"><label>' + pair[1] + '</label>' +
        '<span class="spacer"></span><span class="val" id="e-dir-' + pair[0] + '-n">' + d.length + ' / ' + DIR_CAP + '</span></div>' +
        '<textarea id="e-dir-' + pair[0] + '" maxlength="' + DIR_CAP + '" placeholder="">' + esc(d) + '</textarea>' +
        (d.length > DIR_PROMPT
          ? '<div class="hint">Only the first ' + DIR_PROMPT + ' characters of this reach the prompt. ' +
            'The rest stays in the card, so nothing you wrote is lost — it is simply not repeated to the ' +
            'model, which will not read past the budget anyway.</div>'
          : '') + '</div>';
    }).join('');
    $('#editor-body').innerHTML =
      '<div class="group">' +
        '<div class="field"><div class="avatar-edit" id="av-wrap">' +
          (char.avatar ? '<img src="' + esc(char.avatar) + '" alt="">' : '<div class="ph">' + icon('user') + '</div>') +
          '<div style="flex:1">' +
            '<button class="btn ghost sm block" data-act="av-url">Use image URL</button>' +
            '<button class="btn ghost sm block" style="margin-top:6px" data-act="av-file">Upload from phone</button>' +
            '<button class="btn ghost sm block" style="margin-top:6px" data-act="av-gen">Generate with ' + esc(App.imageProviderLabel(Store.settings.imageProvider)) + '</button>' +
          '</div>' +
        '</div></div>' +
      '</div>' +

      '<div class="group"><div class="group-title">Expression portraits · optional</div>' +
        '<div class="field"><div id="expression-portrait-list"></div>' +
          '<button class="btn ghost sm" data-act="expression-add">' + icon('plus') + ' Add expression</button>' +
          '<div class="hint">When internal state tracking is on, the reply’s mood can select a matching portrait. Images are display-only and never enter the prompt.</div></div>' +
      '</div>' +

      /* v1.29.0: pictures the card itself carries, besides the avatar.
         Display-only — never part of the prompt. */
      (char.images && char.images.length
        ? '<div class="group">' +
          '<div class="group-title">Card images</div>' +
          '<div class="field">' +
            '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(84px,1fr));gap:8px">' +
            char.images.map(function (im) {
              return '<img src="' + esc(im.src) + '" alt="' + esc(im.name || 'card image') + '"' +
                ' data-lightbox="' + esc(im.src) + '"' +
                ' style="width:100%;height:84px;object-fit:cover;border-radius:8px;cursor:zoom-in" loading="lazy">';
            }).join('') +
            '</div>' +
            '<div class="hint">From the card itself — for you to look at, never sent to the model.</div>' +
          '</div>' +
        '</div>'
        : '') +

      '<div class="group">' +
        '<div class="group-title">Identity</div>' +
        '<div class="field"><div class="field-head"><label>Name</label></div>' +
          '<input type="text" id="e-name" value="' + esc(char.name) + '" placeholder="e.g. Seraphine Vale"></div>' +
        '<div class="field"><div class="field-head"><label>Tagline</label></div>' +
          '<input type="text" id="e-tagline" value="' + esc(char.tagline) + '" placeholder="Short hook shown on the card"></div>' +
        '<div class="field"><div class="field-head"><label>Tags</label></div>' +
          '<input type="text" id="e-tags" value="' + esc((char.tags || []).join(', ')) + '" placeholder="fantasy, mentor, slow-burn"></div>' +
      '</div>' +

      (emptySheet
        ? '<div class="group">' +
          '<div class="group-title">Create with AI</div>' +
          '<div class="field"><div class="field-head"><label>Describe who they are</label></div>' +
            '<textarea id="ai-idea" placeholder="e.g. a grumpy blacksmith who owes the tavern a debt and secretly writes poetry — she has not spoken to her sister in nine years"></textarea>' +
            '<div class="hint">One or two lines is plenty. The model drafts the whole sheet — name, persona, opening line and their life — which you can then edit. Two small requests, spent only when you press the button.</div></div>' +
          '<div class="field"><button class="btn primary block sm" data-act="ai-create">' +
            icon('sparkle') + ' Draft the whole person (2 requests)</button></div>' +
        '</div>'
        : '') +

      '<div class="group">' +
        '<div class="group-title">Character sheet</div>' +
        '<div class="field"><div class="field-head"><label id="e-persona-label">' + (personaSplitOn ? 'Description · personality' : 'Persona') + '</label>' +
          '<span class="spacer"></span><button class="chip" data-act="ai-persona">' + icon('sparkle') + ' AI draft</button></div>' +
          /* v1.41.0 (review request 4): a card keeps these as TWO fields. Editing
             them as one has always merged both into `description` and emptied the
             card's `personality`; that path stays, and its consequence is now said
             out loud next to the switch that avoids it. */
          '<div class="seg" id="e-persona-mode" style="margin-bottom:8px">' +
            '<button data-a="one"' + (personaSplitOn ? '' : ' class="on"') + '>One box</button>' +
            '<button data-a="split"' + (personaSplitOn ? ' class="on"' : '') + '>The card\'s two fields</button>' +
          '</div>' +
          '<div id="e-persona-one"' + (personaSplitOn ? ' style="display:none"' : '') + '>' +
            '<textarea class="tall" id="e-persona" placeholder="Appearance, personality, history, wants, voice…">' + esc(char.persona) + '</textarea>' +
            (hasParts && !personaSplitOn
              ? '<div class="hint">This is the card\'s <code>description</code> and <code>personality</code> ' +
                'joined as one. Editing here <b>merges them</b>: the export writes all of it into ' +
                '<code>description</code> and leaves the card\'s <code>personality</code> field empty. ' +
                'Use “the card\'s two fields” to change one without touching the other.</div>'
              : '') +
          '</div>' +
          '<div id="e-persona-split"' + (personaSplitOn ? '' : ' style="display:none"') + '>' +
            '<div class="hint" style="margin-top:0">The two fields as the card keeps them. ' +
            'Changing one leaves the other as it is, and both go back out under their own names.</div>' +
            '<div id="e-persona-merge" hidden></div>' +
            '<textarea class="tall" id="e-desc" placeholder="Appearance, history, how they speak…">' + esc(descSeed) + '</textarea>' +
            '<div class="hint" style="margin:8px 0 4px">Personality (the card\'s own <code>personality</code> field)</div>' +
            '<textarea id="e-pers" placeholder="Short traits list, if the card keeps one.">' + esc(persSeed) + '</textarea>' +
          '</div>' +
        '<div class="field"><div class="field-head"><label>Scenario</label>' +
          Views.scenarioChip(char.scenarioList) +
          '<span class="spacer"></span><button class="chip" data-act="ai-scenario">' + icon('sparkle') + ' AI draft</button></div>' +
          '<textarea id="e-scenario" placeholder="Where the story starts.">' + esc(char.scenario) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Greeting (first message)</label>' +
          '<span class="spacer"></span><button class="chip" data-act="ai-greeting">' + icon('sparkle') + ' AI draft</button></div>' +
          /* v1.39.15: the field is ALL of the intros, not just the first —
             the same ‹ n / N › the chat puts on the opening bubble. */
          '<div class="row" style="align-items:center;gap:6px;margin-bottom:6px">' +
            '<button class="chip" data-act="intro-prev" aria-label="Previous intro">‹</button>' +
            '<span class="hint" style="margin:0">Intro</span>' +
            '<span class="val" id="e-intro-pos" style="min-width:38px;text-align:center">1 / ' + (1 + ((char.alternateGreetings && char.alternateGreetings.length) || 0)) + '</span>' +
            '<button class="chip" data-act="intro-next" aria-label="Next intro">›</button>' +
            '<span class="spacer"></span>' +
            '<button class="chip" data-act="intro-add">' + icon('plus') + ' Add intro</button>' +
            '<button class="chip" data-act="intro-del" id="e-intro-del" aria-label="Remove this intro" style="display:none">' + icon('trash') + '</button>' +
          '</div>' +
          '<textarea id="e-greeting" placeholder="The opening line {{char}} sends.">' + esc(char.greeting) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Example dialogue</label></div>' +
          '<textarea class="tall" id="e-examples" placeholder="{{user}}: …&#10;{{char}}: …">' + esc(char.examples) + '</textarea>' +
          '<div class="hint">Alternating {{user}}: / {{char}}: lines. Optional, but it nails the voice.</div></div>' +
        '<div class="field"><div class="field-head"><label>Always-remember note</label></div>' +
          /* The old placeholder promised the text was "appended last, right before the
   reply is generated". It is not: charSheet puts it at the end of the system
   block, above the examples and the transcript (api.js, `post`). Telling
   authors the wrong thing is how a card ends up with its most important rule
   sitting where the model weighs it least. */
'<textarea id="e-post" placeholder="Joins the end of the character sheet, above the examples and the chat history.">' + esc(char.postHistory) + '</textarea></div>' +
      '</div>' +

      /* ---------------- v1.40.0: the four things a card asks the app to do
         differently, each one a choice the player can see. Everything here
         starts at what this app has always done, so opening a card changes
         nothing until you say so. ---------------- */
      '<div class="group">' +
        '<div class="group-title">Card prompts and placement</div>' +
        '<div class="field"><div class="field-head"><label>System prompt</label>' +
          '<span class="spacer"></span><span class="val">' +
            (cardPrompt ? cardPrompt.length + ' characters in the card' : 'none in this card') + '</span></div>' +
          '<div class="seg" id="e-sys-src">' + sysSrc.map(function (k) {
            return '<button data-a="' + k + '"' + (sysSrcOn === k ? ' class="on"' : '') + '>' + SYS_SRC_LABEL[k] + '</button>';
          }).join('') + '</div>' +
          '<div class="hint">' +
            (cardPrompt
              ? 'Your text only. The card’s own prompt is shown below and used only if you pick it or “both”.'
              : 'This card carries no prompt, so every choice here gives the same result.') +
            ' A card that can replace the prompt can also delete the rules this app needs — plain prose, ' +
            'never narrating for you — so “the card’s” is deliberately not the default.</div>' +
          /* v1.41.0 (review issue 1): a card may ask for this in its own Horde
             fields. Asking is not having: the request is shown here, and one tap
             on the row above is what grants it. Nothing is written into the card
             to mark the grant, because a key a card can set is a key a card can
             grant itself. */
          ((sysSrcAsked === 'card' || sysSrcAsked === 'combine') && sysSrcOn !== sysSrcAsked
            ? '<div class="hint" style="margin-top:6px;color:var(--warn,#fbbf24)"><b>This card asked for “' +
              (sysSrcAsked === 'card' ? 'the card\'s' : 'both') + '” and this app did not apply it.</b> ' +
              'Pick “' + SYS_SRC_LABEL[sysSrcAsked] + '" above to grant it — your choice, not the card\'s.' +
              ((Store.settings && Store.settings.honorCardSystemPrompt) ? '' : ' Or switch on “Cards may choose their prompt” in Settings → System prompt to grant it for every card you import.') +
              '</div>'
            : '') +
          (cardPrompt
            ? '<details style="margin-top:8px"><summary class="hint" style="margin:0">Read the card’s prompt</summary>' +
                '<div class="hint" style="white-space:pre-wrap;margin-top:6px;max-height:14em;overflow:auto">' + esc(cardPrompt) + '</div>' +
                '<button class="chip" data-act="sys-use-card" style="margin-top:6px">Copy into my prompt</button></details>'
            : '') +
        '</div>' +
        '<div class="field"><div class="field-head"><label>Always-remember note</label></div>' +
          '<div class="seg" id="e-post-place">' + postPlace.map(function (k) {
            return '<button data-a="' + k + '"' + (postPlaceOn === k ? ' class="on"' : '') + '>' + POST_PLACE_LABEL[k] + '</button>';
          }).join('') + '</div>' +
          '<div class="hint">Where the text in that box goes. End of the character sheet is what this app ' +
          'has always done, and what most cards written for it expect; after the history puts it last, ' +
          'which some cards ask for. It is never sent twice.</div></div>' +
        '<div class="field compact"><label>Follow the card’s lore order</label>' +
          '<div class="toggle' + (char.loreCompat === true ? ' on' : '') + '" id="e-lore-compat"></div></div>' +
        '<div class="hint">Off, this app picks world facts by how recently their keywords appeared. On, the ' +
          'lorebook’s own <code>insertion_order</code> and <code>position</code> decide where each admitted ' +
          'entry sits, and <code>priority</code> decides what the card’s <code>token_budget</code> discards. ' +
          'Which entries get in stays the same either way.</div>' +
        '<div class="field"><div class="field-head"><label>Lore keyword window</label>' +
          '<span class="spacer"></span><span class="val" id="e-lore-scan-v">' + loreScan + ' turns back</span></div>' +
          '<div class="range-row"><input type="range" id="e-lore-scan" min="' + LORE_SCAN_MIN + '" max="' + LORE_SCAN_MAX +
            '" step="1" value="' + loreScan + '"><button class="chip" id="e-lore-scan-clear">default</button></div>' +
          '<div class="hint">How far back a trigger keyword is looked for. ' + LORE_SCAN_DEFAULT + ' turns is what ' +
          'this app measures, and widening it only lets more entries be <i>noticed</i> — the entry budget still ' +
          'decides what is sent. Bounded at ' + LORE_SCAN_MAX + '.' +
          (loreScanEff !== loreScan
            ? ' <b>This character is using ' + loreScanEff + '</b>: “follow the card’s lore order” lets the ' +
              'card’s own <code>scan_depth</code> shorten the window, never lengthen it.'
            : '') + '</div></div>' +
        (unreadLore ? '<div class="field"><div class="hint" style="color:var(--warn,#fbbf24);margin:0">' +
            unreadLore + ' ' + (unreadLore === 1 ? 'entry sets' : 'entries set') +
            ' a lorebook matching option this app cannot read (SillyTavern’s <code>selectiveLogic</code>, or ' +
            '<code>selective</code>/<code>case_sensitive</code> set to something other than true or false). ' +
            'The value stays in the card; matching here falls back to the documented rule. The Lore screen ' +
            'names the field on each entry.</div></div>' : '') +
      '</div>' +

      '<div class="group">' +
        '<div class="group-title">Instructions to this app</div>' +
        '<div class="hint">Six notes a card can leave for Horde Studio specifically. Every one is optional and ' +
          'off by default: left blank, nothing is added to the prompt at all. Written here, each one becomes a ' +
          'labelled line at the end of the character sheet, and they are stored in the card under ' +
          '<code>extensions.horde_studio</code> — so they survive an export and an import by another app.</div>' +
        dirFields +
      '</div>' +

      '<div class="group">' +
        '<div class="group-title">Virtual human</div>' +
        '<div class="field compact"><label>Give them their own life</label>' +
          '<div class="toggle' + (vh_enabled ? ' on' : '') + '" id="vh-on"></div></div>' +
        '<div id="vh-fields"' + (vh_enabled ? '' : ' hidden') + '>' +
          '<div class="field"><div class="field-head"><label>Reaches out to you</label></div>' +
            '<div class="seg" id="vh-auto">' + ['off', 'low', 'medium', 'high'].map(function (k) {
              return '<button data-a="' + k + '"' + (vh.autonomy === k ? ' class="on"' : '') + '>' +
                ({ off: 'Never', low: 'Rarely', medium: 'Sometimes', high: 'Often' })[k] + '</button>';
            }).join('') + '</div>' +
            '<div class="hint">Never = they only answer you. Often = they message on their own every couple of hours.</div></div>' +
          '<div class="field"><div class="field-head"><label>Asleep</label></div>' +
            '<div class="row"><input type="time" id="vh-sleep-start" value="' + esc(vh.sleep.start) + '" style="flex:1">' +
            '<input type="time" id="vh-sleep-end" value="' + esc(vh.sleep.end) + '" style="flex:1"></div>' +
            '<div class="hint">While asleep they do not answer — the message waits until they wake.</div></div>' +
          '<div class="field"><div class="field-head"><label>Takes this long to reply</label>' +
            '<span class="spacer"></span><span class="val" id="vh-dmin-v">' + vh.replyDelay.min + 's – ' + vh.replyDelay.max + 's</span></div>' +
            '<div class="range-row"><span class="hint">min</span><input type="range" id="vh-dmin" min="0" max="180" step="5" value="' + vh.replyDelay.min + '"></div>' +
            '<div class="range-row"><span class="hint">max</span><input type="range" id="vh-dmax" min="15" max="900" step="15" value="' + vh.replyDelay.max + '"></div></div>' +
          '<div class="field compact"><label>Sends photos</label><div class="toggle' + (vh.photos ? ' on' : '') + '" id="vh-photos"></div></div>' +
          '<div class="field"><div class="field-head"><label>Daily routine</label></div>' +
            '<div id="vh-routine"></div>' +
            '<button class="btn ghost sm block" id="vh-add" style="margin-top:8px">' + icon('plus') + ' Add time of day</button>' +
            '<div class="hint">What they are doing, from that hour onward. Drives their status and what they talk about.</div></div>' +
          '<div class="field"><div class="field-head"><label>Inner state</label></div>' +
            slider('vh-mood', 'Mood', vh.mood) +
            slider('vh-aff', 'Affinity', vh.affinity) +
            slider('vh-trust', 'Trust', vh.trust) +
            slider('vh-ten', 'Tension', vh.tension) +
            '<div class="hint">Drifts on its own as time passes and as you talk. Drag to steer the relationship.</div></div>' +
          '<div class="field"><div class="field-head"><label>Places in their life</label></div>' +
            '<div id="vh-places"></div>' +
            '<button class="btn ghost sm block" id="vh-add-place" style="margin-top:8px">' + icon('plus') + ' Add a place</button>' +
            '<div class="hint">Where their day happens. They travel between these in real time, and being somewhere else is why they took so long to answer.</div>' +
            '<div id="vh-world"></div>' +
            '<button class="btn ghost sm block" id="vh-world-pack" style="margin-top:8px">' + icon('download') + ' Load a world pack</button></div>' +
          '<div class="field"><div class="field-head"><label>People in their life</label></div>' +
            '<div id="vh-people"></div>' +
            '<button class="btn ghost sm block" id="vh-add-person" style="margin-top:8px">' + icon('plus') + ' Add a person</button>' +
            '<div class="hint">The supporting cast — colleagues, neighbours, family. They come up in conversation and give them something to talk about besides you.</div></div>' +
          '<div class="field"><div class="field-head"><label>Standing diary</label></div>' +
            '<div id="vh-cal"></div>' +
            '<button class="btn ghost sm block" id="vh-add-cal" style="margin-top:8px">' + icon('plus') + ' Add to the diary</button>' +
            '<div class="hint">Repeating commitments: a shift, a class, a standing dinner. They head off to these.</div></div>' +
          '<div class="field"><div class="field-head"><label>Texts in one go</label>' +
            '<span class="spacer"></span><span class="val" id="vh-burst-v">' + (vh.burst || 3) + '</span></div>' +
            '<div class="range-row"><input type="range" id="vh-burst" min="1" max="4" step="1" value="' + (vh.burst || 3) + '"></div>' +
            '<div class="hint">Most separate bubbles they may send in one reply, when what they wrote reads as several short texts rather than one paragraph.</div></div>' +
        '</div>' +
      '</div>' +

      (char.vh
        ? ''
        : '<div class="group">' +
          '<div class="group-title">Internal state</div>' +
          '<div class="field compact"><label>Track internal state</label>' +
            '<div class="toggle' + (char.stateTracking === true ? ' on' : '') + '" id="t-istate"></div></div>' +
          '<div id="istate-fields"' + (char.stateTracking === true ? '' : ' hidden') + '>' +
            '<div class="field"><div class="field-head"><label>Mood</label></div>' +
              '<input type="text" id="e-mood" value="' + esc(((char.state || {}).mood) || '') + '" placeholder="weary but fond"></div>' +
            '<div class="field"><div class="field-head"><label>Intent</label></div>' +
              '<input type="text" id="e-intent" value="' + esc(((char.state || {}).intent) || '') + '" placeholder="what they are trying to do next"></div>' +
            '<div class="field"><div class="field-head"><label>Flags</label></div>' +
              '<input type="text" id="e-flags" value="' + esc(((char.state || {}).flags) || '') + '" placeholder="details worth remembering, comma-separated"></div>' +
            '<div class="hint">When on, the current state is sent with every request and the model ends each ' +
            'reply with an updated one (hidden from you) — so mood, plans and small plot turns carry ' +
            'across long chats without you repeating them. A strip at the top of the chat shows it live. ' +
            'Costs a few dozen extra tokens per reply. Virtual humans keep their own simulation-driven ' +
            'Inner state instead.</div>' +
          '</div>' +
        '</div>') +

      '<div class="group">' +
        '<div class="group-title">Character lorebook</div>' +
        '<div class="field"><div class="hint" style="margin:0">Optional facts for this character. Trigger keywords determine when each entry joins the prompt.</div></div>' +
        '<div id="char-lorebook-rows"></div>' +
        '<div class="field"><div class="row">' +
          '<button class="btn ghost sm" style="flex:1" data-act="lore-add-entry">' + icon('plus') + ' Add entry</button>' +
          '<button class="btn ghost sm" style="flex:1" data-act="lore-import-file">' + icon('upload') + ' Import file</button>' +
        '</div><div class="row" style="margin-top:8px">' +
          '<button class="btn ghost sm block" data-act="lore-ai-draft">' + icon('sparkle') + ' Draft with AI</button>' +
        '</div><div class="hint" style="margin:6px 0 0">Import a lorebook JSON file; existing entries stay. SillyTavern exports are supported.</div></div>' +
      '</div>' +

      '<div class="group">' +
        '<div class="group-title">Overrides (optional)</div>' +
        '<div class="field"><div class="field-head"><label>System prompt override</label></div>' +
          '<textarea id="e-sys" placeholder="Blank = use the global system prompt.">' + esc(char.systemPrompt) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Temperature</label><span class="spacer"></span><span class="val" id="v-ctemp">' +
            (char.temperature === null || char.temperature === undefined ? 'global' : char.temperature) + '</span></div>' +
          '<div class="range-row"><input type="range" id="e-temp" min="0" max="2" step="0.05" value="' +
            (char.temperature === null || char.temperature === undefined ? 0.85 : char.temperature) + '">' +
            '<button class="chip" id="e-temp-clear">global</button></div></div>' +
      '</div>' +

      '<div class="group">' +
        '<div class="field"><div class="row">' +
          '<button class="btn primary" style="flex:1" data-act="save">' + icon('edit') + ' Save character</button>' +
          (isNew ? '' : '<button class="btn danger" data-act="delete">' + icon('trash') + '</button>') +
        '</div></div>' +
      '</div>';

    var body = $('#editor-body');
    var draft = Object.assign({}, char);
    draft.expressionPortraits = (Array.isArray(draft.expressionPortraits) ? draft.expressionPortraits : []).map(function (e) {
      return Object.assign({}, e || {}, { keys: Array.isArray(e && e.keys) ? e.keys.slice() : String(e && e.keys || '').split(',').map(function (k) { return k.trim(); }).filter(Boolean) });
    });
    draft.lorebook = (Array.isArray(draft.lorebook) ? draft.lorebook : []).map(function (e) {
      var item = Object.assign({}, e || {});
      item.keys = Array.isArray(item.keys) ? item.keys.slice() : String(item.keys || '').split(',').map(function (k) { return k.trim(); }).filter(Boolean);
      if (item.enabled === undefined) item.enabled = true;
      return item;
    });
    function renderCharLorebook() {
      var box = $('#char-lorebook-rows', body);
      if (!box) return;
      if (!draft.lorebook.length) {
        box.innerHTML = '<div class="field"><span class="hint">No character lore entries yet.</span></div>';
        return;
      }
      box.innerHTML = draft.lorebook.map(function (entry, i) {
        return '<div class="field" data-char-lore="' + i + '">' +
          '<div class="row" style="margin-bottom:6px"><input type="text" data-cl-keys="' + i + '" value="' +
            esc((entry.keys || []).join(', ')) + '" placeholder="Trigger keywords" style="flex:1">' +
            '<button class="chip" data-cl-delete="' + i + '" aria-label="Remove lore entry">' + icon('trash') + '</button></div>' +
          '<textarea data-cl-content="' + i + '" placeholder="Lore content">' + esc(entry.content || '') + '</textarea>' +
          '<div class="field compact" style="padding:6px 0 0"><label>Enabled</label><div class="toggle' +
            (entry.enabled !== false ? ' on' : '') + '" data-cl-enabled="' + i + '"></div></div>' +
        '</div>';
      }).join('');
      box.querySelectorAll('[data-cl-keys]').forEach(function (el) {
        el.oninput = function () { draft.lorebook[+el.getAttribute('data-cl-keys')].keys = el.value.split(',').map(function (k) { return k.trim(); }).filter(Boolean); };
      });
      box.querySelectorAll('[data-cl-content]').forEach(function (el) {
        el.oninput = function () { draft.lorebook[+el.getAttribute('data-cl-content')].content = el.value; };
      });
      box.querySelectorAll('[data-cl-enabled]').forEach(function (el) {
        el.onclick = function () {
          var entry = draft.lorebook[+el.getAttribute('data-cl-enabled')];
          entry.enabled = entry.enabled === false;
          el.classList.toggle('on', entry.enabled !== false);
        };
      });
      box.querySelectorAll('[data-cl-delete]').forEach(function (el) {
        el.onclick = function () { draft.lorebook.splice(+el.getAttribute('data-cl-delete'), 1); renderCharLorebook(); };
      });
    }
    renderCharLorebook();
    function renderExpressionPortraits() {
      var box = $('#expression-portrait-list', body);
      if (!box) return;
      if (!draft.expressionPortraits.length) {
        box.innerHTML = '<div class="hint" style="margin:0 0 8px">No expression portraits added.</div>';
        return;
      }
      box.innerHTML = draft.expressionPortraits.map(function (entry, i) {
        return '<div class="field" style="border:1px solid var(--line);border-radius:10px;padding:10px;margin-bottom:8px">' +
          '<div class="row" style="gap:6px;margin-bottom:6px"><input type="text" data-expr-label="' + i + '" value="' + esc(entry.label || '') + '" placeholder="Expression label, e.g. amused" style="flex:1">' +
            '<button class="chip" data-expr-remove="' + i + '" aria-label="Remove expression">' + icon('trash') + '</button></div>' +
          '<input type="text" data-expr-keys="' + i + '" value="' + esc((entry.keys || []).join(', ')) + '" placeholder="Mood keywords, e.g. amused, pleased, teasing">' +
          '<div class="row" style="gap:6px;margin-top:6px"><input type="text" data-expr-src="' + i + '" value="' + esc(entry.src || '') + '" placeholder="Image URL or upload" style="flex:1;min-width:0">' +
            '<button class="chip" data-expr-file="' + i + '">Upload</button></div>' +
          (entry.src ? '<img src="' + esc(entry.src) + '" alt="' + esc(entry.label || 'expression portrait') + '" style="width:64px;height:64px;object-fit:cover;border-radius:8px;margin-top:7px" loading="lazy">' : '') +
        '</div>';
      }).join('');
      box.querySelectorAll('[data-expr-label]').forEach(function (el) {
        el.oninput = function () { draft.expressionPortraits[+el.getAttribute('data-expr-label')].label = el.value; };
      });
      box.querySelectorAll('[data-expr-keys]').forEach(function (el) {
        el.oninput = function () { draft.expressionPortraits[+el.getAttribute('data-expr-keys')].keys = el.value.split(',').map(function (k) { return k.trim(); }).filter(Boolean); };
      });
      box.querySelectorAll('[data-expr-src]').forEach(function (el) {
        el.oninput = function () {
          draft.expressionPortraits[+el.getAttribute('data-expr-src')].src = el.value.trim();
          var preview = el.closest('.field').querySelector('img');
          if (preview) preview.src = el.value.trim();
        };
      });
      box.querySelectorAll('[data-expr-remove]').forEach(function (el) {
        el.onclick = function () { draft.expressionPortraits.splice(+el.getAttribute('data-expr-remove'), 1); renderExpressionPortraits(); };
      });
      box.querySelectorAll('[data-expr-file]').forEach(function (el) {
        el.onclick = function () {
          var index = +el.getAttribute('data-expr-file');
          pickFile('image/*').then(function (file) {
            if (!file) return;
            return normalizeImage(file).then(function (src) {
              draft.expressionPortraits[index].src = src;
              renderExpressionPortraits();
            });
          }).catch(function () { UI.toast('Could not load that portrait', 3500); });
        };
      });
    }
    renderExpressionPortraits();
    on(body, '[data-act=expression-add]', 'click', function () {
      draft.expressionPortraits.push({ id: UI.uid('expr'), label: '', keys: [], src: '' });
      renderExpressionPortraits();
      var first = body.querySelector('[data-expr-label="' + (draft.expressionPortraits.length - 1) + '"]');
      if (first) first.focus();
    });
    /* The swipeable intro stack for the Greeting field — slots copy the
       texts, so browsing around never touches the sheet until collect(). */
    /* v1.40.0 handlers. Segmented controls keep the vh-auto idiom: the choice
       lives on `draft` only when collect() runs, so cancelling the sheet cannot
       leave a half-applied placement behind. */
    function segWire(id, set) {
      var el = $('#' + id, body);
      if (!el) return;
      el.onclick = function (e) {
        var b = e.target.closest('button'); if (!b) return;
        set(b.getAttribute('data-a'));
        this.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
      };
    }
    segWire('e-sys-src', function (v) { sysSrcOn = v; });
    segWire('e-post-place', function (v) { postPlaceOn = v; });
    /* The persona mode switch. Both boxes stay in the DOM and mirror each other,
       so switching back and forth inside one edit cannot drop text, and the AI
       draft buttons — which read the combined box — always see what is there. */
    /* v1.41.1 (review finding A). Both representations stay in the DOM, so the
       switch is a question of which one is LOOKED AT — and until now, switching
       could throw away whichever text was not. Typing in the one box and opening
       the two fields showed the stale halves; switching back overwrote the typing
       with them; saving exported them. Nothing was lost of the card's, but the
       user's own sentence was, silently, which is the one thing an editor may not
       do. The switch now reconciles: the text that is there wins, the merge it
       implies is said out loud, and the card's halves stay one tap away for as
       long as the sheet is open, so the reconciliation is reversible. */
    function personaJoinOf(desc, pers) {
      return [desc, pers].filter(function (t) { return String(t || '').trim(); }).join('\n\n');
    }
    function personaHalves() {
      var d = $('#e-desc', body), pr = $('#e-pers', body);
      return { desc: d ? String(d.value || '') : '', pers: pr ? String(pr.value || '') : '' };
    }
    function personaMergeSay(shown) {
      var box = $('#e-persona-merge', body);
      if (!box) return;
      if (!shown) { box.innerHTML = ''; box.hidden = true; return; }
      box.hidden = false;
      box.innerHTML = '<div class="hint" style="margin:6px 0 4px;color:var(--warn,#fbbf24)">' +
        '<b>Your text could not be split back into two fields, so it is kept whole as the ' +
        'description and the card’s personality is set aside for now.</b> Nothing is saved yet — ' +
        'this is still the draft in front of you.</div>' +
        '<button class="chip" id="e-persona-restore">Use the card’s two fields instead</button>';
      var back = $('#e-persona-restore', body);
      if (back) back.onclick = function () {
        var d = $('#e-desc', body), pr = $('#e-pers', body);
        if (d) d.value = personaUndo.desc;
        if (pr) pr.value = personaUndo.pers;
        personaJoin();
        personaEdited = null;
        personaMergeSay(null);
        UI.toast('The card’s own halves are back — your sentence is in neither box now, so ' +
          'switch to one box and paste it if you still want it');
      };
    }
    var personaEdited = null;            /* 'one' | 'split' | null — where text was last typed */
    var personaUndo = null;
    function personaJoin() {
      var d = $('#e-desc', body), pr = $('#e-pers', body), one = $('#e-persona', body);
      if (!d || !one) return;
      var joined = personaJoinOf(d.value, pr ? pr.value : '');
      if (one.value !== joined) one.value = joined;
    }
    function splitFromCombined() {
      var d = $('#e-desc', body), pr = $('#e-pers', body), one = $('#e-persona', body);
      if (!d || !one) return;
      if (one.value === personaJoinOf(d.value, pr ? pr.value : '')) return;   /* both agree */
      /* They do not: one of them holds typing the other has never seen. Keep it. */
      personaUndo = { desc: d.value, pers: pr ? pr.value : '' };
      d.value = one.value;
      if (pr) pr.value = '';
      personaEdited = 'one';
      if (hasParts) personaMergeSay('merged');
    }
    segWire('e-persona-mode', function (v) {
      personaSplitOn = v === 'split';
      var oneBox = $('#e-persona-one', body), two = $('#e-persona-split', body);
      if (personaSplitOn) {
        splitFromCombined();
        if (two) two.style.display = '';
        if (oneBox) oneBox.style.display = 'none';
      } else {
        personaJoin();
        if (two) two.style.display = 'none';
        if (oneBox) oneBox.style.display = '';
      }
      /* the note is only true while the two disagree */
      if (personaUndo && !personaSplitOn) personaMergeSay(null);
      /* looked up by its own id rather than by climbing parentNode from a control:
         that walk is the only reason this handler could touch a null, and an id is
         the same length once the markup is read */
      var lab = $('#e-persona-label', body);
      if (lab) lab.textContent = personaSplitOn ? 'Description · personality' : 'Persona';
    });
    ['#e-desc', '#e-pers'].forEach(function (sel) {
      var el = $(sel, body);
      if (el) el.oninput = function () { personaEdited = 'split'; personaJoin(); };
    });
    (function () {
      var one = $('#e-persona', body);
      if (one) one.oninput = function () {
        personaEdited = 'one';
        /* typed while the halves are also on screen: they cannot follow a merge,
           so say what saving will do instead of letting them find out later */
        if (personaSplitOn) personaMergeSay('merged');
      };
    })();
    var loreCompatEl = $('#e-lore-compat', body);
    if (loreCompatEl) loreCompatEl.onclick = function () {
      this.classList.toggle('on');
    };
    var loreScanEl = $('#e-lore-scan', body), loreScanV = $('#e-lore-scan-v', body);
    if (loreScanEl) loreScanEl.oninput = function () {
      loreScanV.textContent = loreScanEl.value + ' turns back';
    };
    var loreScanClear = $('#e-lore-scan-clear', body);
    if (loreScanClear) loreScanClear.onclick = function () {
      loreScanEl.value = API.LORE_SCAN_DEFAULT;
      loreScanV.textContent = API.LORE_SCAN_DEFAULT + ' turns back';
    };
    var useCard = body.querySelector('[data-act=sys-use-card]');
    if (useCard) useCard.onclick = function () {
      var box = $('#e-sys', body);
      if (!box) return;
      var cur = String(box.value || '').trim();
      /* appending, not replacing: the override box may already hold the player's
         own rules, and a card prompt is not a reason to lose them */
      box.value = (cur ? cur + '\n\n' : '') + cardPrompt;
      box.dispatchEvent(new Event('input', { bubbles: true }));
      UI.toast('Card prompt added to your override');
    };
    (API.CARD_DIRECTIVES || []).forEach(function (pair) {
      var el = $('#e-dir-' + pair[0], body), n = $('#e-dir-' + pair[0] + '-n', body);
      if (el) el.oninput = function () { n.textContent = el.value.length + ' / ' + DIR_CAP; };
    });

    var introNav = Views.introNavModel(draft);
    function introPaint() {
      var g = $('#e-greeting', body), pos = $('#e-intro-pos', body), del = $('#e-intro-del', body);
      if (g) g.value = introNav.text();
      if (pos) pos.textContent = introNav.label();
      if (del) del.style.display = introNav.index() > 0 ? '' : 'none';
    }

    function collect() {
      draft.name = $('#e-name', body).value.trim();
      draft.tagline = $('#e-tagline', body).value.trim();
      draft.tags = $('#e-tags', body).value.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
      /* v1.41.1 (review finding B). This used to write `descText = persona,
         persText = ''` on EVERY save made while the one box was showing, edited
         or not — so fixing a greeting quietly collapsed the card's two fields,
         and the split editor then opened on a description holding both halves and
         a personality gone. Saving an unrelated field may not answer a question
         nobody asked. The rule now: the halves survive unless the combined text
         says something the halves do not, and the mode the text was last typed in
         decides which representation is authoritative. */
      var halves = personaHalves();
      var oneVal = $('#e-persona', body) ? String($('#e-persona', body).value || '') : '';
      var joined = personaJoinOf(halves.desc, halves.pers);
      if (personaSplitOn || personaEdited === 'split') {
        draft.descText = halves.desc;
        draft.persText = halves.pers;
        draft.persona = personaJoinOf(halves.desc, halves.pers);
        draft.personaSplit = true;
      } else {
        draft.persona = oneVal;
        var hadHalves = typeof char.descText === 'string' || typeof char.persText === 'string';
        if (hadHalves && oneVal === joined) {
          draft.descText = halves.desc;
          draft.persText = halves.pers;
          draft.personaSplit = char.personaSplit === true;
        } else {
          draft.descText = oneVal;
          draft.persText = '';
          draft.personaSplit = false;
        }
      }
      draft.scenario = $('#e-scenario', body).value;
      /* fold the box back into the intro slot on show FIRST — saving while
         looking at intro k must not clobber the main greeting */
      introNav.set($('#e-greeting', body).value);
      introNav.collect();
      draft.examples = $('#e-examples', body).value;
      draft.postHistory = $('#e-post', body).value;
      draft.systemPrompt = $('#e-sys', body).value;
      /* v1.40.0: the placement choices and the six Horde instructions. The
         directives are trimmed here as well as at import, so a character created
         in the app carries the same limits as a card that arrived with them. */
      draft.postHistoryPlacement = postPlaceOn;
      /* '' means "nobody has decided", so it is only left alone when there is
         nothing to decide: a card that asked for its own prompt has to be
         refused out loud (and that refusal is what survives an export). */
      draft.systemPromptSource = sysSrcOn === 'app' ? (draft.systemPromptAsked ? 'app' : '') : sysSrcOn;
      draft.systemPromptAsked = sysSrcAsked;
      draft.loreCompat = !!($('#e-lore-compat', body) && $('#e-lore-compat', body).classList.contains('on'));
      draft.loreScanTurns = parseInt(($('#e-lore-scan', body) || {}).value, 10) || 0;
      if (draft.loreScanTurns === API.LORE_SCAN_DEFAULT) draft.loreScanTurns = 0;
      draft.loreScanTurns = Math.min(API.LORE_SCAN_MAX, Math.max(0, draft.loreScanTurns));
      draft.directives = {};
      (API.CARD_DIRECTIVES || []).forEach(function (pair) {
        var el = $('#e-dir-' + pair[0], body);
        draft.directives[pair[0]] = el ? String(el.value || '').trim().slice(0, DIR_CAP) : '';
      });
      draft.expressionPortraits = draft.expressionPortraits.filter(function (e) {
        return !!String(e.src || '').trim() && (!!String(e.label || '').trim() || (e.keys && e.keys.length));
      }).map(function (e) {
        return { id: e.id || UI.uid('expr'), label: String(e.label || '').trim(),
          keys: (e.keys || []).slice(), src: String(e.src || '').trim() };
      });
      if ($('#e-mood', body)) {
        var oldSt = draft.state || {};
        var newSt = {
          mood: $('#e-mood', body).value.trim(),
          intent: $('#e-intent', body).value.trim(),
          flags: $('#e-flags', body).value.trim()
        };
        var changed = newSt.mood !== (oldSt.mood || '') ||
          newSt.intent !== (oldSt.intent || '') || newSt.flags !== (oldSt.flags || '');
        draft.state = Object.assign({}, oldSt, newSt,
          changed ? { updatedAt: Date.now(), by: 'user' } : {});
      }
      return draft;
    }

    /* v1.29.0: the card's own pictures open full-screen on tap */
    on(body, '[data-lightbox]', 'click', function (e) {
      UI.lightbox(e.currentTarget.getAttribute('data-lightbox'));
    });
    on(body, '[data-act=lore-add-entry]', 'click', function () {
      draft.lorebook.push({ id: UI.uid('l'), keys: [], content: '', enabled: true });
      renderCharLorebook();
      var last = body.querySelector('[data-cl-keys="' + (draft.lorebook.length - 1) + '"]');
      if (last) last.focus();
    });
    on(body, '[data-act=lore-import-file]', 'click', function () {
      pickFile('.json,application/json').then(function (file) {
        if (!file) return;
        if (file.size > 5 * 1024 * 1024) return UI.toast('That lorebook file is over 5 MB.', 4500);
        var read = typeof file.text === 'function' ? file.text() : new Promise(function (resolve, reject) {
          var reader = new FileReader();
          reader.onload = function () { resolve(reader.result); };
          reader.onerror = reject;
          reader.readAsText(file);
        });
        return read.then(function (text) {
          var entries = API.parseLorebookFile(text);
          if (!entries.length) return UI.toast('No supported lorebook entries found in that JSON file.', 5000);
          function signature(entry) {
            return (entry.keys || []).map(function (k) { return String(k).toLowerCase(); }).sort().join('\\u0001') +
              '|' + String(entry.content || '').trim().toLowerCase();
          }
          var known = {};
          draft.lorebook.forEach(function (entry) { known[signature(entry)] = true; });
          var added = 0;
          entries.forEach(function (entry) {
            var sig = signature(entry);
            if (known[sig]) return;
            known[sig] = true;
            entry.id = UI.uid('l');
            draft.lorebook.push(entry);
            added++;
          });
          if (!added) return UI.toast('Those lorebook entries are already here.', 4000);
          renderCharLorebook();
          UI.toast('Imported ' + added + ' lore entr' + (added === 1 ? 'y' : 'ies') + ' — edit, then Save');
        });
      }).catch(function (e) { UI.toast('Lorebook import failed: ' + (e && e.message || 'could not read file'), 5000); });
    });
    on(body, '[data-act=lore-ai-draft]', 'click', function () {
      var name = $('#e-name', body).value.trim() || 'the character';
      var persona = $('#e-persona', body).value.trim().slice(0, 500);
      var scenario = $('#e-scenario', body).value.trim().slice(0, 250);
      UI.toast('Drafting character lore…');
      API.quickText(Store.settings,
        'Create 3 distinct, concise character lorebook entries for ' + name +
        (persona ? '. Persona: ' + persona : '') + (scenario ? '. Story setting: ' + scenario : '') +
        '. Return exactly three lines, no markdown. Each line must be: trigger keywords | factual lore content. ' +
        'Use 1-3 comma-separated trigger keywords and one short, reusable fact per line. Do not write actions or dialogue for the player.',
        360, 0.3).then(function (text) {
          var entries = API.parseLoreDraft(text || '');
          if (!entries.length) return UI.toast('No lore entries came back; you can add them manually.', 5000);
          entries.forEach(function (e) { e.id = UI.uid('l'); });
          draft.lorebook = draft.lorebook.concat(entries);
          renderCharLorebook();
          UI.toast(entries.length + ' lore entr' + (entries.length === 1 ? 'y' : 'ies') + ' drafted — edit, then Save');
        }).catch(function (e) { UI.toast('Lore draft failed: ' + e.message, 4500); });
    });

    on(body, '[data-act=av-url]', 'click', function () {
      UI.input('Avatar image URL').then(function (url) {
        if (!url) return;
        draft.avatar = url.trim();
        $('#av-wrap', body).querySelector('img,.ph').outerHTML = '<img src="' + esc(draft.avatar) + '" alt="">';
      });
    });
    on(body, '[data-act=av-file]', 'click', function () {
      pickFile('image/*').then(function (f) {
        if (!f) return;
        /* 18.2.0: import through the normalizer — downscaled, re-encoded,
           transparency kept — before it lands in IndexedDB. */
        normalizeImage(f).then(function (d) {
          draft.avatar = d;
          var w = $('#av-wrap', body).querySelector('img,.ph');
          w.outerHTML = '<img src="' + esc(d) + '" alt="">';
        });
      });
    });
    on(body, '[data-act=av-gen]', 'click', function () {
      App.generateAvatar(draft).then(function (url) {
        if (!url) return;
        draft.avatar = url;
        var w = $('#av-wrap', body).querySelector('img,.ph');
        w.outerHTML = '<img src="' + esc(url) + '" alt="">';
      });
    });
    on(body, '[data-act=ai-persona]', 'click', function () {
      var name = $('#e-name', body).value.trim();
      if (!name) { UI.toast('Add a name first'); return; }
      UI.toast('Asking the model…');
      /* 18.1.0: a drafted persona keeps the direction the player gave instead
         of being normalised into an agreeable template. One bounded request,
         one field — the draft fills the persona box and nothing else. */
      API.quickText(Store.settings,
        'Write a roleplay character persona for a character named ' + name +
        (draft.tagline
          ? ' — their direction is "' + draft.tagline + '". Follow it exactly: if it describes an unsettling, obsessive, antagonistic, eccentric or solitary person, write that person, not a likable version of them. '
          : '. ') +
        'Use third person, under 200 words. Cover: appearance, personality (strengths and flaws as they actually are), wants, and how they speak. No headings.',
        320).then(function (txt) {
          /* v1.41.0: with the card's two fields open, a drafted persona is a
             description — writing it into the hidden combined box would have been
             collected and thrown away. */
          if (personaSplitOn) {
            $('#e-desc', body).value = txt.trim();
            personaJoin();
          } else $('#e-persona', body).value = txt.trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });

    /* 18.1.0: the whole-person draft is TWO bounded JSON requests, each
     * under the Horde's 512-token anonymous limit, so heavy demand cannot
     * reject the job over pre-held kudos. Part one (the person) lands in the
     * sheet fields as it comes; a partial life response is salvaged and the
     * editor falls back to its defaults rather than discarding the person.
     * It only offers itself on an empty sheet, keeps the player's direction,
     * and never overwrites a field the player already wrote by hand.
     * Opening the editor spends nothing. */
    on(body, '[data-act=ai-create]', 'click', function () {
      var idea = $('#ai-idea', body).value.trim();
      if (!idea) { UI.toast('Describe who they are, even one line'); return; }
      var btn = this; btn.disabled = true;
      UI.toast('Drafting the person — 1 of 2…');
      /* 1/2 the person: name, voice, opening — the direction lives here */
      API.aiJson(Store.settings,
        'You are helping create a roleplay character. The player\'s direction: "' +
        idea + '". Preserve that direction exactly — if it describes an unsettling, ' +
        'obsessive, antagonistic, eccentric or solitary person, create that person, ' +
        'not a likable or tamed version of them. ' +
        'Return ONLY a JSON object, no markdown, no commentary, with exactly these keys: ' +
        '{"name":string (use the direction\'s name if it gives one, else invent a fitting one), ' +
        '"tagline":string (8-12 words, the hook shown on the card), ' +
        '"persona":string (third person, under 100 words: appearance, personality with real flaws, a short history, what they want, how they speak), ' +
        '"scenario":string (1-2 sentences: where the story starts, with a small hook or tension), ' +
        '"greeting":string (the character\'s first message to the player, 1-2 sentences, in their voice), ' +
        '"examples":string (one short {{user}}: and {{char}}: exchange that pins the voice)}',
        450, null, 'character').then(function (a) {
          if (!a || !a.persona) {
            btn.disabled = false;
            return UI.toast('The model returned no character description. Try again or check provider settings.', 5500);
          }
          /* name/tagline only if the player left them empty — set the inputs,
             collect() below picks them up like any other field */
          if (a.name && !$('#e-name', body).value.trim()) $('#e-name', body).value = String(a.name).trim().slice(0, 60);
          if (a.tagline && !$('#e-tagline', body).value.trim()) $('#e-tagline', body).value = String(a.tagline).trim().slice(0, 140);
          if (a.persona) {
            var pTxt = String(a.persona).trim().slice(0, 2400);
            if (personaSplitOn) { $('#e-desc', body).value = pTxt; personaJoin(); }
            else $('#e-persona', body).value = pTxt;
          }
          if (a.scenario) $('#e-scenario', body).value = String(a.scenario).trim().slice(0, 600);
          if (a.greeting) $('#e-greeting', body).value = String(a.greeting).trim().slice(0, 600);
          if (a.examples) $('#e-examples', body).value = String(a.examples).trim().slice(0, 1200);
          /* 2/2 the life around the story, conditioned on the person. Use a
             short labeled-text format rather than fragile nested JSON. */
          UI.toast('Now their life — 2 of 2…');
          var who = ($('#e-name', body).value.trim() || 'the character');
          var personaClip = String(a.persona).trim().slice(0, 300);
          return API.quickText(Store.settings,
            'Draft a compact daily life for ' + who +
            (personaClip ? ', whose persona is: "' + personaClip + '"' : '') + '. ' +
            'Return exactly these six plain-text lines, not JSON, with short values and no extra commentary:\n' +
            'Home: place name | one detail\nStudy/work: place name | one detail\n' +
            'Routine: HH:MM short activity; HH:MM short activity; HH:MM short activity\n' +
            'Sleep: HH:MM-HH:MM\nPeople: name — relation; name — relation\n' +
            'Diary: one short past-tense sentence.',
            480, 0.3).then(function (lifeText) {
              var b = API.parseLifeNotes(lifeText);
              var lifeParsed = !!b;
              var lifeRemainder = String(lifeText || '').trim();
              if (!b) b = { places: [], routine: [], sleep: null, people: [], diary: [] };
              if (!lifeParsed && lifeRemainder) {
                vh.chronicle = (vh.chronicle || []).concat([{ ts: Date.now(), text: lifeRemainder.slice(0, 600) }]).slice(-20);
              }
              /* Fill only what came back clean; untouched fields keep the
                 character's safe defaults so a bad response never blocks Save. */
              if (Array.isArray(b.places) && b.places.length) {
                var places = b.places.filter(function (p) { return p && p.name; }).slice(0, 8).map(function (p, i) {
                  return { id: (typeof p.id === 'string' && /^[\w-]+$/.test(p.id)) ? p.id : 'place_' + i,
                    name: String(p.name).slice(0, 60), kind: String(p.kind || 'other').slice(0, 20),
                    note: String(p.note || '').slice(0, 160) };
                });
                if (places.length) { vh.places = places; vh.place = places[0].id; }
              }
              if (Array.isArray(b.routine) && b.routine.length) {
                var routine = b.routine.filter(function (r) { return r && /^\d{1,2}:\d{2}$/.test(String(r.t)) && r.a; })
                  .slice(0, 12).map(function (r) { return { t: String(r.t), a: String(r.a).slice(0, 120) }; });
                if (routine.length) vh.routine = routine;
              }
              if (b.sleep && /^\d{1,2}:\d{2}$/.test(String(b.sleep.start)) && /^\d{1,2}:\d{2}$/.test(String(b.sleep.end))) {
                vh.sleep = { start: String(b.sleep.start), end: String(b.sleep.end) };
              }
              if (Array.isArray(b.people) && b.people.length) {
                vh.people = b.people.filter(function (p) { return p && p.name; }).slice(0, 8).map(function (p) {
                  var c = parseFloat(p.closeness);
                  return { id: VH.uid('pe'), name: String(p.name).slice(0, 60),
                    relation: String(p.relation || '').slice(0, 60),
                    closeness: isNaN(c) ? 0 : Math.max(-1, Math.min(1, c)),
                    note: String(p.note || '').slice(0, 160) };
                });
              }
              if (Array.isArray(b.diary) && b.diary.length) {
                vh.chronicle = b.diary.map(function (t) { return { ts: Date.now(), text: String(t).slice(0, 300) }; });
              }
              UI.toast(lifeParsed ? 'Draft in — edit anything, then Save' :
                (lifeRemainder ? 'Life note kept; default routine and places are ready to edit' :
                  'Person drafted; default routine and places are ready to edit'));
              collect();
              Views.editor($('#editor-body'), Object.assign({}, char, draft, { vh: vh }));
            });
        }).catch(function (e) {
          btn.disabled = false;
          UI.toast('Draft failed: ' + e.message, 4000);
        });
    });

    on(body, '[data-act=ai-scenario]', 'click', function () {
      var name = $('#e-name', body).value.trim() || 'the character';
      var persona = $('#e-persona', body).value.trim().slice(0, 400);
      UI.toast('Asking the model — one request…');
      API.aiJson(Store.settings,
        'Write a roleplay scenario for ' + name +
        (persona ? ', whose persona is: "' + persona + '"' : '') +
        '. Return ONLY a JSON object, no markdown, no commentary: ' +
        '{"scenario": string} — 2-4 sentences, a concrete opening situation with a small hook or tension, written so the player can answer it.',
        320, null, 'scenario').then(function (d) {
          if (!d || !d.scenario) return UI.toast('The model returned no usable scenario. Try again or write it manually.', 5000);
          $('#e-scenario', body).value = String(d.scenario).trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });
    /* A card can ship several starting scenarios (scenario_list). Choose the
       one to start from: it lands in the Scenario field, ready to edit, and
       saves with the character like anything else. */
    on(body, '[data-act=scenarios]', 'click', function () {
      var list = draft.scenarioList || [];
      if (list.length < 2) return;
      UI.sheet({
        title: 'Where the card can start',
        body: '<div class="hint" style="margin-bottom:8px">Pick the one to start from — it lands in the Scenario field, ready to edit.</div>' +
          list.map(function (s, i) {
            var t = String(s);
            var prev = t.length > 160 ? t.slice(0, 160) + '…' : t;
            return '<div class="opt" data-sci="' + i + '" style="align-items:flex-start">' +
              '<b style="min-width:26px;color:var(--dim)">' + (i + 1) + '.</b>' +
              '<span style="flex:1;white-space:pre-line">' + esc(prev) + '</span></div>';
          }).join(''),
        onMount: function (b, close) {
          b.querySelectorAll('[data-sci]').forEach(function (el) {
            el.onclick = function () {
              var i = +el.getAttribute('data-sci');
              $('#e-scenario', body).value = list[i];
              /* Keep the greeting in step: the picked scenario is also its
                 intro, so move the Greeting switcher onto it. */
              var g = $('#e-greeting', body);
              if (g) {
                introNav.set(g.value);
                introNav.goToText(list[i]);
                introPaint();
              }
              UI.toast('Scenario ' + (i + 1) + ' loaded — edit it as you like');
              close();
            };
          });
        }
      });
    });

    on(body, '[data-act=ai-greeting]', 'click', function () {
      var name = $('#e-name', body).value.trim() || 'the character';
      var persona = $('#e-persona', body).value.trim().slice(0, 400);
      UI.toast('Asking the model — one request…');
      API.aiJson(Store.settings,
        'Write the opening message a roleplay character named ' + name +
        (persona ? ', whose persona is: "' + persona + '"' : '') +
        ', would send the player as their very first line. In their voice, 1-3 sentences, ending so the player can answer. ' +
        'Return ONLY a JSON object, no markdown, no commentary: {"greeting": string}.',
        240, null, 'greeting').then(function (d) {
          if (!d || !d.greeting) return UI.toast('The model returned no usable greeting. Try again or write it manually.', 5000);
          $('#e-greeting', body).value = String(d.greeting).trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });

    /* v1.39.15: intro swipes in the editor — the textarea always shows the
       slot the counter names; whatever was typed follows the swipe. Bin is
       only offered on alternates — the main greeting itself cannot go. */
    on(body, '[data-act=intro-prev]', 'click', function () {
      introNav.set($('#e-greeting', body).value);
      introNav.move(-1);
      introPaint();
    });
    on(body, '[data-act=intro-next]', 'click', function () {
      introNav.set($('#e-greeting', body).value);
      introNav.move(1);
      introPaint();
    });
    on(body, '[data-act=intro-add]', 'click', function () {
      introNav.set($('#e-greeting', body).value);
      introNav.add();
      introPaint();
      UI.toast('Intro ' + (introNav.index() + 1) + ' — empty and ready. Paste or write another first message here.');
      var g = $('#e-greeting', body);
      if (g) g.focus();
    });
    on(body, '[data-act=intro-del]', 'click', function () {
      if (introNav.index() === 0) return;
      UI.confirm('Remove intro ' + (introNav.index() + 1) + ' of ' + introNav.count() + '?',
        'Only this swipe is dropped — the main first message stays.',
        { danger: true, okLabel: 'Remove' }).then(function (yes) {
          if (yes) { introNav.remove(); introPaint(); }
        });
    });

    $('#e-temp', body).addEventListener('input', function () {
      draft.temperature = parseFloat(this.value);
      $('#v-ctemp', body).textContent = draft.temperature.toFixed(2);
    });
    $('#e-temp-clear', body).addEventListener('click', function () {
      draft.temperature = null;
      $('#v-ctemp', body).textContent = 'global';
    });
    /* ---- virtual human block ---- */
    function renderRoutine() {
      var box = $('#vh-routine', body);
      if (!box) return;
      box.innerHTML = (vh.routine || []).map(function (r, i) {
        return '<div class="row" style="margin-bottom:6px" data-r="' + i + '">' +
          '<input type="time" value="' + esc(r.t) + '" style="width:104px;flex:0 0 auto" data-rt="' + i + '">' +
          '<input type="text" value="' + esc(r.a) + '" placeholder="what they are doing" style="flex:1" data-ra="' + i + '">' +
          '<button class="chip" data-rdel="' + i + '">' + icon('trash') + '</button></div>';
      }).join('');
      box.querySelectorAll('[data-rt]').forEach(function (el) {
        el.onchange = function () { vh.routine[+el.getAttribute('data-rt')].t = el.value; };
      });
      box.querySelectorAll('[data-ra]').forEach(function (el) {
        el.oninput = function () { vh.routine[+el.getAttribute('data-ra')].a = el.value; };
      });
      box.querySelectorAll('[data-rdel]').forEach(function (el) {
        el.onclick = function () { vh.routine.splice(+el.getAttribute('data-rdel'), 1); renderRoutine(); };
      });
    }
    renderRoutine();

    var KINDS = ['home', 'work', 'cafe', 'shop', 'outdoor', 'other'];
    var DAYS = ['Every day', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    function placeOptions(sel) {
      return (vh.places || []).map(function (p) {
        return '<option value="' + esc(p.id) + '"' + (sel === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>';
      }).join('');
    }

    function renderPlaces() {
      var box = $('#vh-places', body);
      if (!box) return;
      box.innerHTML = (vh.places || []).map(function (p, i) {
        return '<div class="row" style="margin-bottom:6px" data-p="' + i + '">' +
          '<input type="text" value="' + esc(p.name) + '" placeholder="name" style="flex:1" data-pn="' + i + '">' +
          '<select data-pk="' + i + '" style="width:104px;flex:0 0 auto">' +
            KINDS.map(function (k) {
              return '<option value="' + k + '"' + (p.kind === k ? ' selected' : '') + '>' + k + '</option>';
            }).join('') +
          '</select>' +
          '<button class="chip" data-pdel="' + i + '">' + icon('trash') + '</button></div>' +
          '<input type="text" value="' + esc(p.note || '') + '" placeholder="what it is like there (optional)" ' +
            'style="width:100%;margin:-2px 0 8px" data-pnote="' + i + '">';
      }).join('') +
      '<div class="row"><span class="hint" style="flex:0 0 auto;margin-right:6px">Currently at</span>' +
      '<select id="vh-at" style="flex:1">' + placeOptions(vh.place) + '</select></div>';

      box.querySelectorAll('[data-pn]').forEach(function (el) {
        el.oninput = function () { vh.places[+el.getAttribute('data-pn')].name = el.value; };
      });
      box.querySelectorAll('[data-pk]').forEach(function (el) {
        el.onchange = function () { vh.places[+el.getAttribute('data-pk')].kind = el.value; };
      });
      box.querySelectorAll('[data-pnote]').forEach(function (el) {
        el.oninput = function () { vh.places[+el.getAttribute('data-pnote')].note = el.value; };
      });
      box.querySelectorAll('[data-pdel]').forEach(function (el) {
        el.onclick = function () {
          var list = vh.places || [];
          if (list.length <= 1) return UI.toast('They need at least one place');
          var i = +el.getAttribute('data-pdel');
          var gone = list[i];
          /* 18.1.0: removing a place that life still references says so,
             instead of the references quietly dangling. */
          var notes = [];
          if (vh.travel && (vh.travel.to === gone.id || vh.travel.from === gone.id)) {
            vh.travel = null;
            notes.push('trip to ' + gone.name + ' cancelled');
          }
          var moved = (vh.calendar || []).filter(function (e) { return e.placeId === gone.id; }).length;
          list.splice(i, 1);
          if (vh.place === gone.id) { vh.place = list[0].id; notes.push('now placed at ' + list[0].name); }
          (vh.calendar || []).forEach(function (e) { if (e.placeId === gone.id) e.placeId = null; });
          if (moved) notes.push(moved + ' diary event' + (moved > 1 ? 's' : '') + ' have no location');
          renderPlaces(); renderCal();
          if (notes.length) UI.toast(notes.join(' · '), 4000);
        };
      });
      var at = $('#vh-at', box);
      if (at) at.onchange = function () { vh.place = at.value; };
    }

    function renderPeople() {
      var box = $('#vh-people', body);
      if (!box) return;
      if (!(vh.people || []).length) {
        box.innerHTML = '<div class="hint">Nobody yet.</div>';
        return;
      }
      box.innerHTML = vh.people.map(function (p, i) {
        return '<div style="margin-bottom:10px" data-pe="' + i + '">' +
          '<div class="row" style="margin-bottom:6px">' +
            '<input type="text" value="' + esc(p.name) + '" placeholder="name" style="flex:1" data-pen="' + i + '">' +
            '<input type="text" value="' + esc(p.relation || '') + '" placeholder="relation" style="flex:1" data-per="' + i + '">' +
            '<button class="chip" data-pedel="' + i + '">' + icon('trash') + '</button></div>' +
          '<div class="row"><span class="hint" style="flex:0 0 auto;margin-right:6px">closeness</span>' +
            '<input type="range" min="0" max="100" value="' + Math.round((p.closeness === undefined ? 0.5 : p.closeness) * 100) + '" data-pec="' + i + '" style="flex:1"></div>' +
          '<input type="text" value="' + esc(p.note || '') + '" placeholder="a note about them (optional)" style="width:100%;margin-top:6px" data-penote="' + i + '">' +
        '</div>';
      }).join('');
      box.querySelectorAll('[data-pen]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-pen')].name = el.value; };
      });
      box.querySelectorAll('[data-per]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-per')].relation = el.value; };
      });
      box.querySelectorAll('[data-pec]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-pec')].closeness = parseInt(el.value, 10) / 100; };
      });
      box.querySelectorAll('[data-penote]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-penote')].note = el.value; };
      });
      box.querySelectorAll('[data-pedel]').forEach(function (el) {
        el.onclick = function () { vh.people.splice(+el.getAttribute('data-pedel'), 1); renderPeople(); };
      });
    }

    function renderCal() {
      var box = $('#vh-cal', body);
      if (!box) return;
      if (!(vh.calendar || []).length) {
        box.innerHTML = '<div class="hint">Nothing recurring.</div>';
        return;
      }
      box.innerHTML = vh.calendar.map(function (e, i) {
        return '<div class="row" style="margin-bottom:6px" data-c="' + i + '">' +
          '<input type="time" value="' + esc(e.t || '09:00') + '" style="width:96px;flex:0 0 auto" data-ct="' + i + '">' +
          '<input type="text" value="' + esc(e.label || '') + '" placeholder="what it is" style="flex:1" data-cl="' + i + '">' +
          '<select data-cd="' + i + '" style="width:104px;flex:0 0 auto">' +
            DAYS.map(function (d, di) {
              var val = di === 0 ? '' : String(di - 1);
              var cur = (e.day === null || e.day === undefined) ? '' : String(e.day);
              return '<option value="' + val + '"' + (cur === val ? ' selected' : '') + '>' + d + '</option>';
            }).join('') +
          '</select>' +
          '<select data-cp="' + i + '" style="width:96px;flex:0 0 auto">' +
            '<option value="">—</option>' + placeOptions(e.placeId) +
          '</select>' +
          '<button class="chip" data-cdel="' + i + '">' + icon('trash') + '</button></div>';
      }).join('');
      box.querySelectorAll('[data-ct]').forEach(function (el) {
        el.onchange = function () { vh.calendar[+el.getAttribute('data-ct')].t = el.value; };
      });
      box.querySelectorAll('[data-cl]').forEach(function (el) {
        el.oninput = function () { vh.calendar[+el.getAttribute('data-cl')].label = el.value; };
      });
      box.querySelectorAll('[data-cd]').forEach(function (el) {
        el.onchange = function () {
          var v = el.value;
          vh.calendar[+el.getAttribute('data-cd')].day = v === '' ? null : parseInt(v, 10);
        };
      });
      box.querySelectorAll('[data-cp]').forEach(function (el) {
        el.onchange = function () { vh.calendar[+el.getAttribute('data-cp')].placeId = el.value || null; };
      });
      box.querySelectorAll('[data-cdel]').forEach(function (el) {
        el.onclick = function () { vh.calendar.splice(+el.getAttribute('data-cdel'), 1); renderCal(); };
      });
    }

    renderPlaces();
    renderWorld();
    renderPeople();
    renderCal();

    function renderWorld() {
      var box = $('#vh-world', body);
      if (!box) return;
      var W = global.Worlds;
      if (!vh.worldId) {
        box.innerHTML = '<div class="hint">No world pack loaded. Add a pack to give them a real city to move through.</div>';
        return;
      }
      var pack = W && W.cached(vh.worldId);
      box.innerHTML = '<div class="hint">World: <b>' + esc(vh.worldId) + '</b> — ' +
        (pack ? pack.placeCount + ' places, ' + pack.routeCount +
                ' walking routes. Journeys take as long as they really take.'
              : 'journey times will be estimated until it loads.') +
        ' <button class="chip" id="vh-world-off">remove</button></div>';
      var off = $('#vh-world-off', box);
      if (off) off.onclick = function () {
        if (pack) W.remove(vh, pack); else vh.worldId = null;
        renderWorld(); renderPlaces(); renderCal();
        UI.toast('World pack removed');
      };
    }

    var worldBtn = $('#vh-world-pack', body);
    if (worldBtn) worldBtn.onclick = function () {
      var W = global.Worlds;
      if (!W) return UI.toast('World packs are not available in this build');
      W.available().then(function (packs) {
        if (!packs.length) return UI.toast('No world packs are installed');
        var p = packs[0];   /* one pack ships today; a picker if more arrive */
        var msg = p.description + ' That is ' + p.placeCount + ' places and ' +
          p.routeCount + ' walking routes. Their home and work are kept, and ' +
          'journeys take as long as the walk really takes. ' + (p.attribution || '');
        return UI.confirm('Load ' + p.name + '?', msg, { okLabel: 'Load' })
          .then(function (yes) {
            if (!yes) return;
            return W.load(p.id).then(function (pack) {
              var n = W.apply(vh, pack);
              renderWorld(); renderPlaces(); renderCal();
              UI.toast(n + ' places loaded');
            });
          });
      }).catch(function (e) {
        UI.toast(e && e.message ? e.message : 'Could not load that world pack');
      });
    };

    var addPlace = $('#vh-add-place', body);
    if (addPlace) addPlace.onclick = function () {
      vh.places.push({ id: VH.uid('p'), name: 'New place', kind: 'other', note: '' });
      renderPlaces(); renderCal();
    };
    var addPerson = $('#vh-add-person', body);
    if (addPerson) addPerson.onclick = function () {
      vh.people.push({ id: VH.uid('pe'), name: '', relation: '', closeness: 0.5, note: '' });
      renderPeople();
    };
    var addCal = $('#vh-add-cal', body);
    if (addCal) addCal.onclick = function () {
      vh.calendar.push({ id: VH.uid('ev'), label: '', t: '09:00', day: null, placeId: null });
      renderCal();
    };
    var burstEl = $('#vh-burst', body);
    if (burstEl) burstEl.oninput = function () {
      vh.burst = parseInt(burstEl.value, 10) || 1;
      var out = $('#vh-burst-v', body);
      if (out) out.textContent = vh.burst;
    };

    var vhOn = $('#vh-on', body);
    if (vhOn) vhOn.onclick = function () {
      vh.enabled = !vh.enabled;
      this.classList.toggle('on', vh.enabled);
      $('#vh-fields', body).hidden = !vh.enabled;
    };
    var istateOn = $('#t-istate', body);
    if (istateOn) istateOn.onclick = function () {
      draft.stateTracking = draft.stateTracking !== true;
      this.classList.toggle('on', draft.stateTracking);
      var f = $('#istate-fields', body);
      if (f) f.hidden = !draft.stateTracking;
    };
    var vhAdd = $('#vh-add', body);
    if (vhAdd) vhAdd.onclick = function () {
      vh.routine.push({ t: '12:00', a: '' });
      renderRoutine();
    };
    var vhAuto = $('#vh-auto', body);
    if (vhAuto) vhAuto.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      vh.autonomy = b.getAttribute('data-a');
      this.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
    };
    function bindRange(id, fn) {
      var el = $('#' + id, body);
      if (el) el.oninput = function () { fn(parseInt(el.value, 10)); };
    }
    bindRange('vh-dmin', function (v) { vh.replyDelay.min = v; updDelay(); });
    bindRange('vh-dmax', function (v) { vh.replyDelay.max = v; updDelay(); });
    function updDelay() {
      if (vh.replyDelay.max < vh.replyDelay.min) vh.replyDelay.max = vh.replyDelay.min;
      var el = $('#vh-dmin-v', body);
      if (el) el.textContent = vh.replyDelay.min + 's – ' + vh.replyDelay.max + 's';
    }
    var vhPhotos = $('#vh-photos', body);
    if (vhPhotos) vhPhotos.onclick = function () { vh.photos = !vh.photos; this.classList.toggle('on', vh.photos); };
    ['vh-mood', 'vh-aff', 'vh-trust', 'vh-ten'].forEach(function (id, i) {
      var el = $('#' + id, body);
      if (!el) return;
      el.oninput = function () {
        var v = parseInt(el.value, 10) / 100;
        if (id === 'vh-mood') vh.mood = v;
        if (id === 'vh-aff') vh.affinity = v;
        if (id === 'vh-trust') vh.trust = v;
        if (id === 'vh-ten') vh.tension = v;
        var out = $('#' + id + '-v', body);
        if (out) out.textContent = v.toFixed(2);
      };
    });
    var ss = $('#vh-sleep-start', body), se = $('#vh-sleep-end', body);
    if (ss) ss.onchange = function () { vh.sleep.start = ss.value || '23:00'; };
    if (se) se.onchange = function () { vh.sleep.end = se.value || '07:00'; };

    on(body, '[data-act=save]', 'click', function () {
      var c = collect();
      if (!c.name) { UI.toast('Give the character a name'); return; }
      App.saveCharacter(c);
    });
    on(body, '[data-act=delete]', 'click', function () {
      UI.confirm('Delete ' + (draft.name || 'character') + '?', 'All their chats and memories go too.',
        { danger: true, okLabel: 'Delete' }).then(function (ok) { if (ok) App.deleteCharacter(draft.id); });
    });
  };

  /* word-count under the alt pager: cheap, honest, testable */
  function altWordCount(t) {
    return String(t || '').trim().split(/\s+/).filter(Boolean).length;
  }
  Views.altWordCount = altWordCount;

  /* v1.39.81: the footer used to read "116 words · cut", which could be read
     two ways — how long this reply is, or how much the app withheld because it
     hit a limit. It was the first, and the second reading is impossible: a cut
     reply is short, not truncated for display; the model simply stopped
     mid-thought. The line now says which number it is, and, when a reply did
     stop early, says so in words and points at the button that fixes it. */
  function replyFooter(body, m, s) {
    var words = altWordCount(body) + ' words in this reply';
    var ends = /[.!?\u2026"\u201d\u2019)\]]\s*$/.test(String(body).trim());
    if (ends) return words + ' \u00b7 complete';
    if (m.finishReason === 'length') {
      var cap = (s && s.maxTokens) || API.DEFAULT_MAX_TOKENS;
      return words + ' \u00b7 the model hit your ' + cap + '-token limit, so it stopped mid-thought ' +
        '\u00b7 Continue finishes it';
    }
    if (m.finishReason === 'stop') {
      return words + ' \u00b7 the model chose to stop before finishing';
    }
    return words + ' \u00b7 it stopped mid-sentence; Continue finishes it';
  }
  Views.replyFooter = replyFooter;

  /* what the listener hears: markdown and directions stripped, just prose */
  function speechText(t) {
    return String(t || '')
      .replace(/!\[[^\]\]]*\]\([^)]*\)/g, ' ')      /* images */
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')        /* links keep their text */
      .replace(/[\*_`#>~]+/g, '')
      .replace(/https?:\/\/\S+/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }
  Views.speechText = speechText;

  /* ================= chat helpers ================= */
  /* v1.45.0: display scripts run at this one point in the app. The try/catch is
     not decoration — a rule saved before save-time testing existed, or edited into
     the settings blob by hand, must not be able to blank a reply on screen. Losing
     the styling is bearable; losing the text is not. */
  function shownText(body, s) {
    try {
      return (typeof API !== 'undefined' && API && API.applyDisplayScripts)
        ? API.applyDisplayScripts(body, s) : body;
    } catch (e) { return body; }
  }

  function messageHtml(m, char, s) {
    var isMe = m.role === 'user';
    var who = isMe ? s.userName : (m.speakerName || char.name);
    var speakerAvatar = !isMe && m.speakerPortrait ? m.speakerPortrait :
      (!isMe && m.speakerId ? (m.speakerAvatar || '') : char.avatar);
    var text = m.text || '';
    /* v1.39.79: a stale EMPTY stream used to win over the finished text — the
       bubble was built before the first chunk arrived, so `_stream` was '' and
       the footer under a full reply read "0 words · cut". An empty stream means
       "nothing has streamed yet", which is exactly when the stored text is the
       truth. */
    var body = (m._stream !== undefined && m._stream !== null && m._stream !== '')
      ? m._stream : text;
    return '<div class="msg' + (isMe ? ' me' : '') + (m.autonomous ? ' auto' : '') + '" data-mid="' + m.id + '">' +
      /* v1.31.0: the player's own bubble shows the active persona's photo
         when the persona has one, initials otherwise. */
      '<div class="av">' + (isMe
        ? avatarHtml(activePersonaAvatar(s), s.userName)
        : avatarHtml(speakerAvatar, who)) + '</div>' +
      '<div style="min-width:0;max-width:calc(100% - 44px)">' +
        '<div class="bubble">' +
          (!isMe ? '<div class="who">' + esc(who) + '</div>' : '') +
          /* v1.45.0: display scripts run here and nowhere else — the stored
             message, the prompt, the export and the `raw` copy all keep the
             model's own words. The reply footer below still counts `body`,
             because it describes the reply the model sent, not this render. */
          '<div class="mtext">' + md(shownText(body, s)) + '</div>' +
          (m.continuationOf ? '<div class="mcont">↳ continued from the reply above</div>' : '') +
          (!isMe && body.trim() ? '<div class="mstat" style="margin-top:6px;font-size:11px;opacity:.55;letter-spacing:.02em">' +
            replyFooter(body, m, s) + '</div>' : '') +
          (m.image ? '<img class="gen" src="' + esc(m.image) + '" alt="' + esc(m.imageCaption || 'image') + '" data-lightbox="' + esc(m.image) + '">' : '') +
          (m.imageCaption ? '<div class="imgcap">' + esc(m.imageCaption) + '</div>' : '') +
          (m.autonomous ? '<div class="auto-tag">· sent on their own</div>' : '') +
        '</div>' +
        '<div class="msg-actions">' +
          (m.image ? '<button class="chip" data-act="download-image" title="Save this image to Downloads">' + icon('download') + ' Download image</button>' : '') +
          (m.rpgStatusProposal && m.rpgStatusProposal.state === 'pending' ? '<button class="chip" data-act="rpg-review" title="Review proposed RPG status changes">' + icon('brain') + ' Review status update</button>' : '') +
          (m.continuityProposal && m.continuityProposal.state === 'pending' ? '<button class="chip" data-act="continuity-review" title="Review proposed continuity changes">' + icon('brain') + ' Review continuity update</button>' : '') +
          (isMe
            ? (m.retry ? '<button class="chip retry" data-act="retry">' + icon('refresh') + ' Retry</button>' : '') +
              '<button class="chip" data-act="edit">' + icon('edit') + ' Edit</button>' +
              '<button class="chip" data-act="del">' + icon('trash') + '</button>'
            : '<button class="chip" data-act="reroll">' + icon('refresh') + ' Reroll</button>' +
              '<button class="chip" data-act="rerollnote" title="Reroll with a steering note">' + icon('refresh') + '+📝</button>' +
              '<button class="chip" data-act="cont">Continue</button>' +
              '<button class="chip" data-act="say" title="Listen">' + icon('volume') + '</button>' +
              '<button class="chip" data-act="edit">' + icon('edit') + '</button>' +
              '<button class="chip" data-act="copy">' + icon('copy') + '</button>' +
              (m.rawDropped ? '<button class="chip" data-act="raw" title="' +
                esc(String(m.rawDropped) + ' characters were removed while cleaning this reply') +
                '">−' + m.rawDropped + '</button>' : '') +
              '<button class="chip" data-act="del">' + icon('trash') + '</button>') +
        '</div>' +
        ((m.alts && m.alts.length > 1)
          ? '<div class="swipe">' +
            '<button data-act="swipe" data-dir="-1"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button>' +
            '<span>' + ((m.altIdx || 0) + 1) + ' / ' + m.alts.length + '</span>' +
            '<span class="swipe-words">' + altWordCount(m.alts[m.altIdx || 0] || '') + ' words</span>' +
            '<button data-act="swipe" data-dir="1"><svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>' +
            '</div>'
          : '') +
      '</div>' +
    '</div>';
  }

  /* Follow the bottom only when the user is already there (within 260px) —
     or when told to. Scrolling up to read a reply must not be fought by
     incoming text: that is what made a finished reply yank the view to the
     last word. */
  function stickToBottom(thread, force) {
    if (!thread) return false;
    if (force || thread.scrollHeight - thread.scrollTop - thread.clientHeight < 260) {
      thread.scrollTop = thread.scrollHeight;
      return true;
    }
    return false;
  }
  Views.stickToBottom = stickToBottom;

  /* v1.39.22: the finish-of-generation follow. Near-bottom readers keep
     following new replies — but a reply taller than the viewport is read
     top-down, so land on its first line instead of marooning the reader at
     the last one (every wall of text previously ended with a forced
     scroll-back-up to start reading). */
  function followReply(thread, el) {
    if (!thread) return;
    var nearBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 260;
    if (!nearBottom) return;   /* someone reading up-thread is never moved */
    if (el && el.offsetHeight > thread.clientHeight - 60) {
      /* (the v1.39.23 seam-anchor was retired in v1.39.28: a Continue now
         finishes in its OWN bubble — head/bottom anchoring covers it) */
      thread.scrollTop = Math.max(0, el.offsetTop - 8);
    } else {
      thread.scrollTop = thread.scrollHeight;
    }
  }
  Views.followReply = followReply;

  /* 18.2.0: a re-render must not fling the reader. Anchor on the first
     message in view (and how far down into it) and restore after the
     rebuild; if that message was just deleted, its predecessor stands in.
     Fresh opens (forceBottom) still land on the last message. Pure over
     plain child objects so it is unit-testable. */
  Views.threadAnchor = function (children, scrollTop) {
    var y = scrollTop || 0;
    var prev = null;
    for (var i = 0; i < children.length; i++) {
      var el = children[i];
      if (el.offsetTop + el.offsetHeight > y) {
        return {
          mid: el.getAttribute ? el.getAttribute('data-mid') : null,
          dy: Math.max(0, y - el.offsetTop),
          prev: prev
        };
      }
      if (el.getAttribute) prev = el.getAttribute('data-mid');
    }
    return null; /* scrolled past the last message — stick to bottom instead */
  };

  Views.restoreThreadScroll = function (thread, anchor) {
    if (!anchor) return false;
    var el = anchor.mid ? thread.querySelector('[data-mid="' + anchor.mid + '"]') : null;
    var usedPrev = false;
    if (!el && anchor.prev) { el = thread.querySelector('[data-mid="' + anchor.prev + '"]'); usedPrev = true; }
    if (!el) return false;
    /* When the fallback predecessor stands in, land at its top, not mid-line.
       v1.39.18: dy is how far INTO the message the viewport top was —
       restoring must ADD it back (subtracting used to fling the reader
       up by 2×dy on every mid-message anchor). */
    thread.scrollTop = Math.max(0, el.offsetTop + (usedPrev ? 0 : (anchor.dy || 0)));
    return true;
  };

  /* v1.13.0 — the internal-state strip at the top of a chat. Collapsed:
     one line (mood is the headline). Expanded: the three fields plus an
     edit button. Shown only for characters with tracking on; virtual
     humans keep their own simulation-driven Inner state instead. */
  function stateStrip(char) {
    var el = $('#char-state');
    if (!el) return;
    var on = !!(char && char.stateTracking === true && !char.vh);
    if (!on) { el.hidden = true; el.innerHTML = ''; return; }
    var st = char.state || {};
    var any = st.mood || st.intent || st.flags;
    var open = el._open;
    el.hidden = false;
    el.innerHTML =
      '<button class="cs-head' + (open ? ' open' : '') + '" data-act="cs-toggle">' +
        '<span class="cs-lbl">State</span>' +
        '<span class="cs-preview">' + esc(st.mood || (any ? (st.intent || st.flags) : 'not set yet')) + '</span>' +
        '<svg class="cs-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>' +
      '</button>' +
      '<div class="cs-body"' + (open ? '' : ' hidden') + '>' +
        (st.mood ? '<div class="cs-row"><span class="cs-k">mood</span><span>' + esc(st.mood) + '</span></div>' : '') +
        (st.intent ? '<div class="cs-row"><span class="cs-k">intent</span><span>' + esc(st.intent) + '</span></div>' : '') +
        (st.flags ? '<div class="cs-row"><span class="cs-k">flags</span><span>' + esc(st.flags) + '</span></div>' : '') +
        (any ? '' : '<div class="hint" style="margin:0 0 6px">The model will fill this in with the next reply — or set it yourself.</div>') +
        '<button class="btn ghost sm block" data-act="cs-edit">' + icon('edit') + ' Edit state</button>' +
      '</div>';
    el.querySelector('[data-act="cs-toggle"]').onclick = function () {
      open = !open;
      el._open = open;
      el.querySelector('.cs-body').hidden = !open;
      this.classList.toggle('open', open);
    };
    el.querySelector('[data-act="cs-edit"]').onclick = function () { App.editCharState(char); };
  }

  Views.thread = function (char, session, messages, streamingId, forceBottom, preAnchor) {
    var s = Store.settings;
    var thread = $('#thread');
    /* v1.39.18: a caller that knows a viewport shift is coming (the edit
       sheet + keyboard dance) captures the anchor BEFOREhand and hands it
       in — the position read right now may already be corrupted. */
    var anchor = (!forceBottom && thread.children && thread.children.length)
      ? (preAnchor || Views.threadAnchor(thread.children, thread.scrollTop))
      : null;
    thread.innerHTML = messages.map(function (m) {
      if (m.id === streamingId) m._stream = m._stream || '';
      return messageHtml(m, char, s);
    }).join('');
    var st = thread.querySelector('.msg.streaming .mtext') ||
      (streamingId ? thread.querySelector('[data-mid="' + streamingId + '"] .mtext') : null);
    if (stickToBottom(thread, forceBottom || !!streamingId)) {
      /* Re-pin when each image below the fold lands - for a forced open AND
         a natural near-bottom pin - but never yank a reader who has already
         scrolled up to read something. */
      if (thread.querySelectorAll) {
        var imgs = thread.querySelectorAll('img');
        for (var ii = 0; ii < imgs.length; ii++) (function (im) {
          if (im.complete) return;
          im.addEventListener('load', function () {
            if (thread.scrollHeight - thread.scrollTop - thread.clientHeight < 160) thread.scrollTop = thread.scrollHeight;
          }, { once: true });
        })(imgs[ii]);
      }
    } else if (anchor) {
      /* Re-render (delete / edit / swipe) while the reader was mid-thread:
         put them back where they were. */
      Views.restoreThreadScroll(thread, anchor);
      /* The first layout pass measures a thread whose avatars/inline images
         have not loaded yet, so the restored position is too high and the
         reader is left stranded up the thread (accept an edit → the view
         jumps up). Once the still-loading images settle, re-apply the
         anchor — the same re-jump the fresh-open path already performs —
         unless the reader has moved on their own in the meantime. */
      var pendingImgs = [];
      var allImgs = thread.querySelectorAll ? thread.querySelectorAll('img') : [];
      for (var pi = 0; pi < allImgs.length; pi++) if (allImgs[pi] && !allImgs[pi].complete) pendingImgs.push(allImgs[pi]);
      if (pendingImgs.length) {
        var settled = false;
        var appliedPos = thread.scrollTop;
        var reapply = function () {
          if (settled) return;
          settled = true;
          if (Math.abs(thread.scrollTop - appliedPos) < 60) Views.restoreThreadScroll(thread, anchor);
        };
        var remaining = pendingImgs.length;
        for (var pj = 0; pj < pendingImgs.length; pj++) (function (im) {
          var one = function () { if (--remaining === 0) reapply(); };
          im.addEventListener('load', one, { once: true });
          im.addEventListener('error', one, { once: true });
        })(pendingImgs[pj]);
        /* a broken or slow image never fires: settle on a timer anyway */
        setTimeout(reapply, 800);
      }
    }
    return st;
  };

  /* v1.39.79: a finished reply used to be patched into `.mtext` only. Every
     other part of the bubble — the word count, the "cut" marker, the
     continuation label, the swipe row — was whatever the streaming render had
     left there, which is how "0 words · cut" survived under a full paragraph.
     Nothing hand-patches a bubble any more: the element is rebuilt from the
     message, so every part of it agrees with the text. */
  Views.refreshMessage = function (char, m) {
    var old = $('#thread [data-mid="' + m.id + '"]');
    if (!old || !old.parentNode) return null;
    var wrap = document.createElement('div');
    wrap.innerHTML = messageHtml(m, char, Store.settings);
    var el = wrap.firstElementChild;
    old.parentNode.replaceChild(el, old);
    return el;
  };

  Views.appendMessage = function (char, m) {
    var thread = $('#thread');
    var wrap = document.createElement('div');
    wrap.innerHTML = messageHtml(m, char, Store.settings);
    var el = wrap.firstElementChild;
    thread.appendChild(el);
    stickToBottom(thread, false);
    return el;
  };

  Views.pickFile = pickFile;
  Views.fileToDataUrl = fileToDataUrl;
  /* Cards can carry several starting scenarios (scenario_list). The editor
     shows a picker chip only when there is more than one to choose from. */
  Views.scenarioChip = function (list) {
    if (!list || list.length < 2) return '';
    return '<button class="chip" data-act="scenarios">Card scenarios (' + list.length + ')</button>';
  };

  /* v1.39.15: the intros a character owns — the main greeting plus every
     alternate — as a swipeable stack for the editor. The chat already
     swipes them (‹ n / N › on the opening bubble); the edit sheet now does
     the same to the Greeting field, with buttons to add or drop one. The
     model copies the texts into its own slots, so swiping around never
     mutates the character until collect() folds the slots back. */
  Views.introNavModel = function (char) {
    var alts = (char && Array.isArray(char.alternateGreetings)) ? char.alternateGreetings : [];
    var slots = [String((char && char.greeting) || '')].concat(alts.map(function (g) { return String(g || ''); }));
    var idx = 0;
    return {
      count: function () { return slots.length; },
      index: function () { return idx; },
      text: function () { return slots[idx]; },
      label: function () { return (idx + 1) + ' / ' + slots.length; },
      set: function (v) { slots[idx] = String(v == null ? '' : v); },
      move: function (dir) {
        idx = ((idx + dir) % slots.length + slots.length) % slots.length;
        return slots[idx];
      },
      /* Jump to the slot already holding this text, or put the text in the
         current slot — so picking a scenario can move the greeting to it. */
      goToText: function (text) {
        text = String(text == null ? '' : text);
        for (var k = 0; k < slots.length; k++) {
          if (slots[k] === text) { idx = k; return slots[idx]; }
        }
        slots[idx] = text;
        return slots[idx];
      },
      add: function () { slots.push(''); idx = slots.length - 1; return slots[idx]; },
      remove: function () {
        if (idx === 0 || slots.length < 2) return false;
        slots.splice(idx, 1);
        idx = Math.max(0, idx - 1);
        return true;
      },
      collect: function () {
        if (!char) return;
        char.greeting = slots[0];
        char.alternateGreetings = slots.slice(1).filter(function (s) { return s.trim() !== ''; });
      }
    };
  };
  Views.stateStrip = stateStrip;
  Views.normalizeImage = normalizeImage;
  Views.normalizeDataUrl = normalizeDataUrl;
  Views.normalizeCardImages = normalizeCardImages;
  /* v1.30.0: the same diet, by itself — a world's banner gets it on import */
  Views.dietDataUrl = normalizeDataUrl;
  Views.imageTargetSize = imageTargetSize;
  Views.imageMime = imageMime;
  Views.initials = initials;
  Views.avatarHtml = avatarHtml;
  Views.activePersonaAvatar = activePersonaAvatar;
  Views.personaRowsHtml = personaRowsHtml;
  Views.messageHtml = messageHtml;

  /* ================= AUTHORED WORLDS ================= */
  /* Upstream .horde_world files: a place with streets and rooms, a cast,
     factions, lore and a set of rules. Artwork is stripped on import, so a
     2.5 MB world arrives at about 50 KB. */

  /* v1.39.9: opts.editable marks the last own turn (and only when the run
     carries its pre-turn snapshot) - that bubble wears the pencil. */
  function worldBubble(m, world, opts) {
    /* a player correction is a ledger note, not a line of dialogue */
    if (m.role === 'correction') {
      return '<div class="wr-note">' + esc(m.content || '') + '</div>';
    }
    /* the world's verdict on a check - compact, tinted by outcome */
    if (m.role === 'check') {
      var win = m.content.indexOf('\u2014 success') !== -1;
      return '<div class="wr-check-line' + (win ? ' ok' : ' fail') + '">' + esc(m.content || '') + '</div>';
    }
    var isMe = m.role === 'user';
    var who = isMe ? (Store.settings.userName || 'You') : (world.name || 'Referee');
    /* v1.35.1: the thread wears faces, like the persona chat - the referee
       bubble carries the world's banner, the player's bubble the active
       persona's photo when it has one. Initials when a face was never set. */
    var av = isMe
      ? avatarHtml(activePersonaAvatar(Store.settings), who)
      : avatarHtml((world && world.banner) || '', who);
    return '<div class="msg' + (isMe ? ' me' : '') + '">' +
      '<div class="av">' + av + '</div>' +
      '<div style="min-width:0;max-width:calc(100% - 44px)">' +
        '<div class="bubble">' +
          (!isMe ? '<div class="who">' + esc(who) + '</div>' : '') +
          '<div class="mtext">' + md(
            /* v1.39.8: turns stored BEFORE the briefing-echo strip read clean
               too - the sheet the model once quoted back is hidden, not
               deleted; the stored log itself is never rewritten. */
            isMe ? (m.content || '') : (HW.stripBriefingEcho ? HW.stripBriefingEcho(m.content || '') : (m.content || ''))
          ) + '</div>' +
        '</div>' +
        ((opts && opts.editable)
          ? '<div class="msg-actions"><button class="chip" data-act="wr-edit-turn">' +
            icon('edit') + ' Edit &amp; resend</button></div>'
          : '') +
      '</div></div>';
  }

  /* v1.39.8: no sheet at all any more. The HUD is one head row (place, time,
     purse, tasks, correct-state) plus the foldable task ledger - the stats,
     pockets and conditions still exist, in the Life tab and the correct-state
     dialog, where they were never in the way. */

  /* Time, stats, purse, pockets and tasks - whatever the world switches on.
     The third argument is the applied turn ({changes, rejections}) or a plain
     changes array. */
  Views.worldHud = function (world, run, applied) {
    var changes = applied && !Array.isArray(applied) ? applied.changes : applied;
    var rejections = applied && !Array.isArray(applied) ? applied.rejections : null;
    var advisories = applied && !Array.isArray(applied) ? applied.advisories : null;
    var checks = applied && !Array.isArray(applied) ? applied.checks : null;
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var loc = HW.location(world, run.locationId);
    var head = '<span class="wr-at">' + esc(loc ? loc.name : 'Somewhere') + '</span>';
    if (hud.showClock !== false) {
      head += '<span><b>' + esc(HW.clockOf(run, hud).text) + '</b> · turn ' + (run.turn || 0) + '</span>';
    }
    if ((gr.modules || {}).commerce !== false && run.stats[run.cashId] !== undefined) {
      head += '<span><b>' + esc(String(run.stats[run.cashId])) + '</b> ' +
             esc(gr.currencyName || 'cash') + '</span>';
    }
    /* v1.39.5: the open-task ledger is folded by hand on small screens -
       a pill in the head folds it away, and the fold is remembered ON the
       run (run.hudTasksOpen), so a phone stays readable across sessions.
       Old runs carry no marker and read open, exactly as before. */
    var openQuests = [];
    if ((gr.modules || {}).quests !== false) {
      openQuests = (run.quests || []).filter(function (q) { return !q.done; });
    }
    var tasksOpen = run.hudTasksOpen !== false;
    if (openQuests.length) {
      head += '<button type="button" class="wr-hud-fold" data-act="wr-hud-fold" ' +
        'title="Show or hide the open tasks">' + esc(String(openQuests.length)) +
        ' tasks ' + (tasksOpen ? '\u25be' : '\u25b8') + '</button>';
    }

    head += '<button type="button" class="wr-correct-btn" data-act="wr-correct" ' +
      'title="Set the clock, purse, stats, pockets or tasks by hand">correct state</button>';

    var out = '<div class="wr-hud-row">' + head + '</div>';
    if (openQuests.length) {
      out += '<div class="wr-hud-tasks"' + (tasksOpen ? '' : ' hidden') + '>' +
        'tasks: ' + esc(openQuests.map(function (q) { return q.text; }).join('; ')) + '</div>';
    }
    if (changes && changes.length) {
      out += '<div class="wr-changes">' + changes.map(function (c) {
        return '<span class="chip">' + esc(c) + '</span>';
      }).join('') + '</div>';
    }
    if (checks && checks.length) {
      out += '<div class="wr-changes">' + checks.map(function (c) {
        return '<span class="chip wr-check-chip' + (c.success ? ' ok' : ' fail') + '">' + esc(c.chip) + '</span>';
      }).join('') + '</div>';
    }
    if (rejections && rejections.length) {
      /* the world said no to some of the referee's bookkeeping - show the
         player what was refused, so a stuck scene is diagnosable */
      out += '<div class="wr-rejections">' + rejections.map(function (r) {
        return '<div class="wr-rej">rejected: ' + esc(r.tag) + ' \u2014 ' + esc(r.reason) + '</div>';
      }).join('') + '</div>';
    }
    if (advisories && advisories.length) {
      /* v1.20.0 - scene discipline: the player asked for something the
         ledger never recorded. Softer than a rejection - the story may be
         right and the tags wrong, or the ask may have failed in prose */
      out += '<div class="wr-advisories">' + advisories.map(function (a) {
        return '<div class="wr-adv">not recorded: ' + esc(a.claim) + ' \u2014 ' + esc(a.note) + '</div>';
      }).join('') + '</div>';
    }
    /* v1.42.2 (the memory research, §7): the record and the budget, on the one
       screen a player looks at when a story has started to drift. Three numbers,
       no dialog: what the world holds, what the last turn spent saying it, and
       what the world refused. It appears once there is something to report, so a
       first turn is not a wall of statistics, and it reports what the engine
       already knows — nothing here is measured by asking a model. */
    if (HW.sessionCounters) {
      var cnt = HW.sessionCounters(world, run);
      if (cnt.factsTotal || cnt.costs.total) {
        var bits = [cnt.facts + ' fact' + (cnt.facts === 1 ? '' : 's') + ' in memory' +
          (cnt.superseded ? ' \u2014 ' + cnt.superseded + ' superseded, none deleted' : '')];
        if (cnt.memoryTurn) bits.push('remembered through turn ' + cnt.memoryTurn);
        if (cnt.costs.total) bits.push('last turn \u2014 state ' + cnt.costs.state +
          ', memory ' + cnt.costs.memory + ', lore ' + cnt.costs.lore +
          ', history ' + cnt.costs.history + ' characters');
        if (cnt.rejections) bits.push(cnt.rejections + ' refused by the ledger' +
          (cnt.rejectionsShown < cnt.rejections ? ' (showing the last ' + cnt.rejectionsShown + ')' : ''));
        if (cnt.advisories) bits.push(cnt.advisories + ' said but not recorded');
        out += '<div class="wr-hud-tasks wr-counters">' + esc(bits.join(' \u00b7 ')) + '</div>';
      }
    }
    return out;
  };

  Views.bindWorldHud = function (hud, world, run) {
    /* v1.39.5: fold the task ledger - the choice travels with the run. */
    on(hud, '[data-act=wr-hud-fold]', 'click', function () {
      if (!run) return;
      var openNow = run.hudTasksOpen !== false;
      run.hudTasksOpen = !openNow;
      var tbox = hud.querySelector('.wr-hud-tasks');
      if (tbox) tbox.hidden = !run.hudTasksOpen;
      var fbtn = hud.querySelector('[data-act=wr-hud-fold]');
      if (fbtn) fbtn.textContent = fbtn.textContent
        .replace(/[\u25b8\u25be]/, run.hudTasksOpen ? '\u25be' : '\u25b8');
      if (HW.saveRun) HW.saveRun(run);
    });
    on(hud, '[data-act=wr-correct]', 'click', function () {
      /* v1.21.0 (upstream 18.3.5): opening the correct-state screen is fine,
         but a turn applying tags is mutating the same run object — wait. */
      if (App.state.worldBusy) return UI.toast('Wait for the current turn to finish');
      if (App.state.worldRun) App.go('worldcorrect');
    });
  };

  /** v1.25.0: the whole run, in a sheet - the phone's answer to the desktop
     sidebar. Everything the HUD knows, always expanded: place and exits,
     time, numbers, purse, pockets, tasks, and the party. */
  /** v1.26.0: Settings → Appearance. One row per theme — a strip of the
     theme's own colors, the name, and an "on" mark on the current pick.
     Tapping applies in place and persists. */
  Views.settingsAppearance = function () {
    var body = $('#settings-x-body');
    var cur = (Store.settings && Store.settings.theme) || 'midnight';
    var h = '<p class="hint" style="margin:0 0 10px">The whole app re-colors in place. The pick is saved on this phone.</p>';
    THEMES.list().forEach(function (id) {
      var t = THEMES.get(id), tk = t.tokens;
      h += '<div class="theme-row' + (id === cur ? ' on' : '') + '" data-th="' + id + '">' +
        '<span class="theme-dots">' +
          '<i style="background:' + tk['--bg'] + '"></i>' +
          '<i style="background:' + tk['--surface'] + '"></i>' +
          '<i style="background:' + tk['--accent'] + '"></i>' +
          '<i style="background:' + tk['--accent-2'] + '"></i>' +
          '<i style="background:' + tk['--text'] + '"></i>' +
        '</span>' +
        '<span class="theme-name">' + esc(t.name) + '</span>' +
        (id === cur ? '<span class="pill theme-check">on</span>' : '') +
        '</div>';
    });
    body.innerHTML = h;
    (body.querySelectorAll ? body.querySelectorAll('[data-th]') : []).forEach(function (row) {
      row.onclick = function () {
        App.chooseTheme(row.getAttribute('data-th')).then(function () {
          Views.settingsAppearance();       /* move the "on" mark */
        });
      };
    });
  };

  /* v1.35.0: a look inside a world before you live in it. Read-only - the
     same parsed truth the referee runs on, shaped for a person's eyes. */
  /* v1.37.0: name a gate without opening it */
  function worldFactionName(world, id) {
    var f = (world.factions || []).find(function (x) { return x.id === id; });
    return (f && f.name) || id;
  }
  function worldNpcName(world, ref) {
    var low = String(ref || '').toLowerCase();
    var n = (world.entities || []).find(function (e) {
      return String(e.id).toLowerCase() === low || String(e.name).toLowerCase() === low;
    });
    return (n && n.name) || ref;
  }

  Views.worldSummary = function (world) {
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var h = '';
    h += '<div class="ws-head">' + avatarHtml(world.banner, world.name) +
         '<div class="ws-head-name">' + esc(world.name) + '</div></div>';
    if (world.description) h += '<div class="hint">' + esc(world.description) + '</div>';

    h += '<h3>The clock</h3>';
    var hh = ('0' + (hud.startTimeHours || 8)).slice(-2), mm = ('0' + (hud.startTimeMinutes || 0)).slice(-2);
    h += '<div class="hint">Begins ' + esc((hud.startWeekday || 'Monday')) + ' ' + hh + ':' + mm +
         ' · ' + (hud.timeStep || 5) + ' minutes a turn</div>';

    var mods = gr.modules || {};
    var on = Object.keys(mods).filter(function (k) { return !!mods[k]; });
    if (on.length) h += '<div class="hint">Systems: ' + esc(on.join(', ')) + '</div>';

    h += '<h3>Places</h3>';
    h += (world.locations || []).map(function (l) {
      return '<div class="ws-item">' + esc(l.name) +
             ' <span class="hint">' + esc(l.mapType || 'room') + '</span></div>';
    }).join('');

    h += '<h3>People</h3>';
    h += (world.entities || []).map(function (e) {
      var day = (e.schedule || []).length;
      return '<div class="ws-item"><b>' + esc(e.name) + '</b>' +
        (e.persona ? ' <span class="hint">' + esc(HW.synopsis(e.persona, 140)) + '</span>' : '') +
        (e.goal ? '<div class="hint">wants: ' + esc(e.goal) + '</div>' : '') +
        (day ? '<div class="hint">a ' + day + '-stop day</div>' : '') +
        '</div>';
    }).join('');

    if ((world.factions || []).length) {
      h += '<h3>Factions</h3>';
      h += world.factions.map(function (f) {
        return '<div class="ws-item"><b>' + esc(f.name) + '</b>' +
               (f.goal ? ' <span class="hint">' + esc(HW.synopsis(f.goal, 120)) + '</span>' : '') + '</div>';
      }).join('');
    }

    /* v1.37.0, the open book: a peek tells you the book exists - keys and
       gates visible, secret entries sealed so the story is never spoiled;
       a keyword the world itself never says is hinted, not hidden. */
    var book = world.lorebook || [];
    if (book.length) {
      h += '<h3>The known book</h3>';
      h += book.map(function (entry) {
        var kb = String(entry.knownBy || '').toLowerCase().trim();
        var row = '<div class="ws-item"><b>' + esc(entry.keyword || '(no keyword)') + '</b>';
        if (kb === 'secret') {
          var hinges = [];
          if (entry.unlockQuest) hinges.push('a task reaching «' + entry.unlockQuest + '»');
          if (entry.unlockNpc) hinges.push(worldNpcName(world, entry.unlockNpc) + ' being here');
          row += ' <span class="hint">sealed - ' +
            (hinges.length ? 'opens with ' + esc(hinges.join('; '))
                           : 'nothing that opens it is named') + '</span>';
        } else {
          if (kb.indexOf('faction:') === 0) {
            row += ' <span class="hint">known inside ' + esc(worldFactionName(world, kb.slice(8).trim())) + '</span>';
          } else if (kb.indexOf('npc:') === 0) {
            row += ' <span class="hint">speaks near ' + esc(worldNpcName(world, kb.slice(4).trim())) + '</span>';
          } else if (kb && kb !== 'anyone') {
            row += ' <span class="hint">known by ' + esc(entry.knownBy) + '</span>';
          }
          if (HW.deadKey && HW.deadKey(world, entry)) {
            row += ' <span class="hint" style="opacity:.7">never said anywhere in the world itself - this key may go unheard</span>';
          }
          if (entry.text) row += ' <span class="hint">' + esc(HW.synopsis(entry.text, 140)) + '</span>';
        }
        return row + '</div>';
      }).join('');
    }

    /* v1.38.0: the classes page - bundles are chosen openly at begin, so
       the peek says what each brings. No secrets here. */
    if ((world.classes || []).length) {
      h += '<h3>Classes</h3>';
      h += world.classes.map(function (c) {
        var sk = (c.skills || []).map(function (id) {
          var s = null;
          (world.skillsCatalog || []).forEach(function (t) { if (t.id === id) s = t; });
          return (s && s.name) || id;
        });
        return '<div class="ws-item"><b>' + esc(c.name) + '</b>' +
          (c.description ? ' <span class="hint">' + esc(HW.synopsis(c.description, 120)) + '</span>' : '') +
          (sk.length ? '<div class="hint">brings: ' + esc(sk.join(', ')) + '</div>' : '') +
          (c.outfit ? '<div class="hint">wears: ' + esc(c.outfit) + '</div>' : '') + '</div>';
      }).join('');
    }

    if ((world.startingLives || []).length) {
      h += '<h3>Ways to begin</h3>';
      h += world.startingLives.map(function (l) {
        return '<div class="ws-item">' + esc(l.name) +
               (l.role ? ' <span class="hint">' + esc(l.role) + '</span>' : '') + '</div>';
      }).join('');
    }

    h += '<h3>Under the hood</h3>';
    h += '<div class="hint">' +
      (world.locations || []).length + ' places · ' +
      (world.entities || []).length + ' people · ' +
      ((world.factions || []).length) + ' factions · ' +
      ((world.relationships || []).length) + ' ties · ' +
      ((world.lorebook || []).length) + ' lore, ' +
      ((hud.stats || []).length) + ' numbers tracked' +
      (((gr.checks || []).length) ? ' · ' + gr.checks.length + ' named checks' : '') +
      '</div>';
    return h;
  };

  Views.worldStatusSheet = function (world, run) {
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var loc = HW.location(world, run.locationId);
    var stats = hud.stats || [];

    var h = '';
    /* v1.30.0: the world's face, the same banner the PC version shows */
    h += '<div class="ws-head">' + avatarHtml(world.banner, world.name) +
         '<div class="ws-head-name">' + esc(world.name) + '</div></div>';
    h += '<h3>Where you are</h3>';
    h += '<div class="ws-loc">' + esc(loc ? loc.name : 'Somewhere') + '</div>';
    var ex = HW.exits(world, run.locationId) || [];
    h += ex.length
      ? '<div class="hint">You can go: ' + esc(ex.map(function (e) {
          return String(e.text || e.to || '').replace(/^to\s+/i, '');
        }).join(', ')) + '</div>'
      : '<div class="hint">The world has not said where you can go yet.</div>';

    h += '<h3>Time</h3>';
    h += '<div class="ws-time">' + (hud.showClock !== false ? esc(HW.clockOf(run, hud).text) + ' · ' : '') +
         'turn ' + (run.turn || 0) + '</div>';
    /* v1.32.0: the calendar the world declares, and who you set out to be */
    var wsSeas = HW.seasonText(world, run);
    if (wsSeas) h += '<div class="hint">Season: ' + esc(wsSeas) + '</div>';
    if (run.identity) h += '<div class="hint">You are: ' + esc(run.identity) + '</div>';
    if (run.outfit) h += '<div class="hint">Wearing: ' + esc(run.outfit) + '</div>';
    /* v1.34.0: the floor is not a number to glance past - it changes what
       the next scene is about */
    if (run.downed) h += '<div class="hint"><b>Downed</b> — the next scene starts from consequences, not game over.</div>';
    /* v1.29.1: the referee's receipt - which Horde model actually answered
       the last turn, and the worker it ran on. "Requested" is a setting;
       this is what came back. */
    if (run.lastModel) {
      h += '<div class="hint">Referee: ' + esc(run.lastModel) +
           (run.lastWorker ? ' · worker ' + esc(String(run.lastWorker).slice(0, 12)) : '') + '</div>';
    }

    h += '<h3>Numbers</h3>';
    var anyStat = false;
    var wsVital = (HW.vitalStat && HW.vitalStat(world)) || null;
    stats.forEach(function (st) {
      var v = run.stats[st.id];
      if (v === undefined) return;
      anyStat = true;
      /* v1.34.0: the vital stat's mark, even on the big sheet */
      h += '<div class="ws-stat"><span>' + esc(st.name) + (wsVital === st.id ? ' ✧' : '') + '</span><b>' +
           esc(String(v)) +
           (st.max ? '/' + esc(String(st.max)) : '') + '</b></div>';
    });
    if ((gr.modules || {}).commerce !== false && run.stats[run.cashId] !== undefined) {
      anyStat = true;
      h += '<div class="ws-stat"><span>' + esc(gr.currencyName || 'Cash') + '</span><b>' +
           esc(String(run.stats[run.cashId])) + '</b></div>';
    }
    if (!anyStat) h += stats.length
      ? '<div class="hint">This world keeps ' + stats.length + ' number' + (stats.length === 1 ? '' : 's') + ', but the referee has not reported a value for any of them yet.</div>'
      : '<div class="hint">This world keeps no numbers — its rules declare no tracked stats.</div>';

    /* v1.34.0: conditions get their own corner of the sheet, and the floor
       is announced where the clock lives. */
    if ((gr.modules || {}).conditions) {
      h += '<h3>Conditions</h3>';
      h += (run.conditions && run.conditions.length)
        ? run.conditions.map(function (c) { return '<div class="ws-item">' + esc(c) + '</div>'; }).join('')
        : '<div class="hint">None, for the moment.</div>';
    }

    if ((gr.modules || {}).inventory !== false) {
      h += '<h3>Pockets</h3>';
      h += (run.inventory && run.inventory.length)
        ? run.inventory.map(function (it) { return '<div class="ws-item">' + esc(it) + '</div>'; }).join('')
        : '<div class="hint">Empty.</div>';
    }

    /* v1.35.0: equipment on the big sheet, slot by slot, in the order the
       world declared the slots */
    if ((gr.modules || {}).equipment && HW.equipmentSlots) {
      h += '<h3>Equipment</h3>';
      var slots = HW.equipmentSlots(world), worn = [];
      slots.forEach(function (s) {
        if (run.equip && run.equip[s]) worn.push([s, run.equip[s]]);
      });
      h += worn.length
        ? worn.map(function (pair) {
            return '<div class="ws-item">' + esc(pair[1]) + ' <span class="hint">(' + esc(pair[0]) + ')</span></div>';
          }).join('')
        : '<div class="hint">Nothing equipped.</div>';
    }

    if ((gr.modules || {}).quests !== false) {
      var all = run.quests || [];
      var open = all.filter(function (q) { return !q.done; });
      h += '<h3>Tasks</h3>';
      h += open.length
        ? open.map(function (q) { return '<div class="ws-item">' + esc(q.text) + '</div>'; }).join('')
        : '<div class="hint">Nothing to do right now.</div>';
      if (all.length - open.length) h += '<div class="hint">' + (all.length - open.length) + ' finished.</div>';
    }

    /* v1.24.0 companion ledger - the party, and where they joined */
    var party = run.companions || [];
    h += '<h3>Party</h3>';
    h += party.length
      ? party.map(function (c) {
          var at = HW.location(world, c.at);
          return '<div class="ws-item">' + esc(c.name) +
                 (at ? ' <span class="hint">(joined at ' + esc(at.name) + ', turn ' + (c.since || 0) + ')</span>' : '') +
                 '</div>';
        }).join('')
      : '<div class="hint">No one is with you right now.</div>';

    /* v1.39.100: what the run believes, and what it used to believe. A fact
       that has been superseded is still on the record - this is where the
       player can see that the old level or the finished task did not just
       vanish, it was replaced, on a turn. */
    var nowFacts = (HW.currentFacts && HW.currentFacts(run)) || [];
    var oldFacts = (HW.pastFacts && HW.pastFacts(run)) || [];
    if (run.memory && (run.memory.summary || nowFacts.length || oldFacts.length)) {
      if (run.memory.summary) {
        h += '<h3>Story so far</h3>';
        h += '<div class="hint">' + esc(run.memory.summary) + '</div>';
      }
      if (nowFacts.length) {
        h += '<h3>What the world holds true</h3>';
        h += nowFacts.slice().sort(function (a, b) { return (b.from || 0) - (a.from || 0); })
          .map(function (f) {
            return '<div class="ws-item">' + esc(f.text) +
              ' <span class="hint">(turn ' + (f.from || 0) + ')</span></div>';
          }).join('');
      }
      if (oldFacts.length) {
        h += '<h3>No longer true</h3>';
        h += '<div class="hint">Kept for the record. The referee is not shown these as current.</div>';
        h += oldFacts.slice(0, 8).map(function (f) {
          return '<div class="ws-item"><span class="hint">' + esc(f.text) +
            ' — until turn ' + (f.to || 0) + '</span></div>';
        }).join('');
        if (oldFacts.length > 8) h += '<div class="hint">…and ' + (oldFacts.length - 8) + ' more.</div>';
      }
    }

    return h;
  };

  Views.worldRun = function (world, run, changes) {
    var hud = $('#wr-hud'), thread = $('#wr-thread');
    if (hud) {
      hud.hidden = false;
      hud.innerHTML = Views.worldHud(world, run, changes);
      Views.bindWorldHud(hud, world, run);
    }
    if (!thread) return;
    /* v1.39.9: the tail of the conversation is the only place a turn can be
       taken back (one snapshot, one level). Find the player's last line. */
    var wlog = run.log || [], lastUser = -1;
    for (var wi = wlog.length - 1; wi >= 0; wi--) {
      if (wlog[wi].role === 'user') { lastUser = wi; break; }
    }
    var canEdit = !!(run.lastTurnPre) && !(App.state && App.state.worldBusy);
    thread.innerHTML = wlog.map(function (m, i) {
      return worldBubble(m, world, { editable: canEdit && i === lastUser });
    }).join('');
    if (changes) {
      /* v1.24.2: a finished turn is a whole scene that appears at once, and
         the old scroll-to-bottom stranded the reader at the END of it -
         back up they had to go to read the beginning. Anchor at the top of
         the reply that just arrived (the last non-player message). Check
         lines and correction notes after the reply don't move the anchor.
         Opening a run and sending a message still land at the bottom. */
      var reply = null, kids = thread.children || [];
      for (var i = kids.length - 1; i >= 0; i--) {
        var k = kids[i];
        if (k && k.classList && k.classList.contains('msg') && !k.classList.contains('me')) { reply = k; break; }
      }
      thread.scrollTop = reply ? reply.offsetTop : thread.scrollHeight;
      return;
    }
    thread.scrollTop = thread.scrollHeight;
  };

  /* v1.17.0: the ledger can be set straight by hand. Every applied change
     is logged into the run as a correction, so the referee's next prompt
     carries the truth, not the story. */
  Views.worldCorrect = function (root) {
    var world = App.state.world, run = App.state.worldRun;
    /* v1.27.1: the body div lives in its own <section>. The root that
       arrives here is the FIRST .screen in the DOM, where the div is not
       - resolving it against root rendered a blank screen on the device.
       Every other view resolves its container by id, so do that. */
    var body = $('#world-correct-body');
    if (!body) return;
    if (!world || !run) {
      body.innerHTML = '<p class="hint">No run to correct.</p>';
      return;
    }

    var hud = world.hudConfig || {}, gr = world.gameRules || {};
    var cur = HW.location(world, run.locationId);
    var reachableIds = {};
    (HW.exits(world, run.locationId) || []).forEach(function (e) {
      if (e.to) reachableIds[e.to] = true;
    });
    reachableIds[run.locationId] = true;

    var inv = (run.inventory || []).slice();
    var quests = (run.quests || []).map(function (q) { return { text: q.text, done: !!q.done }; });
    /* v1.28.0: the party, editable by hand (names only; the ledger keeps
       where/when, and the referee keeps talking as if it were true). */
    var party = (run.companions || []).map(function (c) { return c.name; });

    var h = '<div class="group">';
    h += '<h3>Where you are</h3>';
    h += '<div class="field"><select id="wc-loc">';
    (world.locations || []).forEach(function (l) {
      h += '<option value="' + esc(l.id) + '"' + (l.id === run.locationId ? ' selected' : '') + '>' +
        esc(l.name) + (l.id === run.locationId ? ' (here)' : '') + '</option>';
    });
    h += '</select></div><p class="hint" id="wc-loc-hint"></p>';

    h += '<h3>Numbers</h3>';
    h += '<div class="field"><label class="lbl">' + esc(gr.currencyName || 'Cash') + '</label>' +
      '<input id="wc-cash" type="number" step="1" value="' +
      (run.stats[run.cashId] !== undefined ? run.stats[run.cashId] : 0) + '"></div>';
    (hud.stats || []).forEach(function (st) {
      h += '<div class="field"><label class="lbl">' + esc(st.name) + '</label>' +
        '<input id="wc-stat-' + esc(st.id) + '" type="number" step="1" value="' +
        (run.stats[st.id] !== undefined ? run.stats[st.id] : 0) + '"></div>';
    });

    /* v1.29.1: the clock by hand - a shift in minutes for a run whose
       [[clock:+N]] tags have drifted from the story */
    h += '<h3>Time</h3>' +
      '<div class="field row"><input id="wc-clock" type="number" step="5" placeholder="Shift the clock by minutes (e.g. -30)">' +
      '<button class="btn sm" id="wc-clock-go">Shift</button></div>' +
      '<p class="hint">Applied with the corrections below; the shift is logged in the run.</p>';

    h += '<h3>Pockets</h3><div class="wc-inv" id="wc-inv"></div>' +
      '<div class="field row"><input id="wc-item" type="text" placeholder="Add an item…">' +
      '<button class="btn sm" id="wc-item-add">Add</button></div>';

    h += '<h3>Party</h3><div class="wc-inv" id="wc-party"></div>' +
      '<div class="field row"><input id="wc-companion" type="text" placeholder="Add a companion… (any name the story uses)">' +
      '<button class="btn sm" id="wc-companion-add">Add</button></div>';

    h += '<h3>Tasks</h3><div id="wc-quests"></div>' +
      '<div class="field row"><input id="wc-quest" type="text" placeholder="Add a task…">' +
      '<button class="btn sm" id="wc-quest-add">Add</button></div>';

    h += '<p class="hint">The referee is told nothing about how the state was ' +
      'reached \u2014 it simply continues from it. Corrections are kept in the ' +
      'run\u2019s log.</p>' +
      '<button class="btn" id="wc-save">Apply corrections</button></div>';

    body.innerHTML = h;

    function renderInv() {
      body.querySelector('#wc-inv').innerHTML = inv.length ? inv.map(function (it, i) {
        return '<span class="chip wc-chip">' + esc(it) +
          '<button type="button" class="wc-x" data-wc-drop="' + i + '" aria-label="Remove ' + esc(it) + '">\u00D7</button></span>';
      }).join('') : '<p class="hint">Nothing to remove.</p>';
    }
    function renderParty() {
      body.querySelector('#wc-party').innerHTML = party.length ? party.map(function (nm, i) {
        return '<span class="chip wc-chip">' + esc(nm) +
          '<button type="button" class="wc-x" data-wc-comp="' + i + '" aria-label="Remove ' + esc(nm) + '">\u00D7</button></span>';
      }).join('') : '<p class="hint">No one is with you.</p>';
    }
    function renderQuests() {
      body.querySelector('#wc-quests').innerHTML = quests.length ? quests.map(function (q) {
        var rm = '<button type="button" class="btn sm ghost" data-wc-remove="' + esc(q.text) + '">Remove</button>';
        return q.done
          ? '<div class="wc-quest done">' + esc(q.text) + ' <em>done</em> ' + rm + '</div>'
          : '<div class="wc-quest">' + esc(q.text) +
            '<button type="button" class="btn sm ghost" data-wc-done="' + esc(q.text) + '">Done</button> ' +
            rm + '</div>';
      }).join('') : '<p class="hint">No tasks.</p>';
    }
    renderInv();
    renderParty();
    renderQuests();

    /* container-level listeners: the chips re-render, the container does not */
    body.querySelector('#wc-inv').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-drop]') : null;
      if (!btn) return;
      inv.splice(+btn.getAttribute('data-wc-drop'), 1);
      renderInv();
    });
    body.querySelector('#wc-party').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-comp]') : null;
      if (!btn) return;
      party.splice(+btn.getAttribute('data-wc-comp'), 1);
      renderParty();
    });
    body.querySelector('#wc-quests').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-done]') : null;
      if (btn) {
        var t = btn.getAttribute('data-wc-done');
        quests.forEach(function (q) {
          if (!q.done && q.text.toLowerCase().indexOf(t.toLowerCase()) !== -1) q.done = true;
        });
        renderQuests();
        return;
      }
      /* v1.29.1: a task that was recorded in error can leave the ledger */
      var rm = e.target.closest ? e.target.closest('[data-wc-remove]') : null;
      if (!rm) return;
      var rt = rm.getAttribute('data-wc-remove');
      for (var qi = quests.length - 1; qi >= 0; qi--) {
        if (quests[qi].text === rt) { quests.splice(qi, 1); break; }
      }
      renderQuests();
    });

    var locSel = body.querySelector('#wc-loc');
    function locHint() {
      var id = locSel.value;
      body.querySelector('#wc-loc-hint').textContent =
        id === run.locationId ? '' :
        reachableIds[id] ? 'Directly reachable from here.' :
        'Not directly reachable from ' + (cur ? cur.name : 'here') +
        ' \u2014 the move will be forced.';
    }
    locSel.addEventListener('change', locHint);
    locHint();

    on(body, '#wc-item-add', 'click', function () {
      var v = body.querySelector('#wc-item').value.trim();
      if (!v) return;
      inv.push(v);
      body.querySelector('#wc-item').value = '';
      renderInv();
    });
    on(body, '#wc-companion-add', 'click', function () {
      var v = body.querySelector('#wc-companion').value.trim();
      if (!v) return;
      party.push(v);
      body.querySelector('#wc-companion').value = '';
      renderParty();
    });
    on(body, '#wc-quest-add', 'click', function () {
      var v = body.querySelector('#wc-quest').value.trim();
      if (!v) return;
      quests.push({ text: v, done: false });
      body.querySelector('#wc-quest').value = '';
      renderQuests();
    });
    on(body, '#wc-clock-go', 'click', function () {
      body.querySelector('#wc-save').click();
    });
    on(body, '#wc-save', 'click', function () {
      /* v1.21.0 (upstream 18.3.5): a turn mid-apply and a manual correction
         writing the same run object at once is how tags lose each other. */
      if (App.state.worldBusy) {
        UI.toast('Wait for the current turn to finish');
        return;
      }
      /* one correction object per change - correctState applies exactly one
         of each kind, so several edits mean several calls */
      var corrs = [];
      if (locSel.value !== run.locationId) corrs.push({ locationId: locSel.value });
      var cashEl = body.querySelector('#wc-cash');
      var cashNow = run.stats[run.cashId] !== undefined ? run.stats[run.cashId] : 0;
      if (cashEl.value !== '' && Number(cashEl.value) !== cashNow) {
        corrs.push({ cash: Number(cashEl.value) });
      }
      (hud.stats || []).forEach(function (st) {
        var el = body.querySelector('#wc-stat-' + st.id);
        if (!el) return;
        var now = run.stats[st.id] !== undefined ? run.stats[st.id] : 0;
        if (el.value !== '' && Number(el.value) !== now) {
          var s = {}; s[st.id] = Number(el.value);
          corrs.push({ stats: s });
        }
      });
      var oldInv = run.inventory || [];
      oldInv.forEach(function (x) { if (inv.indexOf(x) === -1) corrs.push({ removeInventory: x }); });
      inv.forEach(function (x) { if (oldInv.indexOf(x) === -1) corrs.push({ addInventory: x }); });
      var oldParty = (run.companions || []).map(function (c) { return c.name; });
      oldParty.forEach(function (x) { if (party.indexOf(x) === -1) corrs.push({ removeCompanion: x }); });
      party.forEach(function (x) { if (oldParty.indexOf(x) === -1) corrs.push({ addCompanion: x }); });
      (run.quests || []).forEach(function (o) {
        var now = null;
        quests.forEach(function (q) { if (q.text === o.text) now = q; });
        if (!now) { corrs.push({ removeQuest: o.text }); return; }
        if (now.done && !o.done) corrs.push({ doneQuestText: o.text });
      });
      quests.forEach(function (q) {
        if (!(run.quests || []).some(function (o) { return o.text === q.text; })) {
          corrs.push({ addQuest: q.text });
        }
      });
      /* v1.29.1: a manual clock shift, applied like any other correction */
      var clockEl = body.querySelector('#wc-clock');
      if (clockEl && clockEl.value !== '' && !isNaN(Number(clockEl.value)) && Number(clockEl.value) !== 0) {
        corrs.push({ clockDelta: Number(clockEl.value) });
        clockEl.value = '';
      }

      var changes = [];
      corrs.forEach(function (c) { changes = changes.concat(HW.correctState(world, run, c)); });
      if (!changes.length) { UI.toast('Nothing to change'); return; }
      run.log.push({ role: 'correction', content: 'State corrected: ' + changes.join('; '), at: Date.now() });
      if (run.log.length > 200) run.log = run.log.slice(-200);
      HW.saveRun(run).then(function () {
        App.go('worldrun');
        Views.worldRun(world, run, { changes: changes, rejections: [] });
        UI.toast('World state corrected');
      });
    });
  };

  Views.worlds = function (root) {
    var body = $('#worlds-body');
    if (!body) return;

    Promise.all([HW.all(), HW.allRuns(), HW.bundled()]).then(function (res) {
      var list = res[0] || [], runs = res[1] || [], shipped = res[2] || [];
      var have = {};
      list.forEach(function (w) { have[w.id] = 1; });
      var offered = shipped.filter(function (e) { return !have[e.id]; });
      /* v1.30.0: the face each run card gets is its WORLD's banner */
      var bannerOf = {};
      list.forEach(function (w) { bannerOf[w.id] = w.banner; });
      var html = '';

      if (runs.length) {
        html += '<div class="group"><div class="group-title">In progress</div>' +
          runs.map(function (r) {
            return '<div class="wr-card" data-run="' + esc(r.id) + '">' +
              '<span class="item-av">' + avatarHtml(bannerOf[r.worldId], r.worldName || 'World') + '</span>' +
              '<div style="flex:1;min-width:0">' +
                '<div class="wr-name">' + esc(r.worldName || 'World') + '</div>' +
                '<div class="wr-sub">' + esc(r.lifeName ? 'as ' + r.lifeName : '') +
                  (r.lifeName ? ' · ' : '') + 'turn ' + (r.turn || 0) + '</div>' +
              '</div>' +
              '<button class="chip" data-act="wr-del" data-run="' + esc(r.id) + '">' + icon('trash') + '</button>' +
            '</div>';
          }).join('') + '</div>';
      }

      html += '<div class="group"><div class="group-title">Installed worlds</div>';
      if (!list.length) {
        html += '<div class="empty" style="padding:16px 4px"><p>No worlds yet. Describe one and let ' +
          'AI create it, or import a <b>.horde_world</b> file. Its artwork is stripped on the ' +
          'way in — except the world&#39;s banner, which is kept (dieted down) as its avatar.</p></div>';
      } else {
        html += list.map(function (w) {
          var sum = HW.summarise(w);
          return '<div class="wr-card" data-world="' + esc(w.id) + '">' +
            '<span class="item-av">' + avatarHtml(w.banner, w.name) + '</span>' +
            '<div style="flex:1;min-width:0">' +
              '<div class="wr-name">' + esc(w.name) + '</div>' +
              '<div class="wr-sub">' + sum.locations + ' places · ' + sum.people + ' people · ' +
                sum.factions + ' factions · ' + sum.lore + ' lore</div>' +
              (w.description
                ? '<div class="wr-sub" style="margin-top:4px">' +
                  esc(String(w.description).slice(0, 160)) + '</div>' : '') +
            '</div>' +
            '<button class="chip" data-act="world-peek" data-world="' + esc(w.id) + '" ' +
              'title="Look inside - read-only">' + icon('eye') + '</button>' +
            '<button class="chip" data-act="world-del" data-world="' + esc(w.id) + '">' + icon('trash') + '</button>' +
          '</div>';
        }).join('');
      }
      if (offered.length) {
        html += '<div class="group"><div class="group-title">Available to install</div>' +
          offered.map(function (e) {
            return '<div class="wr-card" data-install="' + esc(e.id) + '">' +
              '<div style="flex:1;min-width:0">' +
                '<div class="wr-name">' + esc(e.name) + '</div>' +
                '<div class="wr-sub">' + (e.places || 0) + ' places · ' + (e.people || 0) +
                  ' people · ' + (e.factions || 0) + ' factions · ' + (e.roles || 0) + ' ways to begin</div>' +
                (e.description ? '<div class="wr-sub" style="margin-top:4px">' +
                  esc(e.description) + '</div>' : '') +
                (e.attribution ? '<div class="wr-sub" style="margin-top:4px;opacity:.7">' +
                  esc(e.attribution) + '</div>' : '') +
              '</div>' +
              '<button class="chip" data-act="world-peek-bundled" data-install="' + esc(e.id) + '" ' +
                'title="Look inside before installing">' + icon('eye') + '</button>' +
              '<button class="chip" data-act="world-install" data-install="' + esc(e.id) + '">Install</button>' +
            '</div>';
          }).join('') + '</div>';
      }

      html += '</div>';
      html += '<div class="field">' +
        '<button class="btn primary block sm" data-act="world-create">' +
          icon('sparkle') + ' Create a world with AI</button>' +
        '<button class="btn ghost block sm" style="margin-top:6px" data-act="world-import">' +
          icon('plus') + ' Import a world file</button></div>';

      body.innerHTML = html;

      on(body, '[data-act=world-create]', 'click', function () { App.aiCreateWorld(); });
      on(body, '[data-act=world-import]', 'click', function () { App.importWorld(); });
      on(body, '[data-world]', 'click', function (e) {
        if (e.target.closest('[data-act]')) return;
        App.startWorld(this.getAttribute('data-world'));
      });
      on(body, '[data-run]', 'click', function (e) {
        if (e.target.closest('[data-act]')) return;
        App.openWorldRun(this.getAttribute('data-run'));
      });
      /* v1.35.0: peek without commitment - installed worlds from the
         library, catalogue worlds fetched without saving */
      on(body, '[data-act=world-peek]', 'click', function () {
        var id = this.getAttribute('data-world');
        var w = null;
        list.forEach(function (x) { if (x.id === id) w = x; });
        if (!w) return;
        UI.sheet({ title: w.name, body: Views.worldSummary(w),
          actions: [{ label: 'Begin here', cls: 'primary', onClick: function () { App.startWorld(id); } },
                    { label: 'Close', cls: 'ghost', value: null }] });
      });
      on(body, '[data-act=world-peek-bundled]', 'click', function () {
        var id = this.getAttribute('data-install');
        HW.peekBundled(id).then(function (w) {
          UI.sheet({ title: w.name, body: Views.worldSummary(w),
            actions: [{ label: 'Install', cls: 'primary', onClick: function () {
                        HW.installBundled(id).then(function (iw) {
                          UI.toast('Installed ' + (iw && iw.name), 3200);
                          App.go('worlds');
                        }).catch(function (e2) { UI.toast((e2 && e2.message) || 'Could not install', 4500); });
                      } },
                      { label: 'Close', cls: 'ghost', value: null }] });
        }).catch(function (e) { UI.toast((e && e.message) || 'Could not open that world', 4500); });
      });
      on(body, '[data-act=world-install]', 'click', function () {
        var id = this.getAttribute('data-install');
        HW.installBundled(id).then(function (w) {
          UI.toast('Installed ' + (w && w.name), 3200);
          App.go('worlds');
        }).catch(function (e) {
          UI.toast((e && e.message) || 'Could not install that world', 4500);
        });
      });
      on(body, '[data-act=world-del]', 'click', function () {
        var id = this.getAttribute('data-world');
        UI.confirm('Delete this world?', 'Any playthroughs in it are removed too.',
          { danger: true, okLabel: 'Delete' }).then(function (yes) {
          if (!yes) return;
          HW.remove(id).then(function () { App.go('worlds'); });
        });
      });
      on(body, '[data-act=wr-del]', 'click', function () {
        var id = this.getAttribute('data-run');
        UI.confirm('Abandon this run?', 'The story so far is deleted.',
          { danger: true, okLabel: 'Abandon' }).then(function (yes) {
          if (!yes) return;
          HW.removeRun(id).then(function () { App.go('worlds'); });
        });
      });
    });
  };

  /* The roles a world lets you begin as, when it offers more than one. */
  Views.worldRoles = function (world) {
    var body = $('#worlds-body');
    if (!body) return;
    var lives = world.startingLives || [];
    body.innerHTML =
      '<div class="group"><div class="group-title">Begin as…</div>' +
      lives.map(function (l) {
        return '<div class="wr-card" data-life="' + esc(l.id) + '">' +
          '<div style="flex:1;min-width:0">' +
            '<div class="wr-name">' + esc(l.name || l.role || 'Someone') + '</div>' +
            (l.role ? '<div class="wr-sub">' + esc(l.role) +
              (l.socialRank ? ' · ' + esc(l.socialRank) : '') + '</div>' : '') +
            (l.description ? '<div class="wr-sub" style="margin-top:4px">' +
              esc(l.description) + '</div>' : '') +
          '</div></div>';
      }).join('') + '</div>' +
      '<div class="field"><button class="btn ghost block sm" data-act="worlds-back">Back to worlds</button></div>';

    on(body, '[data-life]', 'click', function () {
      /* v1.38.0: after the life, the class gate (which passes plain
         worlds straight through to the begin) */
      App.beginOrPickClass(world.id, this.getAttribute('data-life'));
    });
    on(body, '[data-act=worlds-back]', 'click', function () { App.go('worlds'); });
  };

  /* v1.38.0: the class gate - worlds that declare classes ask after the
     life is chosen; every row carries what the class brings, and "No
     class" is always a legitimate door. */
  Views.worldClasses = function (world, lifeId) {
    var body = $('#worlds-body');
    if (!body) return;
    body.innerHTML =
      '<div class="group"><div class="group-title">Pick a class</div>' +
      ((world.classes || []).map(function (c) {
        var sk = (c.skills || []).map(function (id) {
          var s = null;
          (world.skillsCatalog || []).forEach(function (t) { if (t.id === id) s = t; });
          return (s && s.name) || id;
        });
        return '<div class="wr-card" data-cls="' + esc(c.id) + '">' +
          '<div style="flex:1;min-width:0">' +
            '<div class="wr-name">' + esc(c.name) + '</div>' +
            (c.description ? '<div class="wr-sub">' + esc(c.description) + '</div>' : '') +
            (sk.length ? '<div class="wr-sub">brings ' + esc(sk.join(', ')) + ' at level 1</div>' : '') +
            (c.outfit ? '<div class="wr-sub">wears ' + esc(c.outfit) + '</div>' : '') +
          '</div></div>';
      }).join('') +
      '<div class="wr-card" data-cls="">' +
        '<div style="flex:1;min-width:0">' +
          '<div class="wr-name">No class</div>' +
          '<div class="wr-sub">Just you, unbent.</div>' +
        '</div></div>') +
      '</div>' +
      '<div class="field"><button class="btn ghost block sm" data-act="worlds-back">Back to worlds</button></div>';

    on(body, '[data-cls]', 'click', function () {
      App.beginWorld(world.id, lifeId, this.getAttribute('data-cls') || null);
    });
    on(body, '[data-act=worlds-back]', 'click', function () { App.go('worlds'); });
  };

  global.Views = Views;
})(window);
