/* Screen rendering */
(function (global) {
  'use strict';

  var esc = UI.esc, md = UI.md, icon = UI.icon;

  function $(sel, root) { return (root || document).querySelector(sel); }
  function on(root, sel, ev, fn) {
    (root.querySelectorAll ? root.querySelectorAll(sel) : []).forEach(function (el) {
      if (el) el.addEventListener(ev, fn);   /* test stubs may lack the element */
    });
  }
  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase();
  }
  function avatarHtml(src, name, cls) {
    if (src) return '<img src="' + esc(src) + '" alt="" class="' + (cls || '') + '">';
    return '<div class="ph" style="width:100%;height:100%;display:grid;place-items:center;font-size:12px;color:var(--dim)">' +
      esc(initials(name)) + '</div>';
  }
  /* v1.31.0: the active persona's photo, if it has one. Personas carry
     their avatar on the persona record; the default identity (no persona
     selected) and a persona without a photo keep initials. */
  function activePersonaAvatar(s) {
    var id = (s && s.activePersona) || '';
    if (!id) return '';
    var p = (Store.personas || []).find(function (x) { return x.id === id; });
    return (p && p.avatar) || '';
  }
  function pickFile(accept) {
    return new Promise(function (resolve) {
      var inp = document.createElement('input');
      inp.type = 'file'; inp.accept = accept;
      inp.onchange = function () { resolve(inp.files && inp.files[0]); };
      inp.click();
    });
  }
  function fileToDataUrl(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
  }

  /* 18.2.0: newly imported images arrive normalized — downscaled to at most
     maxDim px and re-encoded (PNG only when the picture actually has
     transparency, JPEG 0.85 otherwise). A 12 MP phone photo must not become
     several MB of base64 sitting in IndexedDB. The math helpers are pure
     and unit-tested; the canvas glue falls back to the raw data URL if any
     step throws. */
  function imageTargetSize(w, h, maxDim) {
    maxDim = maxDim || 512;
    var scale = Math.min(1, maxDim / Math.max(w || 1, h || 1));
    return {
      w: Math.max(1, Math.round((w || 1) * scale)),
      h: Math.max(1, Math.round((h || 1) * scale))
    };
  }
  function imageMime(hasAlpha) { return hasAlpha ? 'image/png' : 'image/jpeg'; }

  function normalizeImage(file, maxDim) {
    return new Promise(function (resolve) {
      function fallback() { fileToDataUrl(file).then(resolve, resolve); }
      try {
        if (!file || !file.size || file.size < 40 * 1024) return fallback(); /* already tiny */
        var url = null;
        try { if (typeof URL !== 'undefined' && URL.createObjectURL) url = URL.createObjectURL(file); } catch (e) { /* ignore */ }
        if (!url) return fallback();
        var img = new Image();
        img.onerror = function () { try { URL.revokeObjectURL(url); } catch (e) {} fallback(); };
        img.onload = function () {
          try {
            var t = imageTargetSize(img.naturalWidth || img.width, img.naturalHeight || img.height, maxDim);
            var canvas = document.createElement('canvas');
            canvas.width = t.w; canvas.height = t.h;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, t.w, t.h);
            var hasAlpha = false;
            try {
              var data = ctx.getImageData(0, 0, t.w, t.h).data;
              for (var i = 3; i < data.length; i += 64) if (data[i] < 255) { hasAlpha = true; break; }
            } catch (e) { hasAlpha = true; } /* unknown → keep it lossless */
            resolve(canvas.toDataURL(imageMime(hasAlpha), 0.85));
          } catch (e2) { fallback(); }
          try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ }
        };
        img.src = url;
      } catch (e) { fallback(); }
    });
  }

  /* Card import runs the same normalization on the avatar the card carries
     (a data: URI, not a File). Anything that is not an image data URI —
     web URLs, unknown types — passes through unchanged, and so does a
     decode failure: the <img> shows those as well as the re-encoded
     result, and the card's original bytes are never lost. */
  function normalizeDataUrl(dataUrl, maxDim) {
    return new Promise(function (resolve) {
      function fallback() { resolve(dataUrl || ''); }
      try {
        if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image') !== 0) return fallback();
        var img = new Image();
        img.onerror = function () { fallback(); };
        img.onload = function () {
          try {
            var w = img.naturalWidth || img.width || 0, h = img.naturalHeight || img.height || 0;
            if (!w || !h) return fallback();
            var t = imageTargetSize(w, h, maxDim);
            if (t.w === w && t.h === h) return fallback(); /* already at or under the cap */
            var canvas = document.createElement('canvas');
            canvas.width = t.w; canvas.height = t.h;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, t.w, t.h);
            var hasAlpha = false;
            try {
              var data = ctx.getImageData(0, 0, t.w, t.h).data;
              for (var i = 3; i < data.length; i += 64) if (data[i] < 255) { hasAlpha = true; break; }
            } catch (e) { hasAlpha = true; } /* unknown → keep it lossless */
            resolve(canvas.toDataURL(imageMime(hasAlpha), 0.85));
          } catch (e2) { fallback(); }
        };
        img.src = dataUrl;
      } catch (e) { fallback(); }
    });
  }

  /* v1.29.0: the card's pictures besides the avatar get the same storage
     diet as the avatar — data-URLs down to a 512px long edge, web URLs
     (and anything undecodable) pass through untouched. Resolves with the
     (mutated) list, so the caller keeps one reference. */
  function normalizeCardImages(images) {
    var list = images || [];
    return Promise.all(list.map(function (im) {
      if (typeof im.src === 'string' && im.src.indexOf('data:image') === 0) {
        return normalizeDataUrl(im.src, 512).then(function (s) {
          if (s) im.src = s;
          return im;
        });
      }
      return Promise.resolve(im);
    }));
  }

  var Views = {};

  /* ================= PERSONA SWITCHER ================= */
  /* One-tap identity switching, shown on the Cast and Chats screens.
     Editing lives in Settings — the bar answers only "who am I right now?".
     Hidden entirely until you have created at least one persona, so nothing
     changes for anyone who never touches it. Every .persona-bar element in
     the document is filled from one place, so both screens stay in step. */
  function renderPersonaBar() {
    var bars = document.querySelectorAll('.persona-bar');
    if (!bars.length) return;
    var list = Store.personas || [];
    var active = (Store.settings && Store.settings.activePersona) || '';

    var defName = (Store.settings && Store.settings.defaultName) || 'You';
    var html =
      '<span class="persona-lbl">You are</span>' +
      '<button class="pchip' + (active ? '' : ' on') + '" data-persona="">' +
        icon('user') + esc(defName) + '</button>' +
      list.map(function (p) {
        /* v1.31.0: a persona with a photo shows its face in the chip. */
        var face = p.avatar
          ? '<img class="pchip-av" src="' + esc(p.avatar) + '" alt="">'
          : icon('user');
        return '<button class="pchip' + (active === p.id ? ' on' : '') + '" data-persona="' +
          esc(p.id) + '">' + face + esc(p.name || 'Unnamed') + '</button>';
      }).join('') +
      '<button class="pchip add" data-persona-new="1">' + icon('plus') + 'New</button>';

    bars.forEach(function (bar) {
      bar.hidden = list.length === 0;
      if (bar.hidden) { bar.innerHTML = ''; return; }
      bar.innerHTML = html;
      on(bar, '.pchip', 'click', function (e) {
        var el = e.currentTarget;
        if (el.getAttribute('data-persona-new')) return App.newPersona();
        App.switchTo(el.getAttribute('data-persona') || '');
      });
    });
  }
  Views.renderPersonaBar = function () { renderPersonaBar(); };

  /* ================= CAST ================= */
  Views.characters = function (root) {
    var q = (App.state.query || '').toLowerCase();
    var tag = App.state.tag || '';
    var list = Store.characters.filter(function (c) {
      var okQ = !q || (c.name || '').toLowerCase().indexOf(q) !== -1 ||
        (c.tagline || '').toLowerCase().indexOf(q) !== -1 ||
        (c.tags || []).join(' ').toLowerCase().indexOf(q) !== -1;
      var okT = !tag || (c.tags || []).indexOf(tag) !== -1;
      return okQ && okT;
    });

    var tags = {};
    Store.characters.forEach(function (c) { (c.tags || []).forEach(function (t) { tags[t] = (tags[t] || 0) + 1; }); });
    var tagNames = Object.keys(tags).sort(function (a, b) { return tags[b] - tags[a]; }).slice(0, 14);

    $('#tag-bar').innerHTML = tagNames.length
      ? '<button class="tag' + (tag ? '' : ' on') + '" data-tag="">All</button>' +
        tagNames.map(function (t) {
          return '<button class="tag' + (tag === t ? ' on' : '') + '" data-tag="' + esc(t) + '">' + esc(t) + '</button>';
        }).join('')
      : '';
    $('#tag-bar').hidden = !tagNames.length;
    on($('#tag-bar'), '.tag', 'click', function (e) {
      App.state.tag = e.currentTarget.getAttribute('data-tag');
      Views.characters(root);
    });

    renderPersonaBar();

    var grid = $('#char-grid');
    var empty = $('#char-empty');
    empty.hidden = Store.characters.length > 0;
    grid.hidden = list.length === 0;

    grid.innerHTML = list.map(function (c) {
      return '<div class="card" data-id="' + c.id + '">' +
        '<div class="card-art">' +
          (c.avatar ? '<img src="' + esc(c.avatar) + '" alt="">' :
            '<div class="ph">' + icon('user') + '</div>') +
          ((c.vh && c.vh.enabled)
            ? '<span class="badge-vh"><svg viewBox="0 0 24 24" style="width:10px;height:10px;stroke:currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg> living</span>'
            : '') +
          '<button class="card-menu" data-menu="' + c.id + '" aria-label="Options">' +
            '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>' +
          '</button>' +
        '</div>' +
        '<div class="card-body">' +
          '<div class="card-name">' + esc(c.name || 'Unnamed') + '</div>' +
          '<div class="card-sub">' + esc(c.tagline || (c.persona || '').slice(0, 90)) + '</div>' +
          ((c.tags && c.tags.length) ? '<div class="card-tags">' +
            c.tags.slice(0, 3).map(function (t) { return '<span class="mini-tag">' + esc(t) + '</span>'; }).join('') +
            '</div>' : '') +
        '</div>' +
      '</div>';
    }).join('');

    on(grid, '.card', 'click', function (e) {
      if (e.target.closest('[data-menu]')) return;
      App.openCharacter(e.currentTarget.getAttribute('data-id'));
    });
    on(grid, '[data-menu]', 'click', function (e) {
      e.stopPropagation();
      App.characterMenu(e.currentTarget.getAttribute('data-menu'));
    });
    on(empty, '[data-act=new-char]', 'click', function () { App.editCharacter(null); });
    on(empty, '[data-act=import-card]', 'click', App.importCard);
  };

  /* ================= LIFE (virtual humans) ================= */
  function needBar(label, text, value) {
    var pct = Math.round(Math.max(0, Math.min(1, value || 0)) * 100);
    return '<div class="meter"><span>' + esc(label) + '</span><b>' + esc(text) + '</b>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div></div>';
  }
  function signedBar(label, text, value) {
    var pct = Math.round((Math.max(-1, Math.min(1, value || 0)) + 1) / 2 * 100);
    return '<div class="meter"><span>' + esc(label) + '</span><b>' + esc(text) + '</b>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div></div>';
  }

  Views.life = function (root) {
    var body = $('#now-body');
    var all = Store.characters;
    if (!all.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>No one lives here yet</h3><p>Virtual humans are built on top of characters — create one first.</p>' +
        '<button class="btn primary" data-act="new">Create character</button>' +
        '<button class="btn ghost" data-act="import">Import a portable human</button></div>';
      on(body, '[data-act=new]', 'click', function () { App.editCharacter(null); });
      on(body, '[data-act=import]', 'click', App.importHuman);
      return;
    }
    var vhs = all.filter(function (c) { return c.vh && c.vh.enabled; });
    if (!vhs.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>No virtual humans yet</h3>' +
        '<p>Turn a character into a virtual human and they get a life of their own: places they go, ' +
        'needs that build up, other people, a diary, hours where they sleep instead of answering, ' +
        'and the habit of messaging you first.</p>' +
        '<button class="btn primary" data-act="pick">Choose a character</button>' +
        '<button class="btn ghost" data-act="import">Import a portable human</button></div>';
      on(body, '[data-act=pick]', 'click', App.pickVirtualHuman);
      on(body, '[data-act=import]', 'click', App.importHuman);
      return;
    }

    body.innerHTML = '<div class="hint" style="margin:0 2px 10px">Their day advances on real time — ' +
      'open the app after a few hours away and you may find messages waiting.</div>' +
      vhs.map(function (c) { return lifeCard(c); }).join('') +
      '<button class="btn ghost block sm" data-act="pick" style="margin-top:4px">' + icon('plus') + ' Make another character a virtual human</button>' +
      '<button class="btn ghost block sm" data-act="import" style="margin-top:6px">Import a portable human</button>';

    on(body, '[data-act=pick]', 'click', App.pickVirtualHuman);
    on(body, '[data-act=import]', 'click', App.importHuman);
    on(body, '[data-a]', 'click', function (e) {
      var id = e.currentTarget.closest('[data-vh]').getAttribute('data-vh');
      var a = e.currentTarget.getAttribute('data-a');
      Promise.resolve(Store.getCharacter(id)).then(function (c) {
        if (a === 'chat') App.openLatestOrNew(c.id);
        else if (a === 'nudge') App.nudge(c);
        else if (a === 'life') App.openLife(c);
        else if (a === 'feed') { App.state.feedFor = c.id; App.go('feed'); }
      });
    });
  };
  Views.now = Views.life;

  function lifeCard(c) {
    var L = VH.life(c);
    var st = L.summary, vh = c.vh, where = L.where;
    var last = L.bond.lastContact ? UI.fmtTime(L.bond.lastContact) : 'never';
    var ev = L.calendar.now || L.calendar.next;
    return '<div class="vh-card" data-vh="' + c.id + '">' +
      '<div class="vh-top">' +
        '<div class="vh-av">' + (c.avatar
          ? '<img src="' + esc(c.avatar) + '" alt="">'
          : '<div class="ph">' + esc(initials(c.name)) + '</div>') + '</div>' +
        '<div style="flex:1;min-width:0">' +
          '<div class="vh-name">' + esc(c.name) + '</div>' +
          '<div class="vh-status">' + esc(st.asleep ? 'Asleep' : (st.activity || 'Awake')) +
            (st.asleep ? ' · back around ' + esc(vh.sleep.end) : '') + '</div>' +
          '<div class="vh-when">' + esc(where.name) +
            (where.travelling ? ' · ' + where.minutesLeft + ' min away' : '') +
            ' · you last spoke ' + esc(last) + '</div>' +
        '</div>' +
      '</div>' +
      (ev ? '<div class="vh-note">' + icon('time') + ' <b>' + esc(ev.t) + '</b> ' + esc(ev.label) +
        (ev.placeId ? ' · ' + esc(VH.placeName(vh, ev.placeId)) : '') + '</div>' : '') +
      '<div class="meters">' +
        signedBar('Mood', st.moodLabel, st.mood) +
        signedBar('You two', L.bond.label + ' · ' + L.bond.persona, L.bond.affinity) +
        needBar('Energy', L.needs[0].label, L.needs[0].value) +
        needBar('Company', L.needs[2].label, L.needs[2].value) +
      '</div>' +
      '<div class="vh-note">Autonomous today: <b>' + L.spend.used + ' / ' + L.spend.cap + '</b>' +
        (L.spend.left ? '' : ' · budget spent, they will not message on their own until tomorrow') + '</div>' +
      (st.chronicle.length
        ? '<div class="chron">' + st.chronicle.slice(0, 3).map(function (b) {
            return '<div><b>' + esc(UI.fmtTime(b.ts)) + '</b> — ' + esc(b.text) + '</div>';
          }).join('') + '</div>'
        : '') +
      '<div class="vh-acts">' +
        '<button class="btn sm" data-a="chat">Open chat</button>' +
        '<button class="btn sm ghost" data-a="life">Their life</button>' +
        '<button class="btn sm ghost" data-a="feed">Feed</button>' +
        '<button class="btn sm ghost" data-a="nudge">Nudge</button>' +
      '</div>' +
    '</div>';
  }

  /* ---------------- the full life, in a sheet ---------------- */
  Views.lifeSheet = function (c) {
    var vh = VH.ensure(c), L = VH.life(c);
    var where = L.where;

    var people = L.people.length
      ? L.people.map(function (p) {
          return '<div class="person"><div class="person-av">' + esc((p.name || '?').slice(0, 1).toUpperCase()) + '</div>' +
            '<div style="flex:1;min-width:0"><div>' + esc(p.name) + '</div>' +
            '<div class="hint">' + esc(p.relation || 'person') + (p.note ? ' · ' + esc(p.note) : '') + '</div></div>' +
            '<span class="pill">' + esc(VH.relLabel((p.closeness || 0) * 2 - 1)) + '</span></div>';
        }).join('')
      : '<div class="hint">Nobody yet — add the people in their life from the character editor.</div>';

    var today = L.calendar.today.length
      ? L.calendar.today.map(function (e) {
          return '<div class="ev"><b>' + esc(e.t) + '</b> ' + esc(e.label) +
            (e.placeId ? ' · ' + esc(VH.placeName(vh, e.placeId)) : '') + '</div>';
        }).join('')
      : '<div class="hint">Nothing in the diary today.</div>';

    var perms = [
      ['message', 'Messages on their own'],
      ['photo', 'Photos on their own'],
      ['post', 'Posts to their feed'],
      ['travel', 'Going out and about']
    ].map(function (p) {
      return '<div class="field compact"><label>' + p[1] + '</label>' +
        '<div class="toggle' + (L.perms[p[0]] ? ' on' : '') + '" data-perm="' + p[0] + '"></div></div>';
    }).join('');

    return '' +
      '<div class="life-head">' +
        '<div class="life-where">' + esc(where.name) + '</div>' +
        '<div class="hint">' + esc(L.summary.activity || '') +
          (where.travelling ? ' · arriving in ' + where.minutesLeft + ' min' : '') + '</div>' +
      '</div>' +
      '<div class="group-title">Needs</div>' +
      '<div class="meters">' + L.needs.map(function (n) {
        return needBar(n.key[0].toUpperCase() + n.key.slice(1), n.label, n.value);
      }).join('') + '</div>' +
      '<div class="group-title">You two</div>' +
      '<div class="meters">' +
        signedBar('Relationship', L.bond.label, L.bond.affinity) +
        signedBar('Trust', L.bond.trust.toFixed(2), L.bond.trust) +
        signedBar('Tension', L.bond.tension.toFixed(2), L.bond.tension) +
      '</div>' +
      '<div class="hint">' + L.bond.exchanges + ' exchanges with ' + esc(L.bond.persona) + '.' +
        (L.personas.length > 1 ? ' They know ' + (L.personas.length - 1) + ' other persona(s) separately.' : '') + '</div>' +
      '<div class="group-title">People</div>' + people +
      '<div class="group-title">Today</div>' + today +
      '<div class="group-title">Autonomy</div>' + perms +
      '<div class="field"><div class="field-head"><label>Daily budget for autonomous messages</label>' +
        '<span class="spacer"></span><span class="val" id="cap-v">' + L.spend.cap + '</span></div>' +
        '<div class="range-row"><input type="range" id="vh-cap" min="0" max="40" step="1" value="' + L.spend.cap + '">' +
        '<span class="hint">' + L.spend.used + ' used today</span></div>' +
        '<div class="hint">Counts messages, photos and posts they send on their own. Your own replies and nudges are free.</div></div>' +
      '<div class="vh-acts">' +
        '<button class="btn sm ghost" data-l="export">Export life</button>' +
        '<button class="btn sm ghost" data-l="feed">Open feed</button>' +
      '</div>';
  };

  /* ================= FEED ================= */
  Views.feed = function (root) {
    var body = $('#feed-body');
    var vhs = Store.characters.filter(function (c) { return c.vh && c.vh.enabled; });
    var only = App.state.feedFor;
    if (only) vhs = vhs.filter(function (c) { return c.id === only; });

    var posts = [];
    vhs.forEach(function (c) {
      (c.vh.feed || []).forEach(function (p) { posts.push({ post: p, char: c }); });
    });
    posts.sort(function (a, b) { return (b.post.ts || 0) - (a.post.ts || 0); });

    if (!posts.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('time') + '</div>' +
        '<h3>Nothing posted yet</h3><p>When a virtual human sends you a photo or says something on ' +
        'their own, it shows up here — a record of the life outside your chat.</p>' +
        '<button class="btn ghost" data-act="life">Back to Life</button></div>';
      on(body, '[data-act=life]', 'click', function () { App.state.feedFor = null; App.go('life'); });
      return;
    }

    body.innerHTML = (only
        ? '<button class="btn ghost block sm" data-act="all" style="margin:0 2px 10px">Everyone’s feed</button>'
        : '') +
      posts.map(function (e) {
        var p = e.post, c = e.char;
        return '<div class="post" data-c="' + c.id + '">' +
          '<div class="post-head">' +
            '<div class="post-av">' + (c.avatar ? '<img src="' + esc(c.avatar) + '" alt="">' : esc(initials(c.name))) + '</div>' +
            '<div style="flex:1;min-width:0"><b>' + esc(c.name) + '</b>' +
            '<div class="hint">' + esc(UI.fmtTime(p.ts)) +
              (p.placeId ? ' · ' + esc(VH.placeName(c.vh, p.placeId)) : '') +
              (p.autonomous ? ' · sent on their own' : '') + '</div></div>' +
          '</div>' +
          (p.image ? '<img class="post-img" src="' + esc(p.image) + '" alt="">' : '') +
          (p.text ? '<div class="post-text">' + esc(p.text) + '</div>' : '') +
        '</div>';
      }).join('');

    on(body, '[data-act=all]', 'click', function () { App.state.feedFor = null; Views.feed($('.screen')); });
  };

  /* ================= CHATS ================= */
  Views.chats = function (root) {
    renderPersonaBar();
    var list = $('#chat-list'), empty = $('#chats-empty');
    Store.allSessions().then(function (all) {
      var chars = {};
      Store.characters.forEach(function (c) { chars[c.id] = c; });
      /* v1.39.0 chatwork: find-pin-archive. Hidden counts (search rows,
         archived piles) stay readable; nothing is ever deleted here. */
      var q = (App.state.chatSearch || '').trim().toLowerCase();
      var words = q ? q.split(/\s+/).filter(Boolean) : [];
      function matches(s) {
        if (!words.length) return true;
        var c = chars[s.charId] || { name: '' };
        var hay = ((c.name || '') + ' ' + (s.title || '') + ' ' + (s.summary || '')).toLowerCase();
        return words.every(function (w) { return hay.indexOf(w) !== -1; });
      }
      var archived = all.filter(function (s) { return s.archived; }).length;
      var sessions = all.filter(function (s) {
        return (App.state.showArchived || !s.archived) && matches(s);
      });
      /* pins ride first, newest first inside each pile (allSessions already
         sorts by updatedAt; Array.sort is stable in modern engines) */
      sessions = sessions.slice().sort(function (a, b) {
        return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0);
      });
      var searchEl = $('#chat-search');
      if (searchEl && searchEl.value !== (App.state.chatSearch || '')) {
        searchEl.value = App.state.chatSearch || '';
      }
      list.innerHTML = sessions.map(function (s) {
        var c = chars[s.charId] || { name: 'Deleted character' };
        return '<div class="item" data-open="' + s.id + '">' +
          '<div class="item-av">' + avatarHtml(c.avatar, c.name) + '</div>' +
          '<div class="item-main">' +
            '<div class="item-title">' + esc(c.name) + ' <span style="color:var(--dim);font-weight:400">· ' + esc(s.title || 'New chat') + '</span>' +
              (s.pinned ? '<span class="item-badge">pinned</span>' : '') +
              (s.archived ? '<span class="item-badge">archived</span>' : '') +
            '</div>' +
            '<div class="item-sub">' + esc(s.summary ? s.summary.slice(0, 90) : (s.messageCount || 0) + ' messages') + '</div>' +
          '</div>' +
          '<div class="item-side">' + esc(UI.fmtTime(s.updatedAt)) +
            '<button class="chip" style="margin-left:6px" data-menu="' + s.id + '">' +
              '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>' +
            '</button>' +
          '</div>' +
        '</div>';
      }).join('') +
      (archived && !App.state.showArchived
        ? '<div class="field"><button class="btn ghost block sm" data-act="show-archived">Show archived (' + archived + ')</button></div>'
        : (App.state.showArchived && archived ? '<div class="field"><button class="btn ghost block sm" data-act="hide-archived">Hide archived</button></div>' : '')) +
      (!sessions.length && archived && !App.state.showArchived ? '' :
        (!sessions.length && (q || all.length)
          ? '<div class="field"><span class="hint">' + (q ? 'No chats match \"' + esc(q) + '\" as ' + esc(Store.personaLabel()) + '.' : '') + '</span></div>'
          : ''));
      empty.hidden = sessions.length > 0;
      if (!empty.hidden) {
        /* An empty list is usually not data loss: every persona keeps its
           own chats. If another identity has conversations, say so. */
        Store.sessionTotal().then(function (total) {
          if (total > 0 && !empty.hidden) {
            var h3 = empty.querySelector('h3'), p = empty.querySelector('p');
            if (h3) h3.textContent = 'No conversations as ' + Store.personaLabel();
            if (p) p.textContent = 'Nothing was lost — your other conversations live under a different identity. Switch to it with the bar above.';
          }
        });
      }
      on(list, '[data-act=show-archived]', 'click', function () {
        App.state.showArchived = true; Views.chats(root);
      });
      on(list, '[data-act=hide-archived]', 'click', function () {
        App.state.showArchived = false; Views.chats(root);
      });
      on(list, '[data-open]', 'click', function (e) {
        if (e.target.closest('[data-menu]')) return;
        App.openSession(e.currentTarget.getAttribute('data-open'));
      });
      on(list, '[data-menu]', 'click', function (e) {
        e.stopPropagation();
        App.sessionMenu(e.currentTarget.getAttribute('data-menu'));
      });
    });
  };

  /* ================= WORLD ================= */
  Views.world = function (root) {
    var body = $('#world-body');
    var chars = Store.characters;
    if (!chars.length) {
      body.innerHTML = '<div class="empty"><div class="empty-art">' + icon('brain') + '</div>' +
        '<h3>No world yet</h3><p>Create a character first — worlds and memories hang off them.</p></div>';
      return;
    }
    var id = App.state.worldChar || chars[0].id;
    var c = chars.find(function (x) { return x.id === id; }) || chars[0];
    App.state.worldChar = c.id;

    body.innerHTML =
      '<div class="tag-bar">' + chars.map(function (x) {
        return '<button class="tag' + (x.id === c.id ? ' on' : '') + '" data-wc="' + x.id + '">' + esc(x.name || 'Unnamed') + '</button>';
      }).join('') + '</div>' +

      '<div class="group"><div class="group-title">Lorebook · ' + esc(c.name) + '</div>' +
        '<div id="lore-list">' + (c.lorebook || []).map(function (e, i) {
          return '<div class="kv" data-lore="' + i + '" style="cursor:pointer">' +
            '<span style="flex:1">' +
              '<b style="display:block;color:' + (e.enabled === false ? 'var(--dim)' : 'var(--text)') + '">' +
                esc((e.keys || []).join(', ') || '(no keys)') + '</b>' +
              '<span style="font-size:12px">' + esc((e.content || '').slice(0, 70)) + '</span>' +
            '</span></div>';
        }).join('') + '</div>' +
        '<div class="field"><button class="btn ghost block sm" data-act="lore-add">' + icon('plus') + ' Add lore entry</button></div>' +
      '</div>' +

      '<div class="group"><div class="group-title">Story memory</div>' +
        '<div class="field"><div class="hint" style="margin:0">Memory is stored per conversation. It gets injected into ' +
        'the prompt so long chats stay coherent without sending the whole transcript.</div></div>' +
        '<div id="mem-list"><div class="field"><span class="hint">Loading…</span></div></div>' +
      '</div>';

    on(body, '[data-wc]', 'click', function (e) {
      App.state.worldChar = e.currentTarget.getAttribute('data-wc');
      Views.world(root);
    });
    on(body, '[data-act=lore-add]', 'click', function () { App.editLore(c, null); });
    on($('#lore-list'), '[data-lore]', 'click', function (e) {
      App.editLore(c, parseInt(e.currentTarget.getAttribute('data-lore'), 10));
    });

    Store.getSessions(c.id).then(function (sessions) {
      var el = $('#mem-list');
      if (!sessions.length) {
        el.innerHTML = '<div class="field"><span class="hint">No conversations with this character yet.</span></div>';
        return;
      }
      el.innerHTML = sessions.map(function (s) {
        return '<div class="kv" data-mem="' + s.id + '" style="cursor:pointer">' +
          '<span style="flex:1"><b style="display:block">' + esc(s.title || 'New chat') + '</b>' +
          '<span style="font-size:12px">' + esc(s.summary ? s.summary.slice(0, 80) : 'No summary yet') + '</span></span>' +
          '<span style="color:var(--dim);font-size:11px">' + (s.facts ? s.facts.length : 0) + ' facts</span>' +
        '</div>';
      }).join('');
      on(el, '[data-mem]', 'click', function (e) {
        App.memorySheet(e.currentTarget.getAttribute('data-mem'));
      });
    });
  };

  /* ================= PERSONAS (dedicated management screen, v1.15.0) ===== */
  /* The persona list used to live inline in Settings, where every identity
     made the screen longer. It now has its own screen; Settings keeps a
     fixed-length "Manage personas" button. Rows are shared (personaRowsHtml)
     so the screen and the bar/Settings stay consistent. */
  function personaRowsHtml(personas, activeId) {
    return personas.length
      ? personas.map(function (p) {
          var on = activeId === p.id;
          return '<div class="field" data-prow="' + esc(p.id) + '">' +
            '<div class="field-head">' +
              /* v1.31.0: the persona's own photo - tap to import a picture,
                 the small dot removes it. Initials until one is set. */
              '<span class="pavat-wrap">' +
                '<button class="pavat" data-persona-av="' + esc(p.id) + '" title="Set or change the photo" aria-label="' + esc('Set photo for ' + (p.name || 'persona')) + '">' + avatarHtml(p.avatar || '', p.name) + '</button>' +
                (p.avatar ? '<button class="pavat-x" data-persona-avdel="' + esc(p.id) + '" aria-label="Remove photo">\u00d7</button>' : '') +
              '</span>' +
            '<label>' + esc(p.name || 'Unnamed persona') + '</label>' +
              '<span class="spacer"></span>' +
              (on ? '<span class="pill ok">active</span>'
                  : '<button class="chip" data-persona-use="' + esc(p.id) + '">Switch to</button>') +
              '<button class="chip" data-persona-del="' + esc(p.id) + '" aria-label="Delete persona">' + icon('trash') + '</button>' +
            '</div>' +
            '<input type="text" data-persona-name="' + esc(p.id) + '" value="' + esc(p.name || '') + '" placeholder="Persona name">' +
            '<textarea data-persona-text="' + esc(p.id) + '" style="margin-top:6px" placeholder="Who this persona is — appearance, background, goals.">' + esc(p.text || '') + '</textarea>' +
          '</div>';
        }).join('')
      : '<div class="field"><span class="hint">No personas yet. Add one to switch between identities — each keeps its own chats with every character and its own relationship with each virtual human.</span></div>';
  }

  Views.personas = function (root) {
    var personas = Store.personas || [];
    var activeId = (Store.settings && Store.settings.activePersona) || '';
    var body = $('#personas-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Identities</div>' +
        '<div class="field"><div class="hint" style="margin:0">Each persona keeps its own chats with every character, and its own relationship with each virtual human. Names and descriptions save when you leave the field. The identity bar at the top of Cast and Chats switches personas too.</div></div>' +
        personaRowsHtml(personas, activeId) +
        '<button class="btn ghost sm" id="btn-persona-add" style="margin-top:8px">' + icon('plus') + ' Add persona</button>' +
      '</div>';
    function bind(sel, ev, fn) { var el = $(sel, body); if (el) el.addEventListener(ev, fn); }
    on(body, '[data-persona-use]', 'click', function (e) {
      App.switchTo(e.currentTarget.getAttribute('data-persona-use'));
    });
    on(body, '[data-persona-del]', 'click', function (e) {
      App.deletePersona(e.currentTarget.getAttribute('data-persona-del'));
    });
    on(body, '[data-persona-name]', 'change', function (e) {
      App.editPersona(e.currentTarget.getAttribute('data-persona-name'), { name: e.target.value.trim() });
    });
    on(body, '[data-persona-text]', 'change', function (e) {
      App.editPersona(e.currentTarget.getAttribute('data-persona-text'), { text: e.target.value });
    });
    /* v1.31.0: import a photo for the persona. The picture goes through the
       image normalizer like every imported image, and the row's thumb and
       remove dot update in place instead of re-rendering the screen. */
    function personaById(id) {
      return (Store.personas || []).find(function (x) { return x.id === id; });
    }
    function detachPhoto(xbtn) {
      var id = xbtn.getAttribute('data-persona-avdel');
      App.editPersona(id, { avatar: '' });
      var btn = body.querySelector('[data-persona-av="' + id + '"]');
      var p = personaById(id);
      if (btn) btn.innerHTML = avatarHtml('', p && p.name, '');
      if (xbtn.remove) xbtn.remove();
    }
    on(body, '[data-persona-av]', 'click', function (e) {
      var id = e.currentTarget.getAttribute('data-persona-av');
      pickFile('image/*').then(function (f) {
        if (!f) return;
        normalizeImage(f).then(function (d) {
          if (!d) { UI.toast('Could not read that image'); return; }
          App.editPersona(id, { avatar: d });
          var btn = body.querySelector('[data-persona-av="' + id + '"]');
          if (!btn) return;
          btn.innerHTML = avatarHtml(d, '', '');
          var wrap = btn.parentNode;
          if (wrap && !wrap.querySelector('.pavat-x')) {
            var x = document.createElement('button');
            x.className = 'pavat-x';
            x.setAttribute('data-persona-avdel', id);
            x.setAttribute('aria-label', 'Remove photo');
            x.textContent = '\u00d7';
            x.addEventListener('click', function () { detachPhoto(x); });
            wrap.appendChild(x);
          }
        });
      });
    });
    on(body, '[data-persona-avdel]', 'click', function (e) { detachPhoto(e.currentTarget); });
    bind('#btn-persona-add', 'click', function () { App.newPersona(); });
  };

  /* ================= SETTINGS ================= */
  /* v1.16.0: Settings is a hub. Every group lives on its own sub-screen —
     one shared settings-x section rendered per section — so the hub stays
     the same length no matter what is inside. "About" stays in the hub as
     a footer: it is status, not a setting. The per-persona rows live on
     Views.personas (v1.15.0), reached from the hub too. */
  Views.SETTINGS_SECTIONS = {
    appearance: { title: 'Appearance', hint: 'Theme colors', icon: 'palette', view: 'settingsAppearance' },
    connection: { title: 'Connection', hint: 'Provider, API key, model', icon: 'key', view: 'settingsConnection' },
    generation: { title: 'Generation', hint: 'Temperature, reply length, context', icon: 'sparkle', view: 'settingsGeneration' },
    you:        { title: 'You', hint: 'Your name and identity', icon: 'user', view: 'settingsYou' },
    system:     { title: 'System prompt', hint: 'Rules sent with every message', icon: 'chat', view: 'settingsSystem' },
    horde:      { title: 'AI Horde · images &amp; free text', hint: 'Free key, image model, queue', icon: 'image', view: 'settingsHorde' },
    memory:     { title: 'Memory', hint: 'Auto-summarise long chats', icon: 'brain', view: 'settingsMemory' },
    data:       { title: 'Data', hint: 'Backup, restore, erase', icon: 'download', view: 'settingsData' },
    storage:    { title: 'Storage', hint: 'What the app is holding', icon: 'copy', view: 'settingsStorage' },
    update:     { title: 'App updates', hint: 'Version, update address', icon: 'refresh', view: 'settingsUpdate' }
  };

  /* Control wiring shared by the settings sub-screens. Everything is scoped
     to the sub-screen's body, so control ids can never collide. */
  function settingsScope(body) {
    function bind(sel, ev, fn) { var el = $(sel, body); if (el) el.addEventListener(ev, fn); }
    function set(patch) { Store.saveSettings(patch); }
    function range(sel, valSel, key, fmt) {
      var el = $(sel, body);
      if (!el) return;
      el.addEventListener('input', function () {
        var v = parseFloat(el.value);
        if (valSel) $(valSel, body).textContent = fmt ? fmt(v) : v;
        var patch = {}; patch[key] = v; set(patch);
      });
    }
    function toggle(sel, key, after) {
      var el = $(sel, body);
      if (!el) return;
      el.addEventListener('click', function () {
        var patch = {}; patch[key] = !Store.settings[key]; set(patch);
        el.classList.toggle('on', Store.settings[key]);
        if (after) after();
      });
    }
    return { bind: bind, set: set, range: range, toggle: toggle };
  }

  /* Version / update-channel facts shared by the hub (About) and the
     App-updates screen. */
  function settingsUpdateInfo() {
    var U = global.Updates;
    var upInfo = (U && U.supported()) ? U.info() : { apk: '?', apkCode: 0, overlay: false, rev: '' };
    var upUrl = U ? (U.baseUrl() || U.DEFAULT_URL || '') : '';
    var verLabel = (upInfo.apk && upInfo.apk !== '?') ? upInfo.apk : (Store.VERSION || 'unknown');
    if (upInfo.overlay && upInfo.rev) verLabel += ' · files ' + upInfo.rev;
    var upNote = '';
    try {
      var blocked = localStorage.getItem('hs.blockedRev');
      if (blocked) upNote += 'The last update was rolled back automatically because the app never started on it. ';
    } catch (e) { }
    if (!U || !U.supported()) {
      upNote += 'Self-updating needs the newest APK installed once — after that this screen does the rest.';
    } else {
      upNote += 'Nothing is downloaded unless you press Check for update.';
    }
    return { U: U, upInfo: upInfo, upUrl: upUrl, verLabel: verLabel, upNote: upNote };
  }

  /* The hub: one row per section, plus About. Fixed length (v1.16.0). */
  Views.settings = function (root) {
    var s = Store.settings;
    var info = settingsUpdateInfo();
    var personas = Store.personas || [];
    /* v1.26.1: 'appearance' was registered in SETTINGS_SECTIONS but missed
       from this ORDER list, so the hub never drew its row. */
    var ORDER = ['appearance', 'connection', 'generation', 'you', 'personas', 'system', 'horde', 'memory', 'data', 'storage', 'update'];
    var rows = ORDER.map(function (k) {
      var label, hint, ic;
      if (k === 'personas') {
        label = 'Manage personas' + (personas.length ? ' · ' + personas.length : '');
        hint = 'Switchable identities — each keeps its own chats';
        ic = 'user';
      } else {
        var m = Views.SETTINGS_SECTIONS[k];
        label = m.title; hint = m.hint; ic = m.icon;
      }
      return '<div class="field">' +
        '<button class="btn ghost sm block" data-gosec="' + k + '" style="display:flex;align-items:center;gap:10px">' +
          icon(ic) +
          '<span style="flex:1;text-align:left"><b>' + label + '</b>' +
          '<span class="hint" style="display:block">' + hint + '</span></span>' +
          '<span style="color:var(--dim);font-size:18px;line-height:1">›</span>' +
        '</button></div>';
    }).join('');
    $('#settings-body').innerHTML =
      '<div class="group">' +
        '<div class="group-title">Settings</div>' +
        rows +
      '</div>' +
      /* --- about (status, not a setting — stays in the hub) --- */
      '<div class="group">' +
        '<div class="group-title">About</div>' +
        '<div class="field"><div class="kv"><span>Version</span><b>' + esc(info.verLabel) + ' · mobile</b></div>' +
        '<div class="kv"><span>Text</span><b>' + esc(s.provider === 'horde' ? 'AI Horde (free)' : (Store.PRESETS[s.provider] || {}).label || 'Custom') + '</b></div>' +
        '<div class="kv"><span>Images</span><b>AI Horde</b></div>' +
        '<div class="hint">Horde Studio Mobile is an unofficial, mobile-first client. It talks to whatever backend you configure — ' +
        'nothing is sent anywhere except your chosen provider.</div></div>' +
      '</div>';
    var body = $('#settings-body');
    on(body, '[data-gosec]', 'click', function (e) {
      var k = e.currentTarget.getAttribute('data-gosec');
      if (k === 'personas') return App.go('personas');
      App.openSettings(k);
    });
  };

  /* ---- Connection ---- */
  Views.settingsConnection = function (root) {
    var s = Store.settings;
    var preset = Store.PRESETS[s.provider] || Store.PRESETS.custom;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Connection</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Provider</label></div>' +
          '<select id="set-provider">' +
            Object.keys(Store.PRESETS).map(function (k) {
              return '<option value="' + k + '"' + (k === s.provider ? ' selected' : '') + '>' +
                esc(Store.PRESETS[k].label) + '</option>';
            }).join('') +
          '</select>' +
          '<div class="hint" id="preset-note">' + esc(preset.note) + '</div>' +
        '</div>' +
        '<div class="field" id="url-field"' + (s.provider === 'horde' ? ' hidden' : '') + '>' +
          '<div class="field-head"><label>API base URL</label></div>' +
          '<input type="url" id="set-url" value="' + esc(s.baseUrl) + '" placeholder="https://…/v1" autocapitalize="off" autocorrect="off" spellcheck="false">' +
        '</div>' +
        '<div class="field"' + (s.provider === 'horde' ? ' hidden' : '') + '>' +
          '<div class="field-head"><label>API key</label></div>' +
          '<input type="password" id="set-key" value="' + esc(s.apiKey) + '" placeholder="' +
            (preset.keyRequired ? 'sk-…' : 'leave blank if not needed') + '" autocapitalize="off" autocorrect="off" spellcheck="false">' +
          '<div class="hint">Stored only in this app’s private storage on your phone. Never included in exports.</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Model</label></div>' +
          '<div class="row">' +
            '<button class="btn ghost sm" id="btn-model" style="flex:1;text-align:left">' + esc(s.model || 'Tap to choose a model') + '</button>' +
            '<button class="btn ghost sm" id="btn-refresh-models" title="Refresh list">' + icon('refresh') + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="row">' +
            '<button class="btn ghost sm" style="flex:1" id="btn-test">' + icon('key') + ' Test connection</button>' +
          '</div>' +
          '<div class="hint" id="test-out"></div>' +
        '</div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#set-provider', 'change', function (e) {
      var p = e.target.value;
      sc.set({ provider: p, baseUrl: Store.PRESETS[p].url });
      Views.settingsConnection(root);
    });
    sc.bind('#set-url', 'change', function (e) { sc.set({ baseUrl: e.target.value.trim() }); });
    sc.bind('#set-key', 'change', function (e) { sc.set({ apiKey: e.target.value.trim() }); });
    sc.bind('#btn-test', 'click', function () {
      var out = $('#test-out', body);
      out.innerHTML = '<span class="pill">Testing…</span>';
      API.testConnection(Store.settings).then(function (r) {
        out.innerHTML = '<span class="pill ' + (r.ok ? 'ok' : 'err') + '">' + esc(r.message) + '</span>';
      });
    });
    sc.bind('#btn-refresh-models', 'click', function () { App.chooseModel(true); });
    sc.bind('#btn-model', 'click', function () { App.chooseModel(false); });
  };

  /* ---- Generation ---- */
  Views.settingsGeneration = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Generation</div>' +
        '<div class="field"><div class="field-head"><label>Temperature</label><span class="spacer"></span><span class="val" id="v-temp">' + s.temperature + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-temp" min="0" max="2" step="0.05" value="' + s.temperature + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Max reply length</label><span class="spacer"></span><span class="val" id="v-max">' + s.maxTokens + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-max" min="64" max="2048" step="32" value="' + s.maxTokens + '"><span class="hint">tokens</span></div></div>' +
        '<div class="field"><div class="field-head"><label>Top P</label><span class="spacer"></span><span class="val" id="v-topp">' + s.topP + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-topp" min="0.1" max="1" step="0.05" value="' + s.topP + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Messages in context</label><span class="spacer"></span><span class="val" id="v-ctx">' + s.contextMessages + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-ctx" min="6" max="120" step="2" value="' + s.contextMessages + '"></div>' +
          '<div class="hint">Higher = longer memory per request, but slower and more expensive.</div></div>' +
        '<div class="field compact"><label>Stream replies</label><div class="toggle' + (s.streaming ? ' on' : '') + '" id="t-stream"></div></div>' +
        '<div class="field compact"><label>Finish cut-off replies</label><div class="toggle' + (s.autoFinish ? ' on' : '') + '" id="t-finish"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">If a reply stops mid-sentence (common on the Horde, which ' +
          'cuts at its token limit), the app asks for the rest and stitches it together — up to 3 passes.</div></div>' +
        '<div class="field compact"><label>Strip the model\'s thinking</label><div class="toggle' + (s.stripThinking !== false ? ' on' : '') + '" id="t-think"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">Some models plan out loud before they answer. ' +
          'When that planning is recognisable it is removed, so you only see what the character says.</div></div>' +
        '<div class="field compact"><label>Split replies into separate texts</label><div class="toggle' + (s.bursts !== false ? ' on' : '') + '" id="t-bursts"></div></div>' +
        '<div class="field"><div class="hint" style="margin:0">For virtual humans: when a reply reads like several short ' +
          'messages rather than one paragraph, it arrives as separate bubbles a few seconds apart.</div></div>' +
        '<div class="field compact"><label>Enter sends message</label><div class="toggle' + (s.sendOnEnter ? ' on' : '') + '" id="t-enter"></div></div>' +
        '<div class="field"><button class="btn danger" id="gen-reset" style="width:100%">Reset to defaults</button>' +
          '<div class="hint" style="margin:6px 0 0">Puts every slider and toggle above back to its factory value. ' +
          'Provider, API key, model and personas are NOT touched.</div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.range('#set-temp', '#v-temp', 'temperature', function (v) { return v.toFixed(2); });
    sc.range('#set-max', '#v-max', 'maxTokens');
    sc.range('#set-topp', '#v-topp', 'topP', function (v) { return v.toFixed(2); });
    sc.range('#set-ctx', '#v-ctx', 'contextMessages');
    sc.toggle('#t-stream', 'streaming');
    sc.toggle('#t-finish', 'autoFinish');
    sc.toggle('#t-bursts', 'bursts');
    sc.toggle('#t-think', 'stripThinking');
    sc.toggle('#t-enter', 'sendOnEnter');
    var gr = $('#gen-reset');
    if (gr) gr.onclick = function () { App.resetGenerationSettings(); };
  };

  /* ---- You ---- */
  Views.settingsYou = function (root) {
    var s = Store.settings;
    var activeId = s.activePersona || '';
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">You</div>' +
        '<div class="field"><div class="hint" style="margin:0 0 6px">' +
          (activeId
            ? 'Editing the <b>' + esc(Store.personaLabel()) + '</b> persona. These two fields always follow whichever identity is active.'
            : 'Your default identity — used whenever no persona is selected.') +
        '</div></div>' +
        '<div class="field"><div class="field-head"><label>Your name</label></div>' +
          '<input type="text" id="set-uname" value="' + esc(s.userName) + '"></div>' +
        '<div class="field"><div class="field-head"><label>Your persona</label></div>' +
          '<textarea id="set-upersona" placeholder="Who you are in the story — appearance, background, goals.">' + esc(s.userPersona) + '</textarea></div>' +
      '</div>';
    var sc = settingsScope(body);
    /* Identity edits land on the persona when one is active, else on the default. */
    sc.bind('#set-uname', 'change', function (e) {
      Store.setIdentity({ name: e.target.value.trim() || 'You' }).then(function () { Views.settingsYou(root); });
    });
    sc.bind('#set-upersona', 'change', function (e) { Store.setIdentity({ text: e.target.value }); });
  };

  /* ---- System prompt ---- */
  Views.settingsSystem = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">System prompt</div>' +
        '<div class="field"><textarea class="tall" id="set-system">' + esc(s.systemPrompt) + '</textarea>' +
          '<div class="hint">Sent before the character sheet. Macros: {{char}}, {{user}}, {{persona}}.</div>' +
          '<button class="btn ghost sm" id="btn-reset-sys">Reset to default</button></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#set-system', 'change', function (e) { sc.set({ systemPrompt: e.target.value }); });
    sc.bind('#btn-reset-sys', 'click', function () {
      /* Reset to the real default (store.js) — this handler used to carry a
         stale copy that predated the formatting line and the closing
         "write only what the character does and says" sentence. */
      sc.set({ systemPrompt: Store.defaultSystem });
      Views.settingsSystem(root);
      UI.toast('System prompt reset');
    });
  };

  /* ---- AI Horde · images & free text ---- */
  Views.settingsHorde = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">AI Horde · images &amp; free text</div>' +
        '<div class="field"><div class="field-head"><label>Horde API key (optional)</label></div>' +
          '<input type="password" id="set-hkey" value="' + esc(s.hordeKey) + '" placeholder="0000000000 = anonymous">' +
          '<div class="hint">Free account at aihorde.net — a key jumps the queue. Anonymous works too.</div></div>' +
        '<div class="field"><div class="field-head"><label>Image model</label></div>' +
          '<div class="row"><button class="btn ghost sm" id="btn-hmodel" style="flex:1;text-align:left">' + esc(s.hordeModel || 'Tap to choose') + '</button>' +
          '<button class="btn ghost sm" id="btn-refresh-hmodels">' + icon('refresh') + '</button></div></div>' +
        '<div class="field"><div class="field-head"><label>Image size</label><span class="spacer"></span><span class="val" id="v-size">' + s.hordeSize + 'px</span></div>' +
          '<div class="hint">Smaller = cheaper in kudos and much shorter queue time.</div>' +
          '<div class="seg" id="seg-size">' + [512, 640, 768, 1024].map(function (n) {
            return '<button data-size="' + n + '"' + (n === s.hordeSize ? ' class="on"' : '') + '>' + n + '</button>';
          }).join('') + '</div></div>' +
        '<div class="field"><div class="field-head"><label>Diffusion steps</label><span class="spacer"></span><span class="val" id="v-steps">' + s.hordeSteps + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-steps" min="10" max="50" step="1" value="' + s.hordeSteps + '"></div></div>' +
        '<div class="field"><div class="field-head"><label>Give up after</label><span class="spacer"></span><span class="val" id="v-maxwait">' + Math.round(s.hordeMaxWait / 60) + ' min</span></div>' +
          '<div class="range-row"><input type="range" id="set-maxwait" min="2" max="20" step="1" value="' + Math.round(s.hordeMaxWait / 60) + '"><span class="hint">queue wait</span></div>' +
          '<div class="hint">The Horde is a queue, not an API — busy models can hold a job for minutes. ' +
          'Jobs show queue position and ETA live, and you can cancel at any time.</div></div>' +
        '<div class="field"><div class="field-head"><label>Horde text model</label></div>' +
          '<div class="row"><button class="btn ghost sm" id="btn-htext" style="flex:1;text-align:left">' + esc(Horde.modelLabel(s.hordeTextModel) || 'Any available (recommended)') + '</button>' +
          '<button class="btn ghost sm" id="btn-refresh-tmodels">' + icon('refresh') + '</button></div>' +
          '<div class="hint">Only used when the provider above is set to AI Horde.</div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#set-hkey', 'change', function (e) { sc.set({ hordeKey: e.target.value.trim() }); });
    sc.range('#set-steps', '#v-steps', 'hordeSteps');
    var mw = $('#set-maxwait', body);
    if (mw) mw.addEventListener('input', function () {
      var mins = parseInt(mw.value, 10);
      $('#v-maxwait', body).textContent = mins + ' min';
      sc.set({ hordeMaxWait: mins * 60 });
    });
    sc.bind('#seg-size', 'click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      sc.set({ hordeSize: parseInt(b.getAttribute('data-size'), 10) });
      body.querySelectorAll('#seg-size button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      $('#v-size', body).textContent = Store.settings.hordeSize + 'px';
    });
    sc.bind('#btn-refresh-hmodels', 'click', function () { App.chooseHordeModel('image', true); });
    sc.bind('#btn-hmodel', 'click', function () { App.chooseHordeModel('image', false); });
    sc.bind('#btn-refresh-tmodels', 'click', function () { App.chooseHordeModel('text', true); });
    sc.bind('#btn-htext', 'click', function () { App.chooseHordeModel('text', false); });
  };

  /* ---- Memory ---- */
  Views.settingsMemory = function (root) {
    var s = Store.settings;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Memory</div>' +
        '<div class="field compact"><label>Auto-summarise long chats</label><div class="toggle' + (s.autoMemory ? ' on' : '') + '" id="t-mem"></div></div>' +
        '<div class="field"><div class="field-head"><label>Summarise every</label><span class="spacer"></span><span class="val" id="v-memevery">' + s.memoryEvery + '</span></div>' +
          '<div class="range-row"><input type="range" id="set-memevery" min="6" max="60" step="2" value="' + s.memoryEvery + '"><span class="hint">msgs</span></div></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.toggle('#t-mem', 'autoMemory');
    sc.range('#set-memevery', '#v-memevery', 'memoryEvery');
  };

  /* ---- Data ---- */
  Views.settingsData = function (root) {
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Data</div>' +
        '<div class="field"><div class="row">' +
          '<button class="btn ghost sm" style="flex:1" id="btn-export">' + icon('download') + ' Backup</button>' +
          '<button class="btn ghost sm" style="flex:1" id="btn-import">' + icon('upload') + ' Restore</button>' +
        '</div><div class="hint">Backup exports everything except your API keys.</div></div>' +
        '<div class="field"><button class="btn danger block sm" id="btn-wipe">' + icon('trash') + ' Erase all characters and chats</button></div>' +
      '</div>';
    var sc = settingsScope(body);
    sc.bind('#btn-export', 'click', function () {
      Store.exportAll().then(function (json) {
        UI.download('horde-studio-backup-' + new Date().toISOString().slice(0, 10) + '.json', json);
        UI.toast('Backup downloaded');
      });
    });
    sc.bind('#btn-import', 'click', function () {
      pickFile('.json,application/json').then(function (f) {
        if (!f) return;
        var fr = new FileReader();
        fr.onload = function () {
          Promise.resolve()
            .then(function () { return Store.importAll(fr.result); })
            .then(function (r) {
              return Store.refreshCharacters().then(function () {
                UI.toast('Restored ' + r.characters + ' characters, ' + r.sessions + ' chats');
                Views.settingsData(root);
              });
            })
            .catch(function (e) { UI.toast('Restore failed: ' + e.message, 4000); });
        };
        fr.readAsText(f);
      });
    });
    sc.bind('#btn-wipe', 'click', function () {
      UI.confirm('Erase everything?', 'All characters, chats and memories on this device will be deleted. This cannot be undone.',
        { danger: true, okLabel: 'Erase' }).then(function (ok) {
        if (!ok) return;
        Store.wipe().then(function () { return Store.refreshCharacters(); }).then(function () {
          UI.toast('Everything erased');
          App.go('characters');
        });
      });
    });
  };

  /* ---- Storage ---- */
  Views.settingsStorage = function (root) {
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">Storage</div>' +
        '<div class="field">' +
          '<button class="btn ghost sm block" id="btn-storage">' + icon('copy') + ' Show storage use</button>' +
          '<div class="hint">A read-only look at what the app is holding on this phone. The app never deletes anything on its own.</div>' +
          '<div id="storage-lines" style="margin-top:8px"></div>' +
        '</div>' +
      '</div>';
    var sc = settingsScope(body);
    /* 18.2.0 (mobile subset): read-only storage inspection — count what the
       app holds on this phone and show the biggest holders. */
    sc.bind('#btn-storage', 'click', function () {
      var box = $('#storage-lines', body);
      box.innerHTML = '<div class="hint">Measuring…</div>';
      var chars = Store.characters || [];
      Promise.all(chars.map(function (c) {
        return Store.getSessions(c.id).then(function (ss) { return ss || []; });
      })).then(function (perChar) {
        var sessions = [];
        perChar.forEach(function (ss) { sessions = sessions.concat(ss); });
        return Promise.all(sessions.map(function (s) {
          return Store.getMessages(s.id).then(function (mm) { return mm || []; });
        })).then(function (perSession) {
          var messages = [];
          perSession.forEach(function (mm) { messages = messages.concat(mm); });
          return HW.all().then(function (worlds) {
            var rep = App.storageReport({
              characters: chars, sessions: sessions, messages: messages, worlds: worlds || []
            });
            box.innerHTML = '<div class="kv"><span>Everything above</span><b>~' + (rep.bytes >= 1048576 ? (rep.bytes / 1048576).toFixed(1) + ' MB' : Math.ceil(rep.bytes / 1024) + ' KB') + '</b></div>' +
              rep.lines.map(function (l) {
                return '<div class="kv"><span>' + esc(l[0]) + '</span><b style="text-align:right">' + esc(l[1]) + '</b></div>';
              }).join('');
          });
        });
      }).catch(function (e) {
        box.innerHTML = '<div class="hint">Could not measure: ' + esc(e.message || e) + '</div>';
      });
    });
  };

  /* ---- App updates ---- */
  Views.settingsUpdate = function (root) {
    var info = settingsUpdateInfo();
    var U = info.U, upInfo = info.upInfo, upUrl = info.upUrl, upNote = info.upNote;
    var body = $('#settings-x-body');
    body.innerHTML =
      '<div class="group">' +
        '<div class="group-title">App updates</div>' +
        '<div class="field"><div class="kv"><span>App</span><b>' + esc(upInfo.apk || '?') + '</b></div>' +
        '<div class="kv"><span>Files in use</span><b>' + (upInfo.overlay
            ? 'update ' + esc(upInfo.rev)
            : 'as shipped in the app') + '</b></div></div>' +
        '<div class="field"><div class="field-head"><label>Update address</label></div>' +
          '<input type="text" id="set-updurl" spellcheck="false" value="' + esc(upUrl) + '" placeholder="https://...">' +
          '<div class="hint">Where the app looks for new files. It only ever looks when you press the button below.</div></div>' +
        '<div class="field">' +
          '<button class="btn ghost sm" id="btn-upd-check">Check for update</button> ' +
          '<button class="btn ghost sm" id="btn-upd-file">Apply from a file</button> ' +
          '<button class="btn ghost sm" id="btn-upd-reset">Reset to shipped files</button>' +
          '<div class="hint" id="upd-status" style="margin-top:8px">' + upNote + '</div>' +
        '</div>' +
        '<div class="field">' +
          '<div class="field-head"><label>Error log</label>' +
            '<button class="btn ghost sm" id="btn-log-clear" style="margin-left:auto">Clear</button></div>' +
          '<div class="errlog" id="errlog-box"></div>' +
          '<div class="hint">The last things that went wrong — installs, downloads, crashes. ' +
            'The log keeps its newest 200 entries and drops the rest on its own; ' +
            'Clear starts it fresh.</div>' +
        '</div>' +
      '</div>';
    var sc = settingsScope(body);
    var upStatus = $('#upd-status', body);

    /* the error log: toasts fade, this stays. Newest first, the box scrolls;
       the wrapper caps the stored log itself (200 entries, oldest dropped). */
    var logBox = $('#errlog-box', body);
    function renderLog() {
      if (!logBox) return;
      var entries;
      try { entries = (global.Logs && Logs.list()) || []; } catch (e) { entries = []; }
      if (!entries.length) {
        logBox.innerHTML = '<p class="hint" style="margin:0">Nothing has gone wrong here yet.</p>';
        return;
      }
      logBox.innerHTML = entries.map(function (e) {
        var when = '';
        try { when = new Date(e.t).toLocaleString(); } catch (err) { when = String(e.t || ''); }
        return '<div class="errlog-line"><span class="errlog-when">' + esc(when) + '</span>' +
          '<span class="errlog-msg">' + esc(e && e.m) + '</span></div>';
      }).join('');
    }
    renderLog();
    sc.bind('#btn-log-clear', 'click', function () {
      UI.confirm('Clear the error log?', 'The log starts fresh. This does not touch chats, characters or settings.',
        { okLabel: 'Clear' }).then(function (yes) {
          if (!yes) return;
          try { global.Logs && Logs.clear(); } catch (e) { }
          renderLog();
          UI.toast('Error log cleared');
        });
    });
    function upSay(html) { if (upStatus) upStatus.innerHTML = html; }
    function upBar(pct, label) {
      upSay('<div class="upd-bar"><span style="width:' + Math.max(2, Math.min(100, pct || 0)) + '%"></span></div>' +
        '<div style="margin-top:4px">' + esc(label || 'Downloading') + ' ' + (pct || 0) + '%</div>');
    }
    /* The install is the one update path that replaces the app itself, so it
       is the one that states its data promise out loud before it starts: an
       in-place install keeps everything; only uninstalling the app first
       would lose chats. (Files-only updates never touch chat storage at all.) */
    function beginInstall(apkLabel, followUp) {
      UI.confirm('Install app ' + apkLabel + ' over the current app?',
        'It downloads the APK and opens Android’s install screen. Installing over the current app keeps all your chats and characters — data is only lost if you uninstall the app first.',
        { okLabel: 'Install' }).then(function (yes) {
          if (!yes) return;
          try { U.installApk(); upSay(followUp); }
          catch (e) { upSay('Could not start the install: ' + esc(e.message || String(e))); }
        });
    }
    sc.bind('#set-updurl', 'change', function (e) {
      if (!U) return;
      U.saveUrl(e.target.value).then(function () { UI.toast('Update address saved'); });
    });
    sc.bind('#btn-upd-check', 'click', function () {
      if (!U || !U.supported()) { upSay('Self-updating needs the newest APK installed once.'); return; }
      var btn = this;
      btn.disabled = true;
      upSay('Checking…');
      U.check().then(function (r) {
        btn.disabled = false;
        if (r.upToDate) {
          upSay('Up to date — app ' + esc(r.local.apk) + ', files ' +
            (r.local.overlay ? 'update ' + esc(r.local.rev) : 'as shipped') + '.');
          return;
        }
        /* One guided path, not a list of options to reason about:
           - files only → Apply now
           - app only → Install app update
           - both → "Update everything" (the install), and the files apply
             themselves on the next boot. No second Check for it. */
        var html = '';
        if (r.newApk && r.newWeb) {
          html += '<p><b>App ' + esc(r.remote.apk || '') + '</b> and new files are ready.</p>' +
            '<p>Install the app, then reopen it — the new files apply themselves. ' +
            'Installing over the current app keeps your chats and characters.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-all">Update everything</button> ' +
            '<button class="btn ghost sm" id="btn-upd-apply">Files only — keep this app</button></div>';
        } else if (r.newApk) {
          html += '<p>App <b>' + esc(r.remote.apk || '') + '</b> is ready. ' +
            'It downloads the APK and opens the Android install screen — ' +
            'installing over the current app keeps your chats and characters.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-install">Install app update</button> ' +
            '<button class="btn ghost sm" id="btn-upd-browser">Or in browser</button></div>';
        } else {
          html += '<p>Fixes are ready to apply <b>without reinstalling anything</b>.</p>';
          html += '<div class="row-gap" style="margin-top:8px">' +
            '<button class="btn sm" id="btn-upd-apply">Apply now</button></div>';
        }
        if (r.remote.note) html += '<p>' + esc(r.remote.note) + '</p>';
        upSay(html);

        var allBtn = $('#btn-upd-all', body);
        if (allBtn) allBtn.addEventListener('click', function () {
          beginInstall(esc(r.remote.apk || 'the update'),
            'Downloading — Android will ask you to confirm the install. ' +
            'After it finishes, reopen the app: the new files apply themselves.');
        });

        var applyBtn = $('#btn-upd-apply', body);
        if (applyBtn) applyBtn.addEventListener('click', function () {
          applyBtn.disabled = true;
          upSay('Downloading the new files…');
          U.applyWeb(r.remote.webRev, function (p) { upBar(p, 'Downloading'); }).then(function () {
            upSay('Applied — reloading…');
            setTimeout(function () { U.reloadFresh(); }, 500);
          }).catch(function (e2) {
            applyBtn.disabled = false;
            upSay('Could not apply the update: ' + esc(e2.message || String(e2)));
          });
        });

        var instBtn = $('#btn-upd-install', body);
        if (instBtn) instBtn.addEventListener('click', function () {
          beginInstall(esc(r.remote.apk || 'the update'),
            'Downloading — Android will ask you to confirm the install.');
        });
        var browBtn = $('#btn-upd-browser', body);
        if (browBtn) browBtn.addEventListener('click', function () {
          try { U.openDownload(); upSay('Opened in your browser — download and install there.'); }
          catch (e4) { upSay('Could not open the browser: ' + esc(e4.message || String(e4))); }
        });
      }).catch(function (e) {
        btn.disabled = false;
        var msg = e.message || String(e);
        if (/answered (502|503|504)/.test(msg)) {
          msg += ' That address belongs to a workspace that is no longer running. Either ' +
            'paste the current address into Update address above, or use ' +
            'Apply from a file — download the bundle in your browser and pick it here.';
        } else if (/answered (401|403)|refused the request/.test(msg)) {
          msg += ' Apply from a file works without the network: download the bundle in ' +
            'your browser, then pick it here.';
        }
        upSay('Could not check: ' + esc(msg));
      });
    });
    sc.bind('#btn-upd-file', 'click', function () {
      if (!U || !U.supported()) { upSay('Self-updating needs the newest APK installed once.'); return; }
      upSay('Choose the update file you downloaded…');
      U.applyFile(function (p) { upBar(p, 'Applying'); }).then(function (rev) {
        upSay('Applied revision ' + esc(String(rev)) + ' — reloading…');
        setTimeout(function () { U.reloadFresh(); }, 600);
      }).catch(function (e2) {
        var m = (e2 && e2.message) || String(e2);
        upSay(/No file chosen/i.test(m) ? 'No file chosen — nothing changed.'
          : 'Could not apply that file: ' + esc(m));
      });
    });
    sc.bind('#btn-upd-reset', 'click', function () {
      if (!U || !U.supported()) return;
      UI.confirm('Go back to the shipped files?', 'The update is removed and the app restarts on the copy that came with the APK. Your chats and characters are untouched.',
        { okLabel: 'Reset' }).then(function (ok) {
          if (!ok) return;
          U.reset();
          U.reloadFresh();
        });
    });
  };
  
  /* ================= EDITOR ================= */
  Views.editor = function (root, char) {
    var isNew = !char.id || !Store.characters.some(function (c) { return c.id === char.id; });
    VH.ensure(char);
    var vh = char.vh;
    var vh_enabled = !!vh.enabled;
    /* the Create-with-AI card shows on an empty sheet only: once the model
     * (or the user) has written persona/scenario/greeting it goes away */
    var emptySheet = !char.persona && !char.scenario && !char.greeting;
    function slider(id, label, val) {
      var pct = Math.round((Math.max(-1, Math.min(1, val || 0)) + 1) / 2 * 100);
      return '<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted)">' +
        '<span>' + esc(label) + '</span><span id="' + id + '-v">' + (val || 0).toFixed(2) + '</span></div>' +
        '<input type="range" id="' + id + '" min="-100" max="100" step="5" value="' + Math.round((val || 0) * 100) + '" style="width:100%"></div>';
    }
    $('#editor-body').innerHTML =
      '<div class="group">' +
        '<div class="field"><div class="avatar-edit" id="av-wrap">' +
          (char.avatar ? '<img src="' + esc(char.avatar) + '" alt="">' : '<div class="ph">' + icon('user') + '</div>') +
          '<div style="flex:1">' +
            '<button class="btn ghost sm block" data-act="av-url">Use image URL</button>' +
            '<button class="btn ghost sm block" style="margin-top:6px" data-act="av-file">Upload from phone</button>' +
            '<button class="btn ghost sm block" style="margin-top:6px" data-act="av-gen">Generate with AI Horde</button>' +
          '</div>' +
        '</div></div>' +
      '</div>' +

      /* v1.29.0: pictures the card itself carries, besides the avatar.
         Display-only — never part of the prompt. */
      (char.images && char.images.length
        ? '<div class="group">' +
          '<div class="group-title">Card images</div>' +
          '<div class="field">' +
            '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(84px,1fr));gap:8px">' +
            char.images.map(function (im) {
              return '<img src="' + esc(im.src) + '" alt="' + esc(im.name || 'card image') + '"' +
                ' data-lightbox="' + esc(im.src) + '"' +
                ' style="width:100%;height:84px;object-fit:cover;border-radius:8px;cursor:zoom-in" loading="lazy">';
            }).join('') +
            '</div>' +
            '<div class="hint">From the card itself — for you to look at, never sent to the model.</div>' +
          '</div>' +
        '</div>'
        : '') +

      '<div class="group">' +
        '<div class="group-title">Identity</div>' +
        '<div class="field"><div class="field-head"><label>Name</label></div>' +
          '<input type="text" id="e-name" value="' + esc(char.name) + '" placeholder="e.g. Seraphine Vale"></div>' +
        '<div class="field"><div class="field-head"><label>Tagline</label></div>' +
          '<input type="text" id="e-tagline" value="' + esc(char.tagline) + '" placeholder="Short hook shown on the card"></div>' +
        '<div class="field"><div class="field-head"><label>Tags</label></div>' +
          '<input type="text" id="e-tags" value="' + esc((char.tags || []).join(', ')) + '" placeholder="fantasy, mentor, slow-burn"></div>' +
      '</div>' +

      (emptySheet
        ? '<div class="group">' +
          '<div class="group-title">Create with AI</div>' +
          '<div class="field"><div class="field-head"><label>Describe who they are</label></div>' +
            '<textarea id="ai-idea" placeholder="e.g. a grumpy blacksmith who owes the tavern a debt and secretly writes poetry — she has not spoken to her sister in nine years"></textarea>' +
            '<div class="hint">One or two lines is plenty. The model drafts the whole sheet — name, persona, opening line and their life — which you can then edit. Two small requests, spent only when you press the button.</div></div>' +
          '<div class="field"><button class="btn primary block sm" data-act="ai-create">' +
            icon('sparkle') + ' Draft the whole person (2 requests)</button></div>' +
        '</div>'
        : '') +

      '<div class="group">' +
        '<div class="group-title">Character sheet</div>' +
        '<div class="field"><div class="field-head"><label>Persona</label>' +
          '<span class="spacer"></span><button class="chip" data-act="ai-persona">' + icon('sparkle') + ' AI draft</button></div>' +
          '<textarea class="tall" id="e-persona" placeholder="Appearance, personality, history, wants, voice…">' + esc(char.persona) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Scenario</label>' +
          Views.scenarioChip(char.scenarioList) +
          '<span class="spacer"></span><button class="chip" data-act="ai-scenario">' + icon('sparkle') + ' AI draft</button></div>' +
          '<textarea id="e-scenario" placeholder="Where the story starts.">' + esc(char.scenario) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Greeting (first message)</label>' +
          '<span class="spacer"></span><button class="chip" data-act="ai-greeting">' + icon('sparkle') + ' AI draft</button></div>' +
          '<textarea id="e-greeting" placeholder="The opening line {{char}} sends.">' + esc(char.greeting) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Example dialogue</label></div>' +
          '<textarea class="tall" id="e-examples" placeholder="{{user}}: …&#10;{{char}}: …">' + esc(char.examples) + '</textarea>' +
          '<div class="hint">Alternating {{user}}: / {{char}}: lines. Optional, but it nails the voice.</div></div>' +
        '<div class="field"><div class="field-head"><label>Always-remember note</label></div>' +
          '<textarea id="e-post" placeholder="Appended last, right before the reply is generated.">' + esc(char.postHistory) + '</textarea></div>' +
      '</div>' +

      '<div class="group">' +
        '<div class="group-title">Virtual human</div>' +
        '<div class="field compact"><label>Give them their own life</label>' +
          '<div class="toggle' + (vh_enabled ? ' on' : '') + '" id="vh-on"></div></div>' +
        '<div id="vh-fields"' + (vh_enabled ? '' : ' hidden') + '>' +
          '<div class="field"><div class="field-head"><label>Reaches out to you</label></div>' +
            '<div class="seg" id="vh-auto">' + ['off', 'low', 'medium', 'high'].map(function (k) {
              return '<button data-a="' + k + '"' + (vh.autonomy === k ? ' class="on"' : '') + '>' +
                ({ off: 'Never', low: 'Rarely', medium: 'Sometimes', high: 'Often' })[k] + '</button>';
            }).join('') + '</div>' +
            '<div class="hint">Never = they only answer you. Often = they message on their own every couple of hours.</div></div>' +
          '<div class="field"><div class="field-head"><label>Asleep</label></div>' +
            '<div class="row"><input type="time" id="vh-sleep-start" value="' + esc(vh.sleep.start) + '" style="flex:1">' +
            '<input type="time" id="vh-sleep-end" value="' + esc(vh.sleep.end) + '" style="flex:1"></div>' +
            '<div class="hint">While asleep they do not answer — the message waits until they wake.</div></div>' +
          '<div class="field"><div class="field-head"><label>Takes this long to reply</label>' +
            '<span class="spacer"></span><span class="val" id="vh-dmin-v">' + vh.replyDelay.min + 's – ' + vh.replyDelay.max + 's</span></div>' +
            '<div class="range-row"><span class="hint">min</span><input type="range" id="vh-dmin" min="0" max="180" step="5" value="' + vh.replyDelay.min + '"></div>' +
            '<div class="range-row"><span class="hint">max</span><input type="range" id="vh-dmax" min="15" max="900" step="15" value="' + vh.replyDelay.max + '"></div></div>' +
          '<div class="field compact"><label>Sends photos</label><div class="toggle' + (vh.photos ? ' on' : '') + '" id="vh-photos"></div></div>' +
          '<div class="field"><div class="field-head"><label>Daily routine</label></div>' +
            '<div id="vh-routine"></div>' +
            '<button class="btn ghost sm block" id="vh-add" style="margin-top:8px">' + icon('plus') + ' Add time of day</button>' +
            '<div class="hint">What they are doing, from that hour onward. Drives their status and what they talk about.</div></div>' +
          '<div class="field"><div class="field-head"><label>Inner state</label></div>' +
            slider('vh-mood', 'Mood', vh.mood) +
            slider('vh-aff', 'Affinity', vh.affinity) +
            slider('vh-trust', 'Trust', vh.trust) +
            slider('vh-ten', 'Tension', vh.tension) +
            '<div class="hint">Drifts on its own as time passes and as you talk. Drag to steer the relationship.</div></div>' +
          '<div class="field"><div class="field-head"><label>Places in their life</label></div>' +
            '<div id="vh-places"></div>' +
            '<button class="btn ghost sm block" id="vh-add-place" style="margin-top:8px">' + icon('plus') + ' Add a place</button>' +
            '<div class="hint">Where their day happens. They travel between these in real time, and being somewhere else is why they took so long to answer.</div>' +
            '<div id="vh-world"></div>' +
            '<button class="btn ghost sm block" id="vh-world-pack" style="margin-top:8px">' + icon('download') + ' Load a world pack</button></div>' +
          '<div class="field"><div class="field-head"><label>People in their life</label></div>' +
            '<div id="vh-people"></div>' +
            '<button class="btn ghost sm block" id="vh-add-person" style="margin-top:8px">' + icon('plus') + ' Add a person</button>' +
            '<div class="hint">The supporting cast — colleagues, neighbours, family. They come up in conversation and give them something to talk about besides you.</div></div>' +
          '<div class="field"><div class="field-head"><label>Standing diary</label></div>' +
            '<div id="vh-cal"></div>' +
            '<button class="btn ghost sm block" id="vh-add-cal" style="margin-top:8px">' + icon('plus') + ' Add to the diary</button>' +
            '<div class="hint">Repeating commitments: a shift, a class, a standing dinner. They head off to these.</div></div>' +
          '<div class="field"><div class="field-head"><label>Texts in one go</label>' +
            '<span class="spacer"></span><span class="val" id="vh-burst-v">' + (vh.burst || 3) + '</span></div>' +
            '<div class="range-row"><input type="range" id="vh-burst" min="1" max="4" step="1" value="' + (vh.burst || 3) + '"></div>' +
            '<div class="hint">Most separate bubbles they may send in one reply, when what they wrote reads as several short texts rather than one paragraph.</div></div>' +
        '</div>' +
      '</div>' +

      (char.vh
        ? ''
        : '<div class="group">' +
          '<div class="group-title">Internal state</div>' +
          '<div class="field compact"><label>Track internal state</label>' +
            '<div class="toggle' + (char.stateTracking === true ? ' on' : '') + '" id="t-istate"></div></div>' +
          '<div id="istate-fields"' + (char.stateTracking === true ? '' : ' hidden') + '>' +
            '<div class="field"><div class="field-head"><label>Mood</label></div>' +
              '<input type="text" id="e-mood" value="' + esc(((char.state || {}).mood) || '') + '" placeholder="weary but fond"></div>' +
            '<div class="field"><div class="field-head"><label>Intent</label></div>' +
              '<input type="text" id="e-intent" value="' + esc(((char.state || {}).intent) || '') + '" placeholder="what they are trying to do next"></div>' +
            '<div class="field"><div class="field-head"><label>Flags</label></div>' +
              '<input type="text" id="e-flags" value="' + esc(((char.state || {}).flags) || '') + '" placeholder="details worth remembering, comma-separated"></div>' +
            '<div class="hint">When on, the current state is sent with every request and the model ends each ' +
            'reply with an updated one (hidden from you) — so mood, plans and small plot turns carry ' +
            'across long chats without you repeating them. A strip at the top of the chat shows it live. ' +
            'Costs a few dozen extra tokens per reply. Virtual humans keep their own simulation-driven ' +
            'Inner state instead.</div>' +
          '</div>' +
        '</div>') +

      '<div class="group">' +
        '<div class="group-title">Overrides (optional)</div>' +
        '<div class="field"><div class="field-head"><label>System prompt override</label></div>' +
          '<textarea id="e-sys" placeholder="Blank = use the global system prompt.">' + esc(char.systemPrompt) + '</textarea></div>' +
        '<div class="field"><div class="field-head"><label>Temperature</label><span class="spacer"></span><span class="val" id="v-ctemp">' +
            (char.temperature === null || char.temperature === undefined ? 'global' : char.temperature) + '</span></div>' +
          '<div class="range-row"><input type="range" id="e-temp" min="0" max="2" step="0.05" value="' +
            (char.temperature === null || char.temperature === undefined ? 0.85 : char.temperature) + '">' +
            '<button class="chip" id="e-temp-clear">global</button></div></div>' +
      '</div>' +

      '<div class="group">' +
        '<div class="field"><div class="row">' +
          '<button class="btn primary" style="flex:1" data-act="save">' + icon('edit') + ' Save character</button>' +
          (isNew ? '' : '<button class="btn danger" data-act="delete">' + icon('trash') + '</button>') +
        '</div></div>' +
      '</div>';

    var body = $('#editor-body');
    var draft = Object.assign({}, char);

    function collect() {
      draft.name = $('#e-name', body).value.trim();
      draft.tagline = $('#e-tagline', body).value.trim();
      draft.tags = $('#e-tags', body).value.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
      draft.persona = $('#e-persona', body).value;
      draft.scenario = $('#e-scenario', body).value;
      draft.greeting = $('#e-greeting', body).value;
      draft.examples = $('#e-examples', body).value;
      draft.postHistory = $('#e-post', body).value;
      draft.systemPrompt = $('#e-sys', body).value;
      if ($('#e-mood', body)) {
        var oldSt = draft.state || {};
        var newSt = {
          mood: $('#e-mood', body).value.trim(),
          intent: $('#e-intent', body).value.trim(),
          flags: $('#e-flags', body).value.trim()
        };
        var changed = newSt.mood !== (oldSt.mood || '') ||
          newSt.intent !== (oldSt.intent || '') || newSt.flags !== (oldSt.flags || '');
        draft.state = Object.assign({}, oldSt, newSt,
          changed ? { updatedAt: Date.now(), by: 'user' } : {});
      }
      return draft;
    }

    /* v1.29.0: the card's own pictures open full-screen on tap */
    on(body, '[data-lightbox]', 'click', function (e) {
      UI.lightbox(e.currentTarget.getAttribute('data-lightbox'));
    });

    on(body, '[data-act=av-url]', 'click', function () {
      UI.input('Avatar image URL').then(function (url) {
        if (!url) return;
        draft.avatar = url.trim();
        $('#av-wrap', body).querySelector('img,.ph').outerHTML = '<img src="' + esc(draft.avatar) + '" alt="">';
      });
    });
    on(body, '[data-act=av-file]', 'click', function () {
      pickFile('image/*').then(function (f) {
        if (!f) return;
        /* 18.2.0: import through the normalizer — downscaled, re-encoded,
           transparency kept — before it lands in IndexedDB. */
        normalizeImage(f).then(function (d) {
          draft.avatar = d;
          var w = $('#av-wrap', body).querySelector('img,.ph');
          w.outerHTML = '<img src="' + esc(d) + '" alt="">';
        });
      });
    });
    on(body, '[data-act=av-gen]', 'click', function () {
      App.generateAvatar(draft).then(function (url) {
        if (!url) return;
        draft.avatar = url;
        var w = $('#av-wrap', body).querySelector('img,.ph');
        w.outerHTML = '<img src="' + esc(url) + '" alt="">';
      });
    });
    on(body, '[data-act=ai-persona]', 'click', function () {
      var name = $('#e-name', body).value.trim();
      if (!name) { UI.toast('Add a name first'); return; }
      UI.toast('Asking the model…');
      /* 18.1.0: a drafted persona keeps the direction the player gave instead
         of being normalised into an agreeable template. One bounded request,
         one field — the draft fills the persona box and nothing else. */
      API.quickText(Store.settings,
        'Write a roleplay character persona for a character named ' + name +
        (draft.tagline
          ? ' — their direction is "' + draft.tagline + '". Follow it exactly: if it describes an unsettling, obsessive, antagonistic, eccentric or solitary person, write that person, not a likable version of them. '
          : '. ') +
        'Use third person, under 200 words. Cover: appearance, personality (strengths and flaws as they actually are), wants, and how they speak. No headings.',
        320).then(function (txt) {
          $('#e-persona', body).value = txt.trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });

    /* 18.1.0: the whole-person draft is TWO bounded JSON requests, each
     * under the Horde's 512-token anonymous limit, so heavy demand cannot
     * reject the job over pre-held kudos. Part one (the person) lands in the
     * sheet fields as it comes; part two (the life) fails without losing it.
     * It only offers itself on an empty sheet, keeps the player's direction,
     * and never overwrites a field the player already wrote by hand.
     * Opening the editor spends nothing. */
    on(body, '[data-act=ai-create]', 'click', function () {
      var idea = $('#ai-idea', body).value.trim();
      if (!idea) { UI.toast('Describe who they are, even one line'); return; }
      var btn = this; btn.disabled = true;
      UI.toast('Drafting the person — 1 of 2…');
      /* 1/2 the person: name, voice, opening — the direction lives here */
      API.aiJson(Store.settings,
        'You are helping create a roleplay character. The player\'s direction: "' +
        idea + '". Preserve that direction exactly — if it describes an unsettling, ' +
        'obsessive, antagonistic, eccentric or solitary person, create that person, ' +
        'not a likable or tamed version of them. ' +
        'Return ONLY a JSON object, no markdown, no commentary, with exactly these keys: ' +
        '{"name":string (use the direction\'s name if it gives one, else invent a fitting one), ' +
        '"tagline":string (8-12 words, the hook shown on the card), ' +
        '"persona":string (third person, under 150 words: appearance, personality with real flaws, a short history, what they want, how they speak), ' +
        '"scenario":string (2-3 sentences: where the story starts, with a small hook or tension), ' +
        '"greeting":string (the character\'s first message to the player, 1-3 sentences, in their voice), ' +
        '"examples":string (two short {{user}}: and {{char}}: exchanges that pin the voice)}',
        450).then(function (a) {
          if (!a || !a.persona) {
            btn.disabled = false;
            return UI.toast('No usable draft — try again', 4500);
          }
          /* name/tagline only if the player left them empty — set the inputs,
             collect() below picks them up like any other field */
          if (a.name && !$('#e-name', body).value.trim()) $('#e-name', body).value = String(a.name).trim().slice(0, 60);
          if (a.tagline && !$('#e-tagline', body).value.trim()) $('#e-tagline', body).value = String(a.tagline).trim().slice(0, 140);
          if (a.persona) $('#e-persona', body).value = String(a.persona).trim().slice(0, 2400);
          if (a.scenario) $('#e-scenario', body).value = String(a.scenario).trim().slice(0, 600);
          if (a.greeting) $('#e-greeting', body).value = String(a.greeting).trim().slice(0, 600);
          if (a.examples) $('#e-examples', body).value = String(a.examples).trim().slice(0, 1200);
          /* 2/2 the life around the story, conditioned on the person */
          UI.toast('Now their life — 2 of 2…');
          var who = ($('#e-name', body).value.trim() || 'the character');
          var personaClip = String(a.persona).trim().slice(0, 300);
          return API.aiJson(Store.settings,
            'Draft the life around the story for ' + who +
            (personaClip ? ', whose persona is: "' + personaClip + '"' : '') + '. ' +
            'Return ONLY a JSON object, no markdown, no commentary, with exactly these keys: ' +
            '{"places":[{"id":"snake_id","name":string,"kind":"home|work|outdoor|other","note":short string}, 3 places], ' +
            '"routine":[{"t":"HH:MM","a":short string}, 5 entries across the waking day], ' +
            '"sleep":{"start":"HH:MM","end":"HH:MM"}, ' +
            '"people":[{"name":string,"relation":string,"closeness":number from -1 to 1,"note":short string}, 2-3 people in their life], ' +
            '"diary":[1-3 short past-tense life beats]}',
            350).then(function (b) {
              if (!b) {
                btn.disabled = false;
                return UI.toast('The person is drafted; the life part failed — press again to finish it', 5000);
              }
              /* the life around the inbox: fill only what came back clean */
              if (Array.isArray(b.places) && b.places.length) {
                var places = b.places.filter(function (p) { return p && p.name; }).slice(0, 8).map(function (p, i) {
                  return { id: (typeof p.id === 'string' && /^[\w-]+$/.test(p.id)) ? p.id : 'place_' + i,
                    name: String(p.name).slice(0, 60), kind: String(p.kind || 'other').slice(0, 20),
                    note: String(p.note || '').slice(0, 160) };
                });
                if (places.length) { vh.places = places; vh.place = places[0].id; }
              }
              if (Array.isArray(b.routine) && b.routine.length) {
                var routine = b.routine.filter(function (r) { return r && /^\d{1,2}:\d{2}$/.test(String(r.t)) && r.a; })
                  .slice(0, 12).map(function (r) { return { t: String(r.t), a: String(r.a).slice(0, 120) }; });
                if (routine.length) vh.routine = routine;
              }
              if (b.sleep && /^\d{1,2}:\d{2}$/.test(String(b.sleep.start)) && /^\d{1,2}:\d{2}$/.test(String(b.sleep.end))) {
                vh.sleep = { start: String(b.sleep.start), end: String(b.sleep.end) };
              }
              if (Array.isArray(b.people) && b.people.length) {
                vh.people = b.people.filter(function (p) { return p && p.name; }).slice(0, 8).map(function (p) {
                  var c = parseFloat(p.closeness);
                  return { id: VH.uid('pe'), name: String(p.name).slice(0, 60),
                    relation: String(p.relation || '').slice(0, 60),
                    closeness: isNaN(c) ? 0 : Math.max(-1, Math.min(1, c)),
                    note: String(p.note || '').slice(0, 160) };
                });
              }
              if (Array.isArray(b.diary) && b.diary.length) {
                vh.chronicle = b.diary.map(function (t) { return { ts: Date.now(), text: String(t).slice(0, 300) }; });
              }
              UI.toast('Draft in — edit anything, then Save');
              collect();
              Views.editor($('#editor-body'), Object.assign({}, char, draft, { vh: vh }));
            });
        }).catch(function (e) {
          btn.disabled = false;
          UI.toast('Draft failed: ' + e.message, 4000);
        });
    });

    on(body, '[data-act=ai-scenario]', 'click', function () {
      var name = $('#e-name', body).value.trim() || 'the character';
      var persona = $('#e-persona', body).value.trim().slice(0, 400);
      UI.toast('Asking the model — one request…');
      API.aiJson(Store.settings,
        'Write a roleplay scenario for ' + name +
        (persona ? ', whose persona is: "' + persona + '"' : '') +
        '. Return ONLY a JSON object, no markdown, no commentary: ' +
        '{"scenario": string} — 2-4 sentences, a concrete opening situation with a small hook or tension, written so the player can answer it.',
        160).then(function (d) {
          if (!d || !d.scenario) return UI.toast('No usable draft — try again', 4500);
          $('#e-scenario', body).value = String(d.scenario).trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });
    /* A card can ship several starting scenarios (scenario_list). Choose the
       one to start from: it lands in the Scenario field, ready to edit, and
       saves with the character like anything else. */
    on(body, '[data-act=scenarios]', 'click', function () {
      var list = draft.scenarioList || [];
      if (list.length < 2) return;
      UI.sheet({
        title: 'Where the card can start',
        body: '<div class="hint" style="margin-bottom:8px">Pick the one to start from — it lands in the Scenario field, ready to edit.</div>' +
          list.map(function (s, i) {
            var t = String(s);
            var prev = t.length > 160 ? t.slice(0, 160) + '…' : t;
            return '<div class="opt" data-sci="' + i + '" style="align-items:flex-start">' +
              '<b style="min-width:26px;color:var(--dim)">' + (i + 1) + '.</b>' +
              '<span style="flex:1;white-space:pre-line">' + esc(prev) + '</span></div>';
          }).join(''),
        onMount: function (b, close) {
          b.querySelectorAll('[data-sci]').forEach(function (el) {
            el.onclick = function () {
              var i = +el.getAttribute('data-sci');
              $('#e-scenario', body).value = list[i];
              UI.toast('Scenario ' + (i + 1) + ' loaded — edit it as you like');
              close();
            };
          });
        }
      });
    });

    on(body, '[data-act=ai-greeting]', 'click', function () {
      var name = $('#e-name', body).value.trim() || 'the character';
      var persona = $('#e-persona', body).value.trim().slice(0, 400);
      UI.toast('Asking the model — one request…');
      API.aiJson(Store.settings,
        'Write the opening message a roleplay character named ' + name +
        (persona ? ', whose persona is: "' + persona + '"' : '') +
        ', would send the player as their very first line. In their voice, 1-3 sentences, ending so the player can answer. ' +
        'Return ONLY a JSON object, no markdown, no commentary: {"greeting": string}.',
        120).then(function (d) {
          if (!d || !d.greeting) return UI.toast('No usable draft — try again', 4500);
          $('#e-greeting', body).value = String(d.greeting).trim();
          UI.toast('Draft inserted — edit as you like');
        }).catch(function (e) { UI.toast('Draft failed: ' + e.message, 4000); });
    });

    $('#e-temp', body).addEventListener('input', function () {
      draft.temperature = parseFloat(this.value);
      $('#v-ctemp', body).textContent = draft.temperature.toFixed(2);
    });
    $('#e-temp-clear', body).addEventListener('click', function () {
      draft.temperature = null;
      $('#v-ctemp', body).textContent = 'global';
    });
    /* ---- virtual human block ---- */
    function renderRoutine() {
      var box = $('#vh-routine', body);
      if (!box) return;
      box.innerHTML = (vh.routine || []).map(function (r, i) {
        return '<div class="row" style="margin-bottom:6px" data-r="' + i + '">' +
          '<input type="time" value="' + esc(r.t) + '" style="width:104px;flex:0 0 auto" data-rt="' + i + '">' +
          '<input type="text" value="' + esc(r.a) + '" placeholder="what they are doing" style="flex:1" data-ra="' + i + '">' +
          '<button class="chip" data-rdel="' + i + '">' + icon('trash') + '</button></div>';
      }).join('');
      box.querySelectorAll('[data-rt]').forEach(function (el) {
        el.onchange = function () { vh.routine[+el.getAttribute('data-rt')].t = el.value; };
      });
      box.querySelectorAll('[data-ra]').forEach(function (el) {
        el.oninput = function () { vh.routine[+el.getAttribute('data-ra')].a = el.value; };
      });
      box.querySelectorAll('[data-rdel]').forEach(function (el) {
        el.onclick = function () { vh.routine.splice(+el.getAttribute('data-rdel'), 1); renderRoutine(); };
      });
    }
    renderRoutine();

    var KINDS = ['home', 'work', 'cafe', 'shop', 'outdoor', 'other'];
    var DAYS = ['Every day', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    function placeOptions(sel) {
      return (vh.places || []).map(function (p) {
        return '<option value="' + esc(p.id) + '"' + (sel === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>';
      }).join('');
    }

    function renderPlaces() {
      var box = $('#vh-places', body);
      if (!box) return;
      box.innerHTML = (vh.places || []).map(function (p, i) {
        return '<div class="row" style="margin-bottom:6px" data-p="' + i + '">' +
          '<input type="text" value="' + esc(p.name) + '" placeholder="name" style="flex:1" data-pn="' + i + '">' +
          '<select data-pk="' + i + '" style="width:104px;flex:0 0 auto">' +
            KINDS.map(function (k) {
              return '<option value="' + k + '"' + (p.kind === k ? ' selected' : '') + '>' + k + '</option>';
            }).join('') +
          '</select>' +
          '<button class="chip" data-pdel="' + i + '">' + icon('trash') + '</button></div>' +
          '<input type="text" value="' + esc(p.note || '') + '" placeholder="what it is like there (optional)" ' +
            'style="width:100%;margin:-2px 0 8px" data-pnote="' + i + '">';
      }).join('') +
      '<div class="row"><span class="hint" style="flex:0 0 auto;margin-right:6px">Currently at</span>' +
      '<select id="vh-at" style="flex:1">' + placeOptions(vh.place) + '</select></div>';

      box.querySelectorAll('[data-pn]').forEach(function (el) {
        el.oninput = function () { vh.places[+el.getAttribute('data-pn')].name = el.value; };
      });
      box.querySelectorAll('[data-pk]').forEach(function (el) {
        el.onchange = function () { vh.places[+el.getAttribute('data-pk')].kind = el.value; };
      });
      box.querySelectorAll('[data-pnote]').forEach(function (el) {
        el.oninput = function () { vh.places[+el.getAttribute('data-pnote')].note = el.value; };
      });
      box.querySelectorAll('[data-pdel]').forEach(function (el) {
        el.onclick = function () {
          var list = vh.places || [];
          if (list.length <= 1) return UI.toast('They need at least one place');
          var i = +el.getAttribute('data-pdel');
          var gone = list[i];
          /* 18.1.0: removing a place that life still references says so,
             instead of the references quietly dangling. */
          var notes = [];
          if (vh.travel && (vh.travel.to === gone.id || vh.travel.from === gone.id)) {
            vh.travel = null;
            notes.push('trip to ' + gone.name + ' cancelled');
          }
          var moved = (vh.calendar || []).filter(function (e) { return e.placeId === gone.id; }).length;
          list.splice(i, 1);
          if (vh.place === gone.id) { vh.place = list[0].id; notes.push('now placed at ' + list[0].name); }
          (vh.calendar || []).forEach(function (e) { if (e.placeId === gone.id) e.placeId = null; });
          if (moved) notes.push(moved + ' diary event' + (moved > 1 ? 's' : '') + ' have no location');
          renderPlaces(); renderCal();
          if (notes.length) UI.toast(notes.join(' · '), 4000);
        };
      });
      var at = $('#vh-at', box);
      if (at) at.onchange = function () { vh.place = at.value; };
    }

    function renderPeople() {
      var box = $('#vh-people', body);
      if (!box) return;
      if (!(vh.people || []).length) {
        box.innerHTML = '<div class="hint">Nobody yet.</div>';
        return;
      }
      box.innerHTML = vh.people.map(function (p, i) {
        return '<div style="margin-bottom:10px" data-pe="' + i + '">' +
          '<div class="row" style="margin-bottom:6px">' +
            '<input type="text" value="' + esc(p.name) + '" placeholder="name" style="flex:1" data-pen="' + i + '">' +
            '<input type="text" value="' + esc(p.relation || '') + '" placeholder="relation" style="flex:1" data-per="' + i + '">' +
            '<button class="chip" data-pedel="' + i + '">' + icon('trash') + '</button></div>' +
          '<div class="row"><span class="hint" style="flex:0 0 auto;margin-right:6px">closeness</span>' +
            '<input type="range" min="0" max="100" value="' + Math.round((p.closeness === undefined ? 0.5 : p.closeness) * 100) + '" data-pec="' + i + '" style="flex:1"></div>' +
          '<input type="text" value="' + esc(p.note || '') + '" placeholder="a note about them (optional)" style="width:100%;margin-top:6px" data-penote="' + i + '">' +
        '</div>';
      }).join('');
      box.querySelectorAll('[data-pen]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-pen')].name = el.value; };
      });
      box.querySelectorAll('[data-per]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-per')].relation = el.value; };
      });
      box.querySelectorAll('[data-pec]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-pec')].closeness = parseInt(el.value, 10) / 100; };
      });
      box.querySelectorAll('[data-penote]').forEach(function (el) {
        el.oninput = function () { vh.people[+el.getAttribute('data-penote')].note = el.value; };
      });
      box.querySelectorAll('[data-pedel]').forEach(function (el) {
        el.onclick = function () { vh.people.splice(+el.getAttribute('data-pedel'), 1); renderPeople(); };
      });
    }

    function renderCal() {
      var box = $('#vh-cal', body);
      if (!box) return;
      if (!(vh.calendar || []).length) {
        box.innerHTML = '<div class="hint">Nothing recurring.</div>';
        return;
      }
      box.innerHTML = vh.calendar.map(function (e, i) {
        return '<div class="row" style="margin-bottom:6px" data-c="' + i + '">' +
          '<input type="time" value="' + esc(e.t || '09:00') + '" style="width:96px;flex:0 0 auto" data-ct="' + i + '">' +
          '<input type="text" value="' + esc(e.label || '') + '" placeholder="what it is" style="flex:1" data-cl="' + i + '">' +
          '<select data-cd="' + i + '" style="width:104px;flex:0 0 auto">' +
            DAYS.map(function (d, di) {
              var val = di === 0 ? '' : String(di - 1);
              var cur = (e.day === null || e.day === undefined) ? '' : String(e.day);
              return '<option value="' + val + '"' + (cur === val ? ' selected' : '') + '>' + d + '</option>';
            }).join('') +
          '</select>' +
          '<select data-cp="' + i + '" style="width:96px;flex:0 0 auto">' +
            '<option value="">—</option>' + placeOptions(e.placeId) +
          '</select>' +
          '<button class="chip" data-cdel="' + i + '">' + icon('trash') + '</button></div>';
      }).join('');
      box.querySelectorAll('[data-ct]').forEach(function (el) {
        el.onchange = function () { vh.calendar[+el.getAttribute('data-ct')].t = el.value; };
      });
      box.querySelectorAll('[data-cl]').forEach(function (el) {
        el.oninput = function () { vh.calendar[+el.getAttribute('data-cl')].label = el.value; };
      });
      box.querySelectorAll('[data-cd]').forEach(function (el) {
        el.onchange = function () {
          var v = el.value;
          vh.calendar[+el.getAttribute('data-cd')].day = v === '' ? null : parseInt(v, 10);
        };
      });
      box.querySelectorAll('[data-cp]').forEach(function (el) {
        el.onchange = function () { vh.calendar[+el.getAttribute('data-cp')].placeId = el.value || null; };
      });
      box.querySelectorAll('[data-cdel]').forEach(function (el) {
        el.onclick = function () { vh.calendar.splice(+el.getAttribute('data-cdel'), 1); renderCal(); };
      });
    }

    renderPlaces();
    renderWorld();
    renderPeople();
    renderCal();

    function renderWorld() {
      var box = $('#vh-world', body);
      if (!box) return;
      var W = global.Worlds;
      if (!vh.worldId) {
        box.innerHTML = '<div class="hint">No world pack loaded. Add a pack to give them a real city to move through.</div>';
        return;
      }
      var pack = W && W.cached(vh.worldId);
      box.innerHTML = '<div class="hint">World: <b>' + esc(vh.worldId) + '</b> — ' +
        (pack ? pack.placeCount + ' places, ' + pack.routeCount +
                ' walking routes. Journeys take as long as they really take.'
              : 'journey times will be estimated until it loads.') +
        ' <button class="chip" id="vh-world-off">remove</button></div>';
      var off = $('#vh-world-off', box);
      if (off) off.onclick = function () {
        if (pack) W.remove(vh, pack); else vh.worldId = null;
        renderWorld(); renderPlaces(); renderCal();
        UI.toast('World pack removed');
      };
    }

    var worldBtn = $('#vh-world-pack', body);
    if (worldBtn) worldBtn.onclick = function () {
      var W = global.Worlds;
      if (!W) return UI.toast('World packs are not available in this build');
      W.available().then(function (packs) {
        if (!packs.length) return UI.toast('No world packs are installed');
        var p = packs[0];   /* one pack ships today; a picker if more arrive */
        var msg = p.description + ' That is ' + p.placeCount + ' places and ' +
          p.routeCount + ' walking routes. Their home and work are kept, and ' +
          'journeys take as long as the walk really takes. ' + (p.attribution || '');
        return UI.confirm('Load ' + p.name + '?', msg, { okLabel: 'Load' })
          .then(function (yes) {
            if (!yes) return;
            return W.load(p.id).then(function (pack) {
              var n = W.apply(vh, pack);
              renderWorld(); renderPlaces(); renderCal();
              UI.toast(n + ' places loaded');
            });
          });
      }).catch(function (e) {
        UI.toast(e && e.message ? e.message : 'Could not load that world pack');
      });
    };

    var addPlace = $('#vh-add-place', body);
    if (addPlace) addPlace.onclick = function () {
      vh.places.push({ id: VH.uid('p'), name: 'New place', kind: 'other', note: '' });
      renderPlaces(); renderCal();
    };
    var addPerson = $('#vh-add-person', body);
    if (addPerson) addPerson.onclick = function () {
      vh.people.push({ id: VH.uid('pe'), name: '', relation: '', closeness: 0.5, note: '' });
      renderPeople();
    };
    var addCal = $('#vh-add-cal', body);
    if (addCal) addCal.onclick = function () {
      vh.calendar.push({ id: VH.uid('ev'), label: '', t: '09:00', day: null, placeId: null });
      renderCal();
    };
    var burstEl = $('#vh-burst', body);
    if (burstEl) burstEl.oninput = function () {
      vh.burst = parseInt(burstEl.value, 10) || 1;
      var out = $('#vh-burst-v', body);
      if (out) out.textContent = vh.burst;
    };

    var vhOn = $('#vh-on', body);
    if (vhOn) vhOn.onclick = function () {
      vh.enabled = !vh.enabled;
      this.classList.toggle('on', vh.enabled);
      $('#vh-fields', body).hidden = !vh.enabled;
    };
    var istateOn = $('#t-istate', body);
    if (istateOn) istateOn.onclick = function () {
      draft.stateTracking = draft.stateTracking !== true;
      this.classList.toggle('on', draft.stateTracking);
      var f = $('#istate-fields', body);
      if (f) f.hidden = !draft.stateTracking;
    };
    var vhAdd = $('#vh-add', body);
    if (vhAdd) vhAdd.onclick = function () {
      vh.routine.push({ t: '12:00', a: '' });
      renderRoutine();
    };
    var vhAuto = $('#vh-auto', body);
    if (vhAuto) vhAuto.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      vh.autonomy = b.getAttribute('data-a');
      this.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
    };
    function bindRange(id, fn) {
      var el = $('#' + id, body);
      if (el) el.oninput = function () { fn(parseInt(el.value, 10)); };
    }
    bindRange('vh-dmin', function (v) { vh.replyDelay.min = v; updDelay(); });
    bindRange('vh-dmax', function (v) { vh.replyDelay.max = v; updDelay(); });
    function updDelay() {
      if (vh.replyDelay.max < vh.replyDelay.min) vh.replyDelay.max = vh.replyDelay.min;
      var el = $('#vh-dmin-v', body);
      if (el) el.textContent = vh.replyDelay.min + 's – ' + vh.replyDelay.max + 's';
    }
    var vhPhotos = $('#vh-photos', body);
    if (vhPhotos) vhPhotos.onclick = function () { vh.photos = !vh.photos; this.classList.toggle('on', vh.photos); };
    ['vh-mood', 'vh-aff', 'vh-trust', 'vh-ten'].forEach(function (id, i) {
      var el = $('#' + id, body);
      if (!el) return;
      el.oninput = function () {
        var v = parseInt(el.value, 10) / 100;
        if (id === 'vh-mood') vh.mood = v;
        if (id === 'vh-aff') vh.affinity = v;
        if (id === 'vh-trust') vh.trust = v;
        if (id === 'vh-ten') vh.tension = v;
        var out = $('#' + id + '-v', body);
        if (out) out.textContent = v.toFixed(2);
      };
    });
    var ss = $('#vh-sleep-start', body), se = $('#vh-sleep-end', body);
    if (ss) ss.onchange = function () { vh.sleep.start = ss.value || '23:00'; };
    if (se) se.onchange = function () { vh.sleep.end = se.value || '07:00'; };

    on(body, '[data-act=save]', 'click', function () {
      var c = collect();
      if (!c.name) { UI.toast('Give the character a name'); return; }
      App.saveCharacter(c);
    });
    on(body, '[data-act=delete]', 'click', function () {
      UI.confirm('Delete ' + (draft.name || 'character') + '?', 'All their chats and memories go too.',
        { danger: true, okLabel: 'Delete' }).then(function (ok) { if (ok) App.deleteCharacter(draft.id); });
    });
  };

  /* word-count under the alt pager: cheap, honest, testable */
  function altWordCount(t) {
    return String(t || '').trim().split(/\s+/).filter(Boolean).length;
  }
  Views.altWordCount = altWordCount;

  /* what the listener hears: markdown and directions stripped, just prose */
  function speechText(t) {
    return String(t || '')
      .replace(/!\[[^\]\]]*\]\([^)]*\)/g, ' ')      /* images */
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')        /* links keep their text */
      .replace(/[\*_`#>~]+/g, '')
      .replace(/https?:\/\/\S+/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }
  Views.speechText = speechText;

  /* ================= chat helpers ================= */
  function messageHtml(m, char, s) {
    var isMe = m.role === 'user';
    var who = isMe ? s.userName : char.name;
    var text = m.text || '';
    var body = m._stream !== undefined && m._stream !== null ? m._stream : text;
    return '<div class="msg' + (isMe ? ' me' : '') + (m.autonomous ? ' auto' : '') + '" data-mid="' + m.id + '">' +
      /* v1.31.0: the player's own bubble shows the active persona's photo
         when the persona has one, initials otherwise. */
      '<div class="av">' + (isMe
        ? avatarHtml(activePersonaAvatar(s), s.userName)
        : avatarHtml(char.avatar, char.name)) + '</div>' +
      '<div style="min-width:0;max-width:calc(100% - 44px)">' +
        '<div class="bubble">' +
          (!isMe ? '<div class="who">' + esc(who) + '</div>' : '') +
          '<div class="mtext">' + md(body) + '</div>' +
          (m.image ? '<img class="gen" src="' + esc(m.image) + '" alt="' + esc(m.imageCaption || 'image') + '" data-lightbox="' + esc(m.image) + '">' : '') +
          (m.imageCaption ? '<div class="imgcap">' + esc(m.imageCaption) + '</div>' : '') +
          (m.autonomous ? '<div class="auto-tag">· sent on their own</div>' : '') +
        '</div>' +
        '<div class="msg-actions">' +
          (isMe
            ? (m.retry ? '<button class="chip retry" data-act="retry">' + icon('refresh') + ' Retry</button>' : '') +
              '<button class="chip" data-act="edit">' + icon('edit') + ' Edit</button>' +
              '<button class="chip" data-act="del">' + icon('trash') + '</button>'
            : '<button class="chip" data-act="reroll">' + icon('refresh') + ' Reroll</button>' +
              '<button class="chip" data-act="rerollnote" title="Reroll with a steering note">' + icon('refresh') + '+📝</button>' +
              '<button class="chip" data-act="cont">Continue</button>' +
              '<button class="chip" data-act="say" title="Listen">' + icon('volume') + '</button>' +
              '<button class="chip" data-act="edit">' + icon('edit') + '</button>' +
              '<button class="chip" data-act="copy">' + icon('copy') + '</button>' +
              '<button class="chip" data-act="del">' + icon('trash') + '</button>') +
        '</div>' +
        ((m.alts && m.alts.length > 1)
          ? '<div class="swipe">' +
            '<button data-act="swipe" data-dir="-1"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button>' +
            '<span>' + ((m.altIdx || 0) + 1) + ' / ' + m.alts.length + '</span>' +
            '<span class="swipe-words">' + altWordCount(m.alts[m.altIdx || 0] || '') + ' words</span>' +
            '<button data-act="swipe" data-dir="1"><svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>' +
            '</div>'
          : '') +
      '</div>' +
    '</div>';
  }

  /* Follow the bottom only when the user is already there (within 260px) —
     or when told to. Scrolling up to read a reply must not be fought by
     incoming text: that is what made a finished reply yank the view to the
     last word. */
  function stickToBottom(thread, force) {
    if (!thread) return false;
    if (force || thread.scrollHeight - thread.scrollTop - thread.clientHeight < 260) {
      thread.scrollTop = thread.scrollHeight;
      return true;
    }
    return false;
  }
  Views.stickToBottom = stickToBottom;

  /* 18.2.0: a re-render must not fling the reader. Anchor on the first
     message in view (and how far down into it) and restore after the
     rebuild; if that message was just deleted, its predecessor stands in.
     Fresh opens (forceBottom) still land on the last message. Pure over
     plain child objects so it is unit-testable. */
  Views.threadAnchor = function (children, scrollTop) {
    var y = scrollTop || 0;
    var prev = null;
    for (var i = 0; i < children.length; i++) {
      var el = children[i];
      if (el.offsetTop + el.offsetHeight > y) {
        return {
          mid: el.getAttribute ? el.getAttribute('data-mid') : null,
          dy: Math.max(0, y - el.offsetTop),
          prev: prev
        };
      }
      if (el.getAttribute) prev = el.getAttribute('data-mid');
    }
    return null; /* scrolled past the last message — stick to bottom instead */
  };

  Views.restoreThreadScroll = function (thread, anchor) {
    if (!anchor) return false;
    var el = anchor.mid ? thread.querySelector('[data-mid="' + anchor.mid + '"]') : null;
    var usedPrev = false;
    if (!el && anchor.prev) { el = thread.querySelector('[data-mid="' + anchor.prev + '"]'); usedPrev = true; }
    if (!el) return false;
    /* When the fallback predecessor stands in, land at its top, not mid-line. */
    thread.scrollTop = Math.max(0, el.offsetTop - (usedPrev ? 0 : (anchor.dy || 0)));
    return true;
  };

  /* v1.13.0 — the internal-state strip at the top of a chat. Collapsed:
     one line (mood is the headline). Expanded: the three fields plus an
     edit button. Shown only for characters with tracking on; virtual
     humans keep their own simulation-driven Inner state instead. */
  function stateStrip(char) {
    var el = $('#char-state');
    if (!el) return;
    var on = !!(char && char.stateTracking === true && !char.vh);
    if (!on) { el.hidden = true; el.innerHTML = ''; return; }
    var st = char.state || {};
    var any = st.mood || st.intent || st.flags;
    var open = el._open;
    el.hidden = false;
    el.innerHTML =
      '<button class="cs-head' + (open ? ' open' : '') + '" data-act="cs-toggle">' +
        '<span class="cs-lbl">State</span>' +
        '<span class="cs-preview">' + esc(st.mood || (any ? (st.intent || st.flags) : 'not set yet')) + '</span>' +
        '<svg class="cs-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>' +
      '</button>' +
      '<div class="cs-body"' + (open ? '' : ' hidden') + '>' +
        (st.mood ? '<div class="cs-row"><span class="cs-k">mood</span><span>' + esc(st.mood) + '</span></div>' : '') +
        (st.intent ? '<div class="cs-row"><span class="cs-k">intent</span><span>' + esc(st.intent) + '</span></div>' : '') +
        (st.flags ? '<div class="cs-row"><span class="cs-k">flags</span><span>' + esc(st.flags) + '</span></div>' : '') +
        (any ? '' : '<div class="hint" style="margin:0 0 6px">The model will fill this in with the next reply — or set it yourself.</div>') +
        '<button class="btn ghost sm block" data-act="cs-edit">' + icon('edit') + ' Edit state</button>' +
      '</div>';
    el.querySelector('[data-act="cs-toggle"]').onclick = function () {
      open = !open;
      el._open = open;
      el.querySelector('.cs-body').hidden = !open;
      this.classList.toggle('open', open);
    };
    el.querySelector('[data-act="cs-edit"]').onclick = function () { App.editCharState(char); };
  }

  Views.thread = function (char, session, messages, streamingId, forceBottom) {
    var s = Store.settings;
    var thread = $('#thread');
    var anchor = (!forceBottom && thread.children && thread.children.length)
      ? Views.threadAnchor(thread.children, thread.scrollTop)
      : null;
    thread.innerHTML = messages.map(function (m) {
      if (m.id === streamingId) m._stream = m._stream || '';
      return messageHtml(m, char, s);
    }).join('');
    var st = thread.querySelector('.msg.streaming .mtext') ||
      (streamingId ? thread.querySelector('[data-mid="' + streamingId + '"] .mtext') : null);
    if (stickToBottom(thread, forceBottom || !!streamingId)) {
      /* Re-pin when each image below the fold lands - for a forced open AND
         a natural near-bottom pin - but never yank a reader who has already
         scrolled up to read something. */
      if (thread.querySelectorAll) {
        var imgs = thread.querySelectorAll('img');
        for (var ii = 0; ii < imgs.length; ii++) (function (im) {
          if (im.complete) return;
          im.addEventListener('load', function () {
            if (thread.scrollHeight - thread.scrollTop - thread.clientHeight < 160) thread.scrollTop = thread.scrollHeight;
          }, { once: true });
        })(imgs[ii]);
      }
    } else if (anchor) {
      /* Re-render (delete / edit / swipe) while the reader was mid-thread:
         put them back where they were. */
      Views.restoreThreadScroll(thread, anchor);
      /* The first layout pass measures a thread whose avatars/inline images
         have not loaded yet, so the restored position is too high and the
         reader is left stranded up the thread (accept an edit → the view
         jumps up). Once the still-loading images settle, re-apply the
         anchor — the same re-jump the fresh-open path already performs —
         unless the reader has moved on their own in the meantime. */
      var pendingImgs = [];
      var allImgs = thread.querySelectorAll ? thread.querySelectorAll('img') : [];
      for (var pi = 0; pi < allImgs.length; pi++) if (allImgs[pi] && !allImgs[pi].complete) pendingImgs.push(allImgs[pi]);
      if (pendingImgs.length) {
        var settled = false;
        var appliedPos = thread.scrollTop;
        var reapply = function () {
          if (settled) return;
          settled = true;
          if (Math.abs(thread.scrollTop - appliedPos) < 60) Views.restoreThreadScroll(thread, anchor);
        };
        var remaining = pendingImgs.length;
        for (var pj = 0; pj < pendingImgs.length; pj++) (function (im) {
          var one = function () { if (--remaining === 0) reapply(); };
          im.addEventListener('load', one, { once: true });
          im.addEventListener('error', one, { once: true });
        })(pendingImgs[pj]);
        /* a broken or slow image never fires: settle on a timer anyway */
        setTimeout(reapply, 800);
      }
    }
    return st;
  };

  Views.appendMessage = function (char, m) {
    var thread = $('#thread');
    var wrap = document.createElement('div');
    wrap.innerHTML = messageHtml(m, char, Store.settings);
    var el = wrap.firstElementChild;
    thread.appendChild(el);
    stickToBottom(thread, false);
    return el;
  };

  Views.pickFile = pickFile;
  Views.fileToDataUrl = fileToDataUrl;
  /* Cards can carry several starting scenarios (scenario_list). The editor
     shows a picker chip only when there is more than one to choose from. */
  Views.scenarioChip = function (list) {
    if (!list || list.length < 2) return '';
    return '<button class="chip" data-act="scenarios">Card scenarios (' + list.length + ')</button>';
  };
  Views.stateStrip = stateStrip;
  Views.normalizeImage = normalizeImage;
  Views.normalizeDataUrl = normalizeDataUrl;
  Views.normalizeCardImages = normalizeCardImages;
  /* v1.30.0: the same diet, by itself — a world's banner gets it on import */
  Views.dietDataUrl = normalizeDataUrl;
  Views.imageTargetSize = imageTargetSize;
  Views.imageMime = imageMime;
  Views.initials = initials;
  Views.avatarHtml = avatarHtml;
  Views.activePersonaAvatar = activePersonaAvatar;
  Views.personaRowsHtml = personaRowsHtml;
  Views.messageHtml = messageHtml;

  /* ================= AUTHORED WORLDS ================= */
  /* Upstream .horde_world files: a place with streets and rooms, a cast,
     factions, lore and a set of rules. Artwork is stripped on import, so a
     2.5 MB world arrives at about 50 KB. */

  function worldBubble(m, world) {
    /* a player correction is a ledger note, not a line of dialogue */
    if (m.role === 'correction') {
      return '<div class="wr-note">' + esc(m.content || '') + '</div>';
    }
    /* the world's verdict on a check - compact, tinted by outcome */
    if (m.role === 'check') {
      var win = m.content.indexOf('\u2014 success') !== -1;
      return '<div class="wr-check-line' + (win ? ' ok' : ' fail') + '">' + esc(m.content || '') + '</div>';
    }
    var isMe = m.role === 'user';
    var who = isMe ? (Store.settings.userName || 'You') : (world.name || 'Referee');
    /* v1.35.1: the thread wears faces, like the persona chat - the referee
       bubble carries the world's banner, the player's bubble the active
       persona's photo when it has one. Initials when a face was never set. */
    var av = isMe
      ? avatarHtml(activePersonaAvatar(Store.settings), who)
      : avatarHtml((world && world.banner) || '', who);
    return '<div class="msg' + (isMe ? ' me' : '') + '">' +
      '<div class="av">' + av + '</div>' +
      '<div style="min-width:0;max-width:calc(100% - 44px)">' +
        '<div class="bubble">' +
          (!isMe ? '<div class="who">' + esc(who) + '</div>' : '') +
          '<div class="mtext">' + md(m.content || '') + '</div>' +
        '</div>' +
      '</div></div>';
  }

  /* The sheet folds. A world with many stats (a job grid, say) would otherwise
     render a HUD taller than several phone screens and bury the input under it
     - one line always shows (place, time, purse, tasks, what just changed) and
     the rest sits behind a tap. */
  var wrHudOpen = false;
  Views.wrHudOpen = function (v) { if (v === undefined) return wrHudOpen; wrHudOpen = !!v; };

  /* Time, stats, purse, pockets and tasks - whatever the world switches on.
     The third argument is the applied turn ({changes, rejections}) or a plain
     changes array. */
  Views.worldHud = function (world, run, applied) {
    var changes = applied && !Array.isArray(applied) ? applied.changes : applied;
    var rejections = applied && !Array.isArray(applied) ? applied.rejections : null;
    var advisories = applied && !Array.isArray(applied) ? applied.advisories : null;
    var checks = applied && !Array.isArray(applied) ? applied.checks : null;
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var loc = HW.location(world, run.locationId);
    var stats = hud.stats || [];

    var sheet = '';
    var vitalId = (HW.vitalStat && HW.vitalStat(world)) || null;
    stats.forEach(function (st) {
      var v = run.stats[st.id];
      if (v === undefined) return;
      /* v1.34.0: the vital stat wears its mark on the sheet too */
      sheet += '<span>' + esc(st.name) + (vitalId === st.id ? ' ✧' : '') + ' <b>' +
             esc(String(v)) + '</b>' +
             (st.max ? '/' + esc(String(st.max)) : '') + '</span>';
    });
    if ((gr.modules || {}).inventory !== false && run.inventory && run.inventory.length) {
      sheet += '<span>' + esc(run.inventory.join(', ')) + '</span>';
    }
    /* v1.34.0: conditions as sheet chips, and the floor shows itself */
    if ((gr.modules || {}).conditions && run.conditions && run.conditions.length) {
      run.conditions.forEach(function (c) { sheet += '<span class="ws-cond">' + esc(c) + '</span>'; });
    }
    if (run.downed) sheet += '<span class="ws-cond"><b>downed</b></span>';
    /* v1.35.0: worn things, named with their pockets */
    if ((gr.modules || {}).equipment && run.equip && HW.equipmentSlots) {
      HW.equipmentSlots(world).forEach(function (s) {
        if (run.equip[s]) sheet += '<span>' + esc(run.equip[s]) + ' <i>(' + esc(s) + ')</i></span>';
      });
    }

    var head = '<span class="wr-at">' + esc(loc ? loc.name : 'Somewhere') + '</span>';
    if (hud.showClock !== false) {
      head += '<span><b>' + esc(HW.clockOf(run, hud).text) + '</b> · turn ' + (run.turn || 0) + '</span>';
    }
    if ((gr.modules || {}).commerce !== false && run.stats[run.cashId] !== undefined) {
      head += '<span><b>' + esc(String(run.stats[run.cashId])) + '</b> ' +
             esc(gr.currencyName || 'cash') + '</span>';
    }
    /* v1.39.5: the open-task ledger is folded by hand on small screens -
       a pill in the head folds it away, and the fold is remembered ON the
       run (run.hudTasksOpen), so a phone stays readable across sessions.
       Old runs carry no marker and read open, exactly as before. */
    var openQuests = [];
    if ((gr.modules || {}).quests !== false) {
      openQuests = (run.quests || []).filter(function (q) { return !q.done; });
    }
    var tasksOpen = run.hudTasksOpen !== false;
    if (openQuests.length) {
      head += '<button type="button" class="wr-hud-fold" data-act="wr-hud-fold" ' +
        'title="Show or hide the open tasks">' + esc(String(openQuests.length)) +
        ' tasks ' + (tasksOpen ? '\u25be' : '\u25b8') + '</button>';
    }

    var collapsible = stats.length > 6;
    if (collapsible) {
      head += '<button type="button" class="wr-hud-toggle" data-act="wr-hud-toggle">' +
             (wrHudOpen ? 'hide sheet' : 'sheet (' + stats.length + ')') + '</button>';
    }
    head += '<button type="button" class="wr-correct-btn" data-act="wr-correct" ' +
      'title="Set the clock, purse, stats, pockets or tasks by hand">correct state</button>';

    var out = '<div class="wr-hud-row">' + head + '</div>';
    if (openQuests.length) {
      out += '<div class="wr-hud-tasks"' + (tasksOpen ? '' : ' hidden') + '>' +
        'tasks: ' + esc(openQuests.map(function (q) { return q.text; }).join('; ')) + '</div>';
    }
    if (sheet) {
      out += '<div class="wr-hud-more"' + (collapsible && !wrHudOpen ? ' hidden' : '') + '>' + sheet + '</div>';
    }
    if (changes && changes.length) {
      out += '<div class="wr-changes">' + changes.map(function (c) {
        return '<span class="chip">' + esc(c) + '</span>';
      }).join('') + '</div>';
    }
    if (checks && checks.length) {
      out += '<div class="wr-changes">' + checks.map(function (c) {
        return '<span class="chip wr-check-chip' + (c.success ? ' ok' : ' fail') + '">' + esc(c.chip) + '</span>';
      }).join('') + '</div>';
    }
    if (rejections && rejections.length) {
      /* the world said no to some of the referee's bookkeeping - show the
         player what was refused, so a stuck scene is diagnosable */
      out += '<div class="wr-rejections">' + rejections.map(function (r) {
        return '<div class="wr-rej">rejected: ' + esc(r.tag) + ' \u2014 ' + esc(r.reason) + '</div>';
      }).join('') + '</div>';
    }
    if (advisories && advisories.length) {
      /* v1.20.0 - scene discipline: the player asked for something the
         ledger never recorded. Softer than a rejection - the story may be
         right and the tags wrong, or the ask may have failed in prose */
      out += '<div class="wr-advisories">' + advisories.map(function (a) {
        return '<div class="wr-adv">not recorded: ' + esc(a.claim) + ' \u2014 ' + esc(a.note) + '</div>';
      }).join('') + '</div>';
    }
    return out;
  };

  /* Flip the folded sheet in place - no re-render, so the change chips
     from the last turn stay visible. */
  Views.bindWorldHud = function (hud, world, run) {
    on(hud, '[data-act=wr-hud-toggle]', 'click', function () {
      wrHudOpen = !wrHudOpen;
      var more = hud.querySelector('.wr-hud-more');
      if (more) more.hidden = !wrHudOpen;
      var btn = hud.querySelector('[data-act=wr-hud-toggle]');
      if (btn) btn.textContent = wrHudOpen ? 'hide sheet' :
        'sheet (' + ((world.hudConfig || {}).stats || []).length + ')';
    });
    /* v1.39.5: fold the task ledger - the choice travels with the run. */
    on(hud, '[data-act=wr-hud-fold]', 'click', function () {
      if (!run) return;
      var openNow = run.hudTasksOpen !== false;
      run.hudTasksOpen = !openNow;
      var tbox = hud.querySelector('.wr-hud-tasks');
      if (tbox) tbox.hidden = !run.hudTasksOpen;
      var fbtn = hud.querySelector('[data-act=wr-hud-fold]');
      if (fbtn) fbtn.textContent = fbtn.textContent
        .replace(/[\u25b8\u25be]/, run.hudTasksOpen ? '\u25be' : '\u25b8');
      if (HW.saveRun) HW.saveRun(run);
    });
    on(hud, '[data-act=wr-correct]', 'click', function () {
      /* v1.21.0 (upstream 18.3.5): opening the correct-state screen is fine,
         but a turn applying tags is mutating the same run object — wait. */
      if (App.state.worldBusy) return UI.toast('Wait for the current turn to finish');
      if (App.state.worldRun) App.go('worldcorrect');
    });
  };

  /** v1.25.0: the whole run, in a sheet - the phone's answer to the desktop
     sidebar. Everything the HUD knows, always expanded: place and exits,
     time, numbers, purse, pockets, tasks, and the party. */
  /** v1.26.0: Settings → Appearance. One row per theme — a strip of the
     theme's own colors, the name, and an "on" mark on the current pick.
     Tapping applies in place and persists. */
  Views.settingsAppearance = function () {
    var body = $('#settings-x-body');
    var cur = (Store.settings && Store.settings.theme) || 'midnight';
    var h = '<p class="hint" style="margin:0 0 10px">The whole app re-colors in place. The pick is saved on this phone.</p>';
    THEMES.list().forEach(function (id) {
      var t = THEMES.get(id), tk = t.tokens;
      h += '<div class="theme-row' + (id === cur ? ' on' : '') + '" data-th="' + id + '">' +
        '<span class="theme-dots">' +
          '<i style="background:' + tk['--bg'] + '"></i>' +
          '<i style="background:' + tk['--surface'] + '"></i>' +
          '<i style="background:' + tk['--accent'] + '"></i>' +
          '<i style="background:' + tk['--accent-2'] + '"></i>' +
          '<i style="background:' + tk['--text'] + '"></i>' +
        '</span>' +
        '<span class="theme-name">' + esc(t.name) + '</span>' +
        (id === cur ? '<span class="pill theme-check">on</span>' : '') +
        '</div>';
    });
    body.innerHTML = h;
    (body.querySelectorAll ? body.querySelectorAll('[data-th]') : []).forEach(function (row) {
      row.onclick = function () {
        App.chooseTheme(row.getAttribute('data-th')).then(function () {
          Views.settingsAppearance();       /* move the "on" mark */
        });
      };
    });
  };

  /* v1.35.0: a look inside a world before you live in it. Read-only - the
     same parsed truth the referee runs on, shaped for a person's eyes. */
  /* v1.37.0: name a gate without opening it */
  function worldFactionName(world, id) {
    var f = (world.factions || []).find(function (x) { return x.id === id; });
    return (f && f.name) || id;
  }
  function worldNpcName(world, ref) {
    var low = String(ref || '').toLowerCase();
    var n = (world.entities || []).find(function (e) {
      return String(e.id).toLowerCase() === low || String(e.name).toLowerCase() === low;
    });
    return (n && n.name) || ref;
  }

  Views.worldSummary = function (world) {
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var h = '';
    h += '<div class="ws-head">' + avatarHtml(world.banner, world.name) +
         '<div class="ws-head-name">' + esc(world.name) + '</div></div>';
    if (world.description) h += '<div class="hint">' + esc(world.description) + '</div>';

    h += '<h3>The clock</h3>';
    var hh = ('0' + (hud.startTimeHours || 8)).slice(-2), mm = ('0' + (hud.startTimeMinutes || 0)).slice(-2);
    h += '<div class="hint">Begins ' + esc((hud.startWeekday || 'Monday')) + ' ' + hh + ':' + mm +
         ' · ' + (hud.timeStep || 5) + ' minutes a turn</div>';

    var mods = gr.modules || {};
    var on = Object.keys(mods).filter(function (k) { return !!mods[k]; });
    if (on.length) h += '<div class="hint">Systems: ' + esc(on.join(', ')) + '</div>';

    h += '<h3>Places</h3>';
    h += (world.locations || []).map(function (l) {
      return '<div class="ws-item">' + esc(l.name) +
             ' <span class="hint">' + esc(l.mapType || 'room') + '</span></div>';
    }).join('');

    h += '<h3>People</h3>';
    h += (world.entities || []).map(function (e) {
      var day = (e.schedule || []).length;
      return '<div class="ws-item"><b>' + esc(e.name) + '</b>' +
        (e.persona ? ' <span class="hint">' + esc(HW.synopsis(e.persona, 140)) + '</span>' : '') +
        (e.goal ? '<div class="hint">wants: ' + esc(e.goal) + '</div>' : '') +
        (day ? '<div class="hint">a ' + day + '-stop day</div>' : '') +
        '</div>';
    }).join('');

    if ((world.factions || []).length) {
      h += '<h3>Factions</h3>';
      h += world.factions.map(function (f) {
        return '<div class="ws-item"><b>' + esc(f.name) + '</b>' +
               (f.goal ? ' <span class="hint">' + esc(HW.synopsis(f.goal, 120)) + '</span>' : '') + '</div>';
      }).join('');
    }

    /* v1.37.0, the open book: a peek tells you the book exists - keys and
       gates visible, secret entries sealed so the story is never spoiled;
       a keyword the world itself never says is hinted, not hidden. */
    var book = world.lorebook || [];
    if (book.length) {
      h += '<h3>The known book</h3>';
      h += book.map(function (entry) {
        var kb = String(entry.knownBy || '').toLowerCase().trim();
        var row = '<div class="ws-item"><b>' + esc(entry.keyword || '(no keyword)') + '</b>';
        if (kb === 'secret') {
          var hinges = [];
          if (entry.unlockQuest) hinges.push('a task reaching «' + entry.unlockQuest + '»');
          if (entry.unlockNpc) hinges.push(worldNpcName(world, entry.unlockNpc) + ' being here');
          row += ' <span class="hint">sealed - ' +
            (hinges.length ? 'opens with ' + esc(hinges.join('; '))
                           : 'nothing that opens it is named') + '</span>';
        } else {
          if (kb.indexOf('faction:') === 0) {
            row += ' <span class="hint">known inside ' + esc(worldFactionName(world, kb.slice(8).trim())) + '</span>';
          } else if (kb.indexOf('npc:') === 0) {
            row += ' <span class="hint">speaks near ' + esc(worldNpcName(world, kb.slice(4).trim())) + '</span>';
          } else if (kb && kb !== 'anyone') {
            row += ' <span class="hint">known by ' + esc(entry.knownBy) + '</span>';
          }
          if (HW.deadKey && HW.deadKey(world, entry)) {
            row += ' <span class="hint" style="opacity:.7">never said anywhere in the world itself - this key may go unheard</span>';
          }
          if (entry.text) row += ' <span class="hint">' + esc(HW.synopsis(entry.text, 140)) + '</span>';
        }
        return row + '</div>';
      }).join('');
    }

    /* v1.38.0: the classes page - bundles are chosen openly at begin, so
       the peek says what each brings. No secrets here. */
    if ((world.classes || []).length) {
      h += '<h3>Classes</h3>';
      h += world.classes.map(function (c) {
        var sk = (c.skills || []).map(function (id) {
          var s = null;
          (world.skillsCatalog || []).forEach(function (t) { if (t.id === id) s = t; });
          return (s && s.name) || id;
        });
        return '<div class="ws-item"><b>' + esc(c.name) + '</b>' +
          (c.description ? ' <span class="hint">' + esc(HW.synopsis(c.description, 120)) + '</span>' : '') +
          (sk.length ? '<div class="hint">brings: ' + esc(sk.join(', ')) + '</div>' : '') +
          (c.outfit ? '<div class="hint">wears: ' + esc(c.outfit) + '</div>' : '') + '</div>';
      }).join('');
    }

    if ((world.startingLives || []).length) {
      h += '<h3>Ways to begin</h3>';
      h += world.startingLives.map(function (l) {
        return '<div class="ws-item">' + esc(l.name) +
               (l.role ? ' <span class="hint">' + esc(l.role) + '</span>' : '') + '</div>';
      }).join('');
    }

    h += '<h3>Under the hood</h3>';
    h += '<div class="hint">' +
      (world.locations || []).length + ' places · ' +
      (world.entities || []).length + ' people · ' +
      ((world.factions || []).length) + ' factions · ' +
      ((world.relationships || []).length) + ' ties · ' +
      ((world.lorebook || []).length) + ' lore, ' +
      ((hud.stats || []).length) + ' numbers tracked' +
      (((gr.checks || []).length) ? ' · ' + gr.checks.length + ' named checks' : '') +
      '</div>';
    return h;
  };

  Views.worldStatusSheet = function (world, run) {
    var gr = world.gameRules || {}, hud = world.hudConfig || {};
    var loc = HW.location(world, run.locationId);
    var stats = hud.stats || [];

    var h = '';
    /* v1.30.0: the world's face, the same banner the PC version shows */
    h += '<div class="ws-head">' + avatarHtml(world.banner, world.name) +
         '<div class="ws-head-name">' + esc(world.name) + '</div></div>';
    h += '<h3>Where you are</h3>';
    h += '<div class="ws-loc">' + esc(loc ? loc.name : 'Somewhere') + '</div>';
    var ex = HW.exits(world, run.locationId) || [];
    h += ex.length
      ? '<div class="hint">You can go: ' + esc(ex.map(function (e) {
          return String(e.text || e.to || '').replace(/^to\s+/i, '');
        }).join(', ')) + '</div>'
      : '<div class="hint">The world has not said where you can go yet.</div>';

    h += '<h3>Time</h3>';
    h += '<div class="ws-time">' + (hud.showClock !== false ? esc(HW.clockOf(run, hud).text) + ' · ' : '') +
         'turn ' + (run.turn || 0) + '</div>';
    /* v1.32.0: the calendar the world declares, and who you set out to be */
    var wsSeas = HW.seasonText(world, run);
    if (wsSeas) h += '<div class="hint">Season: ' + esc(wsSeas) + '</div>';
    if (run.identity) h += '<div class="hint">You are: ' + esc(run.identity) + '</div>';
    if (run.outfit) h += '<div class="hint">Wearing: ' + esc(run.outfit) + '</div>';
    /* v1.34.0: the floor is not a number to glance past - it changes what
       the next scene is about */
    if (run.downed) h += '<div class="hint"><b>Downed</b> — the next scene starts from consequences, not game over.</div>';
    /* v1.29.1: the referee's receipt - which Horde model actually answered
       the last turn, and the worker it ran on. "Requested" is a setting;
       this is what came back. */
    if (run.lastModel) {
      h += '<div class="hint">Referee: ' + esc(run.lastModel) +
           (run.lastWorker ? ' · worker ' + esc(String(run.lastWorker).slice(0, 12)) : '') + '</div>';
    }

    h += '<h3>Numbers</h3>';
    var anyStat = false;
    var wsVital = (HW.vitalStat && HW.vitalStat(world)) || null;
    stats.forEach(function (st) {
      var v = run.stats[st.id];
      if (v === undefined) return;
      anyStat = true;
      /* v1.34.0: the vital stat's mark, even on the big sheet */
      h += '<div class="ws-stat"><span>' + esc(st.name) + (wsVital === st.id ? ' ✧' : '') + '</span><b>' +
           esc(String(v)) +
           (st.max ? '/' + esc(String(st.max)) : '') + '</b></div>';
    });
    if ((gr.modules || {}).commerce !== false && run.stats[run.cashId] !== undefined) {
      anyStat = true;
      h += '<div class="ws-stat"><span>' + esc(gr.currencyName || 'Cash') + '</span><b>' +
           esc(String(run.stats[run.cashId])) + '</b></div>';
    }
    if (!anyStat) h += stats.length
      ? '<div class="hint">This world keeps ' + stats.length + ' number' + (stats.length === 1 ? '' : 's') + ', but the referee has not reported a value for any of them yet.</div>'
      : '<div class="hint">This world keeps no numbers — its rules declare no tracked stats.</div>';

    /* v1.34.0: conditions get their own corner of the sheet, and the floor
       is announced where the clock lives. */
    if ((gr.modules || {}).conditions) {
      h += '<h3>Conditions</h3>';
      h += (run.conditions && run.conditions.length)
        ? run.conditions.map(function (c) { return '<div class="ws-item">' + esc(c) + '</div>'; }).join('')
        : '<div class="hint">None, for the moment.</div>';
    }

    if ((gr.modules || {}).inventory !== false) {
      h += '<h3>Pockets</h3>';
      h += (run.inventory && run.inventory.length)
        ? run.inventory.map(function (it) { return '<div class="ws-item">' + esc(it) + '</div>'; }).join('')
        : '<div class="hint">Empty.</div>';
    }

    /* v1.35.0: equipment on the big sheet, slot by slot, in the order the
       world declared the slots */
    if ((gr.modules || {}).equipment && HW.equipmentSlots) {
      h += '<h3>Equipment</h3>';
      var slots = HW.equipmentSlots(world), worn = [];
      slots.forEach(function (s) {
        if (run.equip && run.equip[s]) worn.push([s, run.equip[s]]);
      });
      h += worn.length
        ? worn.map(function (pair) {
            return '<div class="ws-item">' + esc(pair[1]) + ' <span class="hint">(' + esc(pair[0]) + ')</span></div>';
          }).join('')
        : '<div class="hint">Nothing equipped.</div>';
    }

    if ((gr.modules || {}).quests !== false) {
      var all = run.quests || [];
      var open = all.filter(function (q) { return !q.done; });
      h += '<h3>Tasks</h3>';
      h += open.length
        ? open.map(function (q) { return '<div class="ws-item">' + esc(q.text) + '</div>'; }).join('')
        : '<div class="hint">Nothing to do right now.</div>';
      if (all.length - open.length) h += '<div class="hint">' + (all.length - open.length) + ' finished.</div>';
    }

    /* v1.24.0 companion ledger - the party, and where they joined */
    var party = run.companions || [];
    h += '<h3>Party</h3>';
    h += party.length
      ? party.map(function (c) {
          var at = HW.location(world, c.at);
          return '<div class="ws-item">' + esc(c.name) +
                 (at ? ' <span class="hint">(joined at ' + esc(at.name) + ', turn ' + (c.since || 0) + ')</span>' : '') +
                 '</div>';
        }).join('')
      : '<div class="hint">No one is with you right now.</div>';

    return h;
  };

  Views.worldRun = function (world, run, changes) {
    var hud = $('#wr-hud'), thread = $('#wr-thread');
    if (hud) {
      hud.hidden = false;
      hud.innerHTML = Views.worldHud(world, run, changes);
      Views.bindWorldHud(hud, world, run);
    }
    if (!thread) return;
    thread.innerHTML = (run.log || []).map(function (m) { return worldBubble(m, world); }).join('');
    if (changes) {
      /* v1.24.2: a finished turn is a whole scene that appears at once, and
         the old scroll-to-bottom stranded the reader at the END of it -
         back up they had to go to read the beginning. Anchor at the top of
         the reply that just arrived (the last non-player message). Check
         lines and correction notes after the reply don't move the anchor.
         Opening a run and sending a message still land at the bottom. */
      var reply = null, kids = thread.children || [];
      for (var i = kids.length - 1; i >= 0; i--) {
        var k = kids[i];
        if (k && k.classList && k.classList.contains('msg') && !k.classList.contains('me')) { reply = k; break; }
      }
      thread.scrollTop = reply ? reply.offsetTop : thread.scrollHeight;
      return;
    }
    thread.scrollTop = thread.scrollHeight;
  };

  /* v1.17.0: the ledger can be set straight by hand. Every applied change
     is logged into the run as a correction, so the referee's next prompt
     carries the truth, not the story. */
  Views.worldCorrect = function (root) {
    var world = App.state.world, run = App.state.worldRun;
    /* v1.27.1: the body div lives in its own <section>. The root that
       arrives here is the FIRST .screen in the DOM, where the div is not
       - resolving it against root rendered a blank screen on the device.
       Every other view resolves its container by id, so do that. */
    var body = $('#world-correct-body');
    if (!body) return;
    if (!world || !run) {
      body.innerHTML = '<p class="hint">No run to correct.</p>';
      return;
    }

    var hud = world.hudConfig || {}, gr = world.gameRules || {};
    var cur = HW.location(world, run.locationId);
    var reachableIds = {};
    (HW.exits(world, run.locationId) || []).forEach(function (e) {
      if (e.to) reachableIds[e.to] = true;
    });
    reachableIds[run.locationId] = true;

    var inv = (run.inventory || []).slice();
    var quests = (run.quests || []).map(function (q) { return { text: q.text, done: !!q.done }; });
    /* v1.28.0: the party, editable by hand (names only; the ledger keeps
       where/when, and the referee keeps talking as if it were true). */
    var party = (run.companions || []).map(function (c) { return c.name; });

    var h = '<div class="group">';
    h += '<h3>Where you are</h3>';
    h += '<div class="field"><select id="wc-loc">';
    (world.locations || []).forEach(function (l) {
      h += '<option value="' + esc(l.id) + '"' + (l.id === run.locationId ? ' selected' : '') + '>' +
        esc(l.name) + (l.id === run.locationId ? ' (here)' : '') + '</option>';
    });
    h += '</select></div><p class="hint" id="wc-loc-hint"></p>';

    h += '<h3>Numbers</h3>';
    h += '<div class="field"><label class="lbl">' + esc(gr.currencyName || 'Cash') + '</label>' +
      '<input id="wc-cash" type="number" step="1" value="' +
      (run.stats[run.cashId] !== undefined ? run.stats[run.cashId] : 0) + '"></div>';
    (hud.stats || []).forEach(function (st) {
      h += '<div class="field"><label class="lbl">' + esc(st.name) + '</label>' +
        '<input id="wc-stat-' + esc(st.id) + '" type="number" step="1" value="' +
        (run.stats[st.id] !== undefined ? run.stats[st.id] : 0) + '"></div>';
    });

    /* v1.29.1: the clock by hand - a shift in minutes for a run whose
       [[clock:+N]] tags have drifted from the story */
    h += '<h3>Time</h3>' +
      '<div class="field row"><input id="wc-clock" type="number" step="5" placeholder="Shift the clock by minutes (e.g. -30)">' +
      '<button class="btn sm" id="wc-clock-go">Shift</button></div>' +
      '<p class="hint">Applied with the corrections below; the shift is logged in the run.</p>';

    h += '<h3>Pockets</h3><div class="wc-inv" id="wc-inv"></div>' +
      '<div class="field row"><input id="wc-item" type="text" placeholder="Add an item…">' +
      '<button class="btn sm" id="wc-item-add">Add</button></div>';

    h += '<h3>Party</h3><div class="wc-inv" id="wc-party"></div>' +
      '<div class="field row"><input id="wc-companion" type="text" placeholder="Add a companion… (any name the story uses)">' +
      '<button class="btn sm" id="wc-companion-add">Add</button></div>';

    h += '<h3>Tasks</h3><div id="wc-quests"></div>' +
      '<div class="field row"><input id="wc-quest" type="text" placeholder="Add a task…">' +
      '<button class="btn sm" id="wc-quest-add">Add</button></div>';

    h += '<p class="hint">The referee is told nothing about how the state was ' +
      'reached \u2014 it simply continues from it. Corrections are kept in the ' +
      'run\u2019s log.</p>' +
      '<button class="btn" id="wc-save">Apply corrections</button></div>';

    body.innerHTML = h;

    function renderInv() {
      body.querySelector('#wc-inv').innerHTML = inv.length ? inv.map(function (it, i) {
        return '<span class="chip wc-chip">' + esc(it) +
          '<button type="button" class="wc-x" data-wc-drop="' + i + '" aria-label="Remove ' + esc(it) + '">\u00D7</button></span>';
      }).join('') : '<p class="hint">Nothing to remove.</p>';
    }
    function renderParty() {
      body.querySelector('#wc-party').innerHTML = party.length ? party.map(function (nm, i) {
        return '<span class="chip wc-chip">' + esc(nm) +
          '<button type="button" class="wc-x" data-wc-comp="' + i + '" aria-label="Remove ' + esc(nm) + '">\u00D7</button></span>';
      }).join('') : '<p class="hint">No one is with you.</p>';
    }
    function renderQuests() {
      body.querySelector('#wc-quests').innerHTML = quests.length ? quests.map(function (q) {
        var rm = '<button type="button" class="btn sm ghost" data-wc-remove="' + esc(q.text) + '">Remove</button>';
        return q.done
          ? '<div class="wc-quest done">' + esc(q.text) + ' <em>done</em> ' + rm + '</div>'
          : '<div class="wc-quest">' + esc(q.text) +
            '<button type="button" class="btn sm ghost" data-wc-done="' + esc(q.text) + '">Done</button> ' +
            rm + '</div>';
      }).join('') : '<p class="hint">No tasks.</p>';
    }
    renderInv();
    renderParty();
    renderQuests();

    /* container-level listeners: the chips re-render, the container does not */
    body.querySelector('#wc-inv').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-drop]') : null;
      if (!btn) return;
      inv.splice(+btn.getAttribute('data-wc-drop'), 1);
      renderInv();
    });
    body.querySelector('#wc-party').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-comp]') : null;
      if (!btn) return;
      party.splice(+btn.getAttribute('data-wc-comp'), 1);
      renderParty();
    });
    body.querySelector('#wc-quests').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-wc-done]') : null;
      if (btn) {
        var t = btn.getAttribute('data-wc-done');
        quests.forEach(function (q) {
          if (!q.done && q.text.toLowerCase().indexOf(t.toLowerCase()) !== -1) q.done = true;
        });
        renderQuests();
        return;
      }
      /* v1.29.1: a task that was recorded in error can leave the ledger */
      var rm = e.target.closest ? e.target.closest('[data-wc-remove]') : null;
      if (!rm) return;
      var rt = rm.getAttribute('data-wc-remove');
      for (var qi = quests.length - 1; qi >= 0; qi--) {
        if (quests[qi].text === rt) { quests.splice(qi, 1); break; }
      }
      renderQuests();
    });

    var locSel = body.querySelector('#wc-loc');
    function locHint() {
      var id = locSel.value;
      body.querySelector('#wc-loc-hint').textContent =
        id === run.locationId ? '' :
        reachableIds[id] ? 'Directly reachable from here.' :
        'Not directly reachable from ' + (cur ? cur.name : 'here') +
        ' \u2014 the move will be forced.';
    }
    locSel.addEventListener('change', locHint);
    locHint();

    on(body, '#wc-item-add', 'click', function () {
      var v = body.querySelector('#wc-item').value.trim();
      if (!v) return;
      inv.push(v);
      body.querySelector('#wc-item').value = '';
      renderInv();
    });
    on(body, '#wc-companion-add', 'click', function () {
      var v = body.querySelector('#wc-companion').value.trim();
      if (!v) return;
      party.push(v);
      body.querySelector('#wc-companion').value = '';
      renderParty();
    });
    on(body, '#wc-quest-add', 'click', function () {
      var v = body.querySelector('#wc-quest').value.trim();
      if (!v) return;
      quests.push({ text: v, done: false });
      body.querySelector('#wc-quest').value = '';
      renderQuests();
    });
    on(body, '#wc-clock-go', 'click', function () {
      body.querySelector('#wc-save').click();
    });
    on(body, '#wc-save', 'click', function () {
      /* v1.21.0 (upstream 18.3.5): a turn mid-apply and a manual correction
         writing the same run object at once is how tags lose each other. */
      if (App.state.worldBusy) {
        UI.toast('Wait for the current turn to finish');
        return;
      }
      /* one correction object per change - correctState applies exactly one
         of each kind, so several edits mean several calls */
      var corrs = [];
      if (locSel.value !== run.locationId) corrs.push({ locationId: locSel.value });
      var cashEl = body.querySelector('#wc-cash');
      var cashNow = run.stats[run.cashId] !== undefined ? run.stats[run.cashId] : 0;
      if (cashEl.value !== '' && Number(cashEl.value) !== cashNow) {
        corrs.push({ cash: Number(cashEl.value) });
      }
      (hud.stats || []).forEach(function (st) {
        var el = body.querySelector('#wc-stat-' + st.id);
        if (!el) return;
        var now = run.stats[st.id] !== undefined ? run.stats[st.id] : 0;
        if (el.value !== '' && Number(el.value) !== now) {
          var s = {}; s[st.id] = Number(el.value);
          corrs.push({ stats: s });
        }
      });
      var oldInv = run.inventory || [];
      oldInv.forEach(function (x) { if (inv.indexOf(x) === -1) corrs.push({ removeInventory: x }); });
      inv.forEach(function (x) { if (oldInv.indexOf(x) === -1) corrs.push({ addInventory: x }); });
      var oldParty = (run.companions || []).map(function (c) { return c.name; });
      oldParty.forEach(function (x) { if (party.indexOf(x) === -1) corrs.push({ removeCompanion: x }); });
      party.forEach(function (x) { if (oldParty.indexOf(x) === -1) corrs.push({ addCompanion: x }); });
      (run.quests || []).forEach(function (o) {
        var now = null;
        quests.forEach(function (q) { if (q.text === o.text) now = q; });
        if (!now) { corrs.push({ removeQuest: o.text }); return; }
        if (now.done && !o.done) corrs.push({ doneQuestText: o.text });
      });
      quests.forEach(function (q) {
        if (!(run.quests || []).some(function (o) { return o.text === q.text; })) {
          corrs.push({ addQuest: q.text });
        }
      });
      /* v1.29.1: a manual clock shift, applied like any other correction */
      var clockEl = body.querySelector('#wc-clock');
      if (clockEl && clockEl.value !== '' && !isNaN(Number(clockEl.value)) && Number(clockEl.value) !== 0) {
        corrs.push({ clockDelta: Number(clockEl.value) });
        clockEl.value = '';
      }

      var changes = [];
      corrs.forEach(function (c) { changes = changes.concat(HW.correctState(world, run, c)); });
      if (!changes.length) { UI.toast('Nothing to change'); return; }
      run.log.push({ role: 'correction', content: 'State corrected: ' + changes.join('; '), at: Date.now() });
      if (run.log.length > 200) run.log = run.log.slice(-200);
      HW.saveRun(run).then(function () {
        App.go('worldrun');
        Views.worldRun(world, run, { changes: changes, rejections: [] });
        UI.toast('World state corrected');
      });
    });
  };

  Views.worlds = function (root) {
    var body = $('#worlds-body');
    if (!body) return;

    Promise.all([HW.all(), HW.allRuns(), HW.bundled()]).then(function (res) {
      var list = res[0] || [], runs = res[1] || [], shipped = res[2] || [];
      var have = {};
      list.forEach(function (w) { have[w.id] = 1; });
      var offered = shipped.filter(function (e) { return !have[e.id]; });
      /* v1.30.0: the face each run card gets is its WORLD's banner */
      var bannerOf = {};
      list.forEach(function (w) { bannerOf[w.id] = w.banner; });
      var html = '';

      if (runs.length) {
        html += '<div class="group"><div class="group-title">In progress</div>' +
          runs.map(function (r) {
            return '<div class="wr-card" data-run="' + esc(r.id) + '">' +
              '<span class="item-av">' + avatarHtml(bannerOf[r.worldId], r.worldName || 'World') + '</span>' +
              '<div style="flex:1;min-width:0">' +
                '<div class="wr-name">' + esc(r.worldName || 'World') + '</div>' +
                '<div class="wr-sub">' + esc(r.lifeName ? 'as ' + r.lifeName : '') +
                  (r.lifeName ? ' · ' : '') + 'turn ' + (r.turn || 0) + '</div>' +
              '</div>' +
              '<button class="chip" data-act="wr-del" data-run="' + esc(r.id) + '">' + icon('trash') + '</button>' +
            '</div>';
          }).join('') + '</div>';
      }

      html += '<div class="group"><div class="group-title">Installed worlds</div>';
      if (!list.length) {
        html += '<div class="empty" style="padding:16px 4px"><p>No worlds yet. Describe one and let ' +
          'AI create it, or import a <b>.horde_world</b> file. Its artwork is stripped on the ' +
          'way in — except the world&#39;s banner, which is kept (dieted down) as its avatar.</p></div>';
      } else {
        html += list.map(function (w) {
          var sum = HW.summarise(w);
          return '<div class="wr-card" data-world="' + esc(w.id) + '">' +
            '<span class="item-av">' + avatarHtml(w.banner, w.name) + '</span>' +
            '<div style="flex:1;min-width:0">' +
              '<div class="wr-name">' + esc(w.name) + '</div>' +
              '<div class="wr-sub">' + sum.locations + ' places · ' + sum.people + ' people · ' +
                sum.factions + ' factions · ' + sum.lore + ' lore</div>' +
              (w.description
                ? '<div class="wr-sub" style="margin-top:4px">' +
                  esc(String(w.description).slice(0, 160)) + '</div>' : '') +
            '</div>' +
            '<button class="chip" data-act="world-peek" data-world="' + esc(w.id) + '" ' +
              'title="Look inside - read-only">' + icon('eye') + '</button>' +
            '<button class="chip" data-act="world-del" data-world="' + esc(w.id) + '">' + icon('trash') + '</button>' +
          '</div>';
        }).join('');
      }
      if (offered.length) {
        html += '<div class="group"><div class="group-title">Available to install</div>' +
          offered.map(function (e) {
            return '<div class="wr-card" data-install="' + esc(e.id) + '">' +
              '<div style="flex:1;min-width:0">' +
                '<div class="wr-name">' + esc(e.name) + '</div>' +
                '<div class="wr-sub">' + (e.places || 0) + ' places · ' + (e.people || 0) +
                  ' people · ' + (e.factions || 0) + ' factions · ' + (e.roles || 0) + ' ways to begin</div>' +
                (e.description ? '<div class="wr-sub" style="margin-top:4px">' +
                  esc(e.description) + '</div>' : '') +
                (e.attribution ? '<div class="wr-sub" style="margin-top:4px;opacity:.7">' +
                  esc(e.attribution) + '</div>' : '') +
              '</div>' +
              '<button class="chip" data-act="world-peek-bundled" data-install="' + esc(e.id) + '" ' +
                'title="Look inside before installing">' + icon('eye') + '</button>' +
              '<button class="chip" data-act="world-install" data-install="' + esc(e.id) + '">Install</button>' +
            '</div>';
          }).join('') + '</div>';
      }

      html += '</div>';
      html += '<div class="field">' +
        '<button class="btn primary block sm" data-act="world-create">' +
          icon('sparkle') + ' Create a world with AI</button>' +
        '<button class="btn ghost block sm" style="margin-top:6px" data-act="world-import">' +
          icon('plus') + ' Import a world file</button></div>';

      body.innerHTML = html;

      on(body, '[data-act=world-create]', 'click', function () { App.aiCreateWorld(); });
      on(body, '[data-act=world-import]', 'click', function () { App.importWorld(); });
      on(body, '[data-world]', 'click', function (e) {
        if (e.target.closest('[data-act]')) return;
        App.startWorld(this.getAttribute('data-world'));
      });
      on(body, '[data-run]', 'click', function (e) {
        if (e.target.closest('[data-act]')) return;
        App.openWorldRun(this.getAttribute('data-run'));
      });
      /* v1.35.0: peek without commitment - installed worlds from the
         library, catalogue worlds fetched without saving */
      on(body, '[data-act=world-peek]', 'click', function () {
        var id = this.getAttribute('data-world');
        var w = null;
        list.forEach(function (x) { if (x.id === id) w = x; });
        if (!w) return;
        UI.sheet({ title: w.name, body: Views.worldSummary(w),
          actions: [{ label: 'Begin here', cls: 'primary', onClick: function () { App.startWorld(id); } },
                    { label: 'Close', cls: 'ghost', value: null }] });
      });
      on(body, '[data-act=world-peek-bundled]', 'click', function () {
        var id = this.getAttribute('data-install');
        HW.peekBundled(id).then(function (w) {
          UI.sheet({ title: w.name, body: Views.worldSummary(w),
            actions: [{ label: 'Install', cls: 'primary', onClick: function () {
                        HW.installBundled(id).then(function (iw) {
                          UI.toast('Installed ' + (iw && iw.name), 3200);
                          App.go('worlds');
                        }).catch(function (e2) { UI.toast((e2 && e2.message) || 'Could not install', 4500); });
                      } },
                      { label: 'Close', cls: 'ghost', value: null }] });
        }).catch(function (e) { UI.toast((e && e.message) || 'Could not open that world', 4500); });
      });
      on(body, '[data-act=world-install]', 'click', function () {
        var id = this.getAttribute('data-install');
        HW.installBundled(id).then(function (w) {
          UI.toast('Installed ' + (w && w.name), 3200);
          App.go('worlds');
        }).catch(function (e) {
          UI.toast((e && e.message) || 'Could not install that world', 4500);
        });
      });
      on(body, '[data-act=world-del]', 'click', function () {
        var id = this.getAttribute('data-world');
        UI.confirm('Delete this world?', 'Any playthroughs in it are removed too.',
          { danger: true, okLabel: 'Delete' }).then(function (yes) {
          if (!yes) return;
          HW.remove(id).then(function () { App.go('worlds'); });
        });
      });
      on(body, '[data-act=wr-del]', 'click', function () {
        var id = this.getAttribute('data-run');
        UI.confirm('Abandon this run?', 'The story so far is deleted.',
          { danger: true, okLabel: 'Abandon' }).then(function (yes) {
          if (!yes) return;
          HW.removeRun(id).then(function () { App.go('worlds'); });
        });
      });
    });
  };

  /* The roles a world lets you begin as, when it offers more than one. */
  Views.worldRoles = function (world) {
    var body = $('#worlds-body');
    if (!body) return;
    var lives = world.startingLives || [];
    body.innerHTML =
      '<div class="group"><div class="group-title">Begin as…</div>' +
      lives.map(function (l) {
        return '<div class="wr-card" data-life="' + esc(l.id) + '">' +
          '<div style="flex:1;min-width:0">' +
            '<div class="wr-name">' + esc(l.name || l.role || 'Someone') + '</div>' +
            (l.role ? '<div class="wr-sub">' + esc(l.role) +
              (l.socialRank ? ' · ' + esc(l.socialRank) : '') + '</div>' : '') +
            (l.description ? '<div class="wr-sub" style="margin-top:4px">' +
              esc(l.description) + '</div>' : '') +
          '</div></div>';
      }).join('') + '</div>' +
      '<div class="field"><button class="btn ghost block sm" data-act="worlds-back">Back to worlds</button></div>';

    on(body, '[data-life]', 'click', function () {
      /* v1.38.0: after the life, the class gate (which passes plain
         worlds straight through to the begin) */
      App.beginOrPickClass(world.id, this.getAttribute('data-life'));
    });
    on(body, '[data-act=worlds-back]', 'click', function () { App.go('worlds'); });
  };

  /* v1.38.0: the class gate - worlds that declare classes ask after the
     life is chosen; every row carries what the class brings, and "No
     class" is always a legitimate door. */
  Views.worldClasses = function (world, lifeId) {
    var body = $('#worlds-body');
    if (!body) return;
    body.innerHTML =
      '<div class="group"><div class="group-title">Pick a class</div>' +
      ((world.classes || []).map(function (c) {
        var sk = (c.skills || []).map(function (id) {
          var s = null;
          (world.skillsCatalog || []).forEach(function (t) { if (t.id === id) s = t; });
          return (s && s.name) || id;
        });
        return '<div class="wr-card" data-cls="' + esc(c.id) + '">' +
          '<div style="flex:1;min-width:0">' +
            '<div class="wr-name">' + esc(c.name) + '</div>' +
            (c.description ? '<div class="wr-sub">' + esc(c.description) + '</div>' : '') +
            (sk.length ? '<div class="wr-sub">brings ' + esc(sk.join(', ')) + ' at level 1</div>' : '') +
            (c.outfit ? '<div class="wr-sub">wears ' + esc(c.outfit) + '</div>' : '') +
          '</div></div>';
      }).join('') +
      '<div class="wr-card" data-cls="">' +
        '<div style="flex:1;min-width:0">' +
          '<div class="wr-name">No class</div>' +
          '<div class="wr-sub">Just you, unbent.</div>' +
        '</div></div>') +
      '</div>' +
      '<div class="field"><button class="btn ghost block sm" data-act="worlds-back">Back to worlds</button></div>';

    on(body, '[data-cls]', 'click', function () {
      App.beginWorld(world.id, lifeId, this.getAttribute('data-cls') || null);
    });
    on(body, '[data-act=worlds-back]', 'click', function () { App.go('worlds'); });
  };

  global.Views = Views;
})(window);
